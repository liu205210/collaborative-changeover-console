import type { ReactNode } from 'react'
import type { DatasetMeta, Plan, StrategyKey } from '../types'

interface Props {
  meta: DatasetMeta | null
  plan: Plan | null
  mode: StrategyKey
  setMode: (m: StrategyKey) => void
}

const STRAT_LABEL: Record<StrategyKey, string> = {
  A: '方案A · 订单串行 SOP 对照',
  B: '方案B · 跨订单离线准备 + 固定优先级',
  C: '方案C · 协同优化'
}

export default function Validation({ meta, plan, mode, setMode }: Props) {
  if (!meta) {
    return (
      <div className="panel empty-panel">
        <div className="empty big">
          <div className="empty-title">数据加载中或导入失败</div>
          <div className="empty-sub">请检查数据文件并尝试“重新导入数据”。</div>
        </div>
      </div>
    )
  }

  const agg = meta.quantityAggregation

  return (
    <div className="validation-page">
      <div className="panel">
        <div className="panel-head">
          <h2>Excel 导入与数据质量核查</h2>
          <span className="panel-hint">来源文件：{meta.sourceFile}</span>
        </div>
        <div className="kpi-row wrap">
          <Kpi label="工作表数" value={meta.sheetCount} unit={meta.sheetNames.join('、')} />
          <Kpi label="数据行数" value={meta.dataRows} unit={`空行 ${meta.blankRows}`} />
          <Kpi label="订单数" value={meta.orders} unit="个" />
          <Kpi label="产品数" value={meta.products} unit="个（成品专用号）" />
          <Kpi label="物料数" value={meta.materials} unit="种（物料编码）" />
          <Kpi label="日期范围" value={meta.dateRange.min} unit={`共 ${meta.dateRange.distinctDays} 天`} />
          <Kpi label="完全重复行" value={meta.duplicates.fullRows} unit="行" ok={meta.duplicates.fullRows === 0} />
          <Kpi label="键重复明细" value={meta.duplicates.compositeKeys} unit="组" ok={meta.duplicates.compositeKeys === 0} />
        </div>
        <div className="grid-2 tight">
          <div className="sub-card">
            <div className="sub-title">缺失值统计（按字段）</div>
            <div className="chips">
              {Object.entries(meta.missing).map(([k, v]) => (
                <span className={`chip ${v > 0 ? 'chip-warn' : ''}`} key={k}>
                  {k}：{v}
                </span>
              ))}
            </div>
            <div className="muted">重复判定口径：{meta.duplicates.compositeKeyDefinition}</div>
          </div>
          <div className="sub-card">
            <div className="sub-title">物料分类分布（按物料明细行）</div>
            <div className="cat-list">
              {meta.materialCategories.map((c) => {
                const max = meta.materialCategories[0]?.count || 1
                return (
                  <div className="cat-row" key={c.name}>
                    <span className="cat-name">{c.name}</span>
                    <div className="cat-bar">
                      <div className="cat-fill" style={{ width: `${(c.count / max) * 100}%` }} />
                    </div>
                    <span className="cat-count">{c.count}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="panel panel-warn">
        <div className="panel-head">
          <h2>排产数量聚合核查（关键）</h2>
          <span className="badge badge-warn">已按订单去重</span>
        </div>
        <div className="agg-grid">
          <div className="agg-card bad">
            <div className="agg-label">按物料明细行直接求和（错误口径）</div>
            <div className="agg-value">{agg.rawMaterialDetailSum.toLocaleString()}</div>
            <div className="agg-foot">基于 {agg.rawMaterialDetailRows} 行明细累加，因 BOM 展开而虚高</div>
          </div>
          <div className="agg-card good">
            <div className="agg-label">按订单去重后聚合（正确口径）</div>
            <div className="agg-value">{agg.aggregatedByOrderSum.toLocaleString()}</div>
            <div className="agg-foot">每个订单的排产数量仅计一次</div>
          </div>
          <div className="agg-card">
            <div className="agg-label">虚高倍数</div>
            <div className="agg-value">{agg.inflatedTimes}×</div>
            <div className="agg-foot">直接求和会放大数量，导致排程严重失真</div>
          </div>
        </div>
        <p className="muted">{agg.note}</p>
      </div>

      {plan && (
        <div className="panel">
          <div className="panel-head">
            <h2>订单聚合结果</h2>
            <span className="panel-hint">当前计划所选订单</span>
          </div>
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>订单批次号</th>
                  <th>成品专用号</th>
                  <th className="num">排产数量</th>
                  <th className="num">BOM 行数</th>
                  <th className="num">物料种类</th>
                  <th>装配面</th>
                  <th>交货日期</th>
                </tr>
              </thead>
              <tbody>
                {plan.orders.map((o) => (
                  <tr key={o.order}>
                    <td className="mono">{o.order}</td>
                    <td className="mono">{o.product}</td>
                    <td className="num">{o.qty}</td>
                    <td className="num">{o.bomLines}</td>
                    <td className="num">{o.materialTypes}</td>
                    <td>{o.faces.join('+')}</td>
                    <td>{o.delivery}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="panel panel-oee">
        <div className="panel-head">
          <h2>{plan?.assumptions.boundary.title || '建模边界：仅模拟换产任务，不是完整生产排程'}</h2>
          <span className="badge badge-warn">重要边界</span>
        </div>
        <p>{plan?.assumptions.boundary.statement || '本模型只对换产任务链建模，不模拟订单正式生产时长。'}</p>
        <p className="muted">{plan?.assumptions.boundary.comparableMetric}</p>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>{plan?.assumptions.lineStateModel.title || '产线状态与订单一致性约束'}</h2>
          <span className="badge badge-info">业务规则</span>
        </div>
        <div className="source-grid">
          <div className="sub-card">
            <div className="sub-title src-real">产线状态一致性规则</div>
            <ul className="bullet">
              {(plan?.assumptions.lineStateModel.rules || []).map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
          </div>
          <div className="sub-card">
            <div className="sub-title src-sim">依据赛题说明的前置关系</div>
            <ul className="bullet">
              {(plan?.assumptions.lineStateModel.readiness || []).map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>补充仿真模型与假设</h2>
          <span className="badge badge-info">{plan?.assumptions.modelType || '补充仿真模型'}</span>
        </div>
        <div className="source-grid">
          <div className="sub-card">
            <div className="sub-title src-real">真实导入数据</div>
            <p>{plan?.assumptions.dataSource.real || '订单/BOM 明细来自《赛道数据包.xlsx》，为真实导入数据。'}</p>
          </div>
          <div className="sub-card">
            <div className="sub-title src-sim">补充仿真假设</div>
            <p>{plan?.assumptions.dataSource.simulated || '资源池、人员效率、工序依赖与工时公式为建模假设。'}</p>
          </div>
          <div className="sub-card">
            <div className="sub-title src-missing">数据未提供（因此不计算 OEE）</div>
            <ul className="bullet">
              {(plan?.assumptions.dataSource.missing || []).map((m) => (
                <li key={m}>{m}</li>
              ))}
            </ul>
          </div>
        </div>
        <p className="declare">{plan?.assumptions.declaration || '本应用中的换产耗时等指标均由仿真模型与排程算法计算得出，不代表工厂实测数据。'}</p>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>换产工序模型（任务模板）</h2>
          <span className="panel-hint">区分在线/离线；工时公式为补充仿真假设</span>
        </div>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>在线/离线</th>
                <th>阶段</th>
                <th>工序</th>
                <th>责任工种</th>
                <th>前序依赖</th>
                <th>独占资源</th>
                <th>工时公式（分钟）</th>
                <th>建模理由</th>
              </tr>
            </thead>
            <tbody>
              {(plan?.assumptions.taskTemplates || []).map((t) => (
                <tr key={t.key}>
                  <td>
                    <span className={`mode-tag ${t.stage === 'line' ? 'online' : 'offline'}`}>{t.stage === 'line' ? '在线' : '离线'}</span>
                  </td>
                  <td>{t.phase}</td>
                  <td>{t.name}</td>
                  <td>{t.skillLabel}</td>
                  <td>{t.deps.length ? t.deps.join('、') : '无'}</td>
                  <td>{t.exclusive || '—'}</td>
                  <td className="mono">{t.formula}</td>
                  <td className="muted">{t.rationale}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="grid-2 tight">
          <div className="sub-card">
            <div className="sub-title">人员资源池（含效率系数，仿真假设）</div>
            <div className="chips">
              {(plan?.assumptions.personnel || []).map((p) => (
                <span className="chip" key={p.id}>
                  {p.name} · {p.skill} · 效率 {p.efficiency}
                </span>
              ))}
            </div>
            <div className="muted">{plan?.assumptions.efficiencyNote}</div>
          </div>
          <div className="sub-card">
            <div className="sub-title">独占资源</div>
            <div className="chips">
              {(plan?.assumptions.exclusive || []).map((e) => (
                <span className="chip" key={e.id}>
                  {e.name}（容量 {e.capacity}）· {e.note}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>异常注入与动态重排假设</h2>
          <span className="badge badge-info">规则决策模式</span>
        </div>
        <div className="source-grid">
          <div className="sub-card">
            <div className="sub-title src-real">支持的四类异常</div>
            <ul className="bullet">
              {(plan?.assumptions.eventModel?.supported || []).map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
          </div>
          <div className="sub-card">
            <div className="sub-title src-sim">重排规则与可查看假设</div>
            <ul className="bullet">
              {(plan?.assumptions.eventModel?.assumptions || []).map((r) => (
                <li key={r}>{r}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>效果指标定义</h2>
          <span className="panel-hint">开始事件 / 结束事件 / 计算公式</span>
        </div>
        <div className="grid-2 tight">
          {plan &&
            (['totalMakespan', 'onlineStopWindow', 'offlinePrep'] as const).map((k) => {
              const d = plan.assumptions.metricDefinitions[k]
              return (
                <div className="sub-card" key={k}>
                  <div className="sub-title">{d.name}</div>
                  <div className="def-row">
                    <span className="k">开始事件</span>
                    <span>{d.startEvent}</span>
                  </div>
                  <div className="def-row">
                    <span className="k">结束事件</span>
                    <span>{d.endEvent}</span>
                  </div>
                  <div className="def-row">
                    <span className="k">计算公式</span>
                    <span className="mono">{d.formula}</span>
                  </div>
                  <div className="muted">{d.note}</div>
                </div>
              )
            })}
        </div>
      </div>

      <div className="panel panel-oee">
        <div className="panel-head">
          <h2>OEE 指标</h2>
          <span className="badge badge-warn">待验证</span>
        </div>
        <p>{plan?.assumptions.oeeNote.reason || '缺少生产工时、产出数量与良率数据，OEE 无法计算。'}</p>
        <div className="chips">
          {(plan?.assumptions.oeeNote.required || ['计划生产时间', '实际产出数量', '良品数量', '设备停机记录']).map((r) => (
            <span className="chip chip-warn" key={r}>
              缺少：{r}
            </span>
          ))}
        </div>
      </div>

      {plan && (
        <>
          <div className="panel">
            <div className="panel-head">
              <h2>独立验证结果</h2>
              <div className="seg">
                {(['A', 'B', 'C'] as StrategyKey[]).map((k) => (
                  <button key={k} className={`seg-btn ${mode === k ? 'active' : ''}`} onClick={() => setMode(k)}>
                    {STRAT_LABEL[k]}
                  </button>
                ))}
              </div>
            </div>
            <div className="check-grid">
              {plan.validation[mode].checks.map((c) => (
                <div className={`check-card ${c.status}`} key={c.name}>
                  <div className="check-head">
                    <span className={`check-badge ${c.status}`}>{c.status === 'pass' ? '通过' : '未通过'}</span>
                    <span className="check-name">{c.name}</span>
                  </div>
                  <div className="check-detail">{c.detail}</div>
                </div>
              ))}
            </div>
            <div className={`result-banner ${plan.validation[mode].ok ? 'ok' : 'bad'}`}>
              {plan.validation[mode].ok
                ? '独立验证全部通过：任务完整无重复、前置依赖满足、人员技能匹配、资源无冲突、同一产线在线换产窗口不交叠、首件生产时产品/工装/参数一致、质量门禁有效。'
                : `存在 ${plan.validation[mode].violations.length} 项违例，请检查排程。`}
            </div>
          </div>

          <div className="panel">
            <div className="panel-head">
              <h2>A / B / C 三方案比较</h2>
              <span className="panel-hint">相同订单、任务耗时、人员、资源、初始状态与产线约束</span>
            </div>
            <div className="compare three">
              {(['A', 'B', 'C'] as StrategyKey[]).map((k) => {
                const m = plan.comparison[k]
                const max = Math.max(plan.comparison.A.makespan, plan.comparison.B.makespan, plan.comparison.C.makespan, 1)
                return (
                  <div className={`compare-col ${k === 'C' ? 'accent' : ''}`} key={k}>
                    <div className="compare-title">{STRAT_LABEL[k]}</div>
                    <div className="compare-make">{m.makespan} 分钟</div>
                    <div className="compare-bar">
                      <div className={`compare-fill ${k === 'C' ? 'opt' : k === 'B' ? 'b' : 'fixed'}`} style={{ width: `${(m.makespan / max) * 100}%` }} />
                    </div>
                    <ul className="bullet">
                      <li>在线停线窗口合计：{m.onlineStopTotal} 分钟</li>
                      <li>离线准备总工时：{m.offlinePrepTotal} 分钟</li>
                      <li>资源等待事件：{m.conflictEvents} 处</li>
                    </ul>
                  </div>
                )
              })}
            </div>
            <div className="delta-grid">
              <div className="delta-card">
                <div className="delta-title">A → B（提前准备收益）</div>
                <div className="delta-value">
                  {plan.comparison.deltas.AtoB.makespanDeltaMin} 分钟 / {plan.comparison.deltas.AtoB.makespanDeltaPct}%
                </div>
                <div className="muted">{plan.comparison.interpretation.AtoB}</div>
              </div>
              <div className="delta-card">
                <div className="delta-title">B → C（调度算法收益）</div>
                <div className="delta-value">
                  {plan.comparison.deltas.BtoC.makespanDeltaMin} 分钟 / {plan.comparison.deltas.BtoC.makespanDeltaPct}%
                </div>
                <div className="muted">{plan.comparison.interpretation.BtoC}</div>
              </div>
              <div className="delta-card">
                <div className="delta-title">A → C（总体变化）</div>
                <div className="delta-value">
                  {plan.comparison.deltas.AtoC.makespanDeltaMin} 分钟 / {plan.comparison.deltas.AtoC.makespanDeltaPct}%
                </div>
                <div className="muted">{plan.comparison.interpretation.AtoC}</div>
              </div>
            </div>
            <p className="muted">
              {plan.comparison.note} A→B→C 的变化为算法实际计算结果，未通过放松产线约束制造改善；即使改善为零也会如实展示。
              本批次在线停线合计：A {plan.comparison.A.onlineStopTotal}、B {plan.comparison.B.onlineStopTotal}、C {plan.comparison.C.onlineStopTotal} 分钟。总历时缩短不能直接等同于单次停线缩短。
              “订单更多、资源更紧时算法收益更明显”属于待批量评测验证的假设，不作为已证结论。
            </p>
          </div>
        </>
      )}
    </div>
  )
}

function Kpi({ label, value, unit, ok }: { label: string; value: ReactNode; unit?: string; ok?: boolean }) {
  return (
    <div className={`kpi ${ok ? 'ok' : ''}`}>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        {value}
        {unit && <span className="kpi-unit">{unit}</span>}
      </div>
    </div>
  )
}
