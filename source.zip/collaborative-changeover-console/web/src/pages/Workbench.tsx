import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import { api } from '../api'
import type { OrderDetail, OrderSummary, Plan, StrategyKey } from '../types'
import Gantt from '../components/Gantt'

interface Props {
  orders: OrderSummary[]
  orderMap: Map<string, OrderSummary>
  selected: string[]
  setSelected: (v: string[]) => void
  plan: Plan | null
  mode: StrategyKey
  setMode: (m: StrategyKey) => void
  generating: boolean
  loadingData: boolean
  onCreatePlan: () => void
}

const STRATEGIES: { key: StrategyKey; label: string }[] = [
  { key: 'A', label: '方案A · SOP对照' },
  { key: 'B', label: '方案B · 提前准备' },
  { key: 'C', label: '方案C · 协同优化' }
]

export default function Workbench({ orders, selected, setSelected, plan, mode, setMode, generating, loadingData, onCreatePlan }: Props) {
  const [query, setQuery] = useState('')
  const [ganttView, setGanttView] = useState<'task' | 'resource'>('task')
  const [detailOrder, setDetailOrder] = useState<string>('')
  const [detail, setDetail] = useState<OrderDetail | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return orders
    return orders.filter((o) => o.order.toLowerCase().includes(q) || o.product.toLowerCase().includes(q) || o.productDesc.toLowerCase().includes(q))
  }, [orders, query])

  const schedule = plan ? plan.schedules[mode] : null
  const validation = plan?.validation[mode]
  const selectedDiffers = plan && (selected.length !== plan.orderIds.length || selected.some(id => !plan.orderIds.includes(id)))

  useEffect(() => {
    if (!detailOrder) {
      setDetail(null)
      return
    }
    let alive = true
    setDetailLoading(true)
    api
      .order(detailOrder)
      .then((d) => alive && setDetail(d))
      .catch(() => alive && setDetail(null))
      .finally(() => alive && setDetailLoading(false))
    return () => {
      alive = false
    }
  }, [detailOrder])

  const toggle = (id: string) => {
    setSelected(selected.includes(id) ? selected.filter((x) => x !== id) : [...selected, id])
  }

  return (
    <div className="workbench">
      <section className="panel order-panel">
        <div className="panel-head">
          <h2>订单选择</h2>
          <span className="panel-hint">共 {orders.length} 个订单</span>
        </div>
        <input className="input" placeholder="搜索订单号 / 成品专用号" value={query} onChange={(e) => setQuery(e.target.value)} />
        <div className="order-actions">
          <button className="btn btn-mini" onClick={() => setSelected(filtered.map((o) => o.order))}>
            全选当前
          </button>
          <button className="btn btn-mini" onClick={() => setSelected([])}>
            清空
          </button>
        </div>
        <div className="order-list">
          {loadingData && <div className="empty small">数据加载中…</div>}
          {!loadingData && filtered.length === 0 && <div className="empty small">没有匹配的订单</div>}
          {filtered.slice(0, 300).map((o) => (
            <label key={o.order} className={`order-item ${selected.includes(o.order) ? 'checked' : ''}`}>
              <input type="checkbox" checked={selected.includes(o.order)} onChange={() => toggle(o.order)} />
              <div className="order-item-body">
                <div className="order-item-top">
                  <span className="mono">{o.order}</span>
                  <span className="order-qty">{o.qty} 件</span>
                </div>
                <div className="order-item-sub">
                  {o.product} · {o.bomLines} 行 BOM / {o.materialTypes} 种物料 · {o.faces.join('+')}
                </div>
              </div>
            </label>
          ))}
        </div>
        <button className="btn btn-primary btn-block" onClick={onCreatePlan} disabled={generating || !selected.length}>
          {generating ? '正在计算 A/B/C 三套排程…' : `生成换产计划（${selected.length} 个订单）`}
        </button>
      </section>

      <section className="workbench-main">
        {selectedDiffers && <div className="metric-hint">待排订单选择已改变。下方仍展示已生成的 {plan.orders.length} 订单计划；点击“生成换产计划”后更新。</div>}
        {generating && <div className="loading-block">正在运行六类智能体协同排程、产线一致性校验与 A/B/C 对照计算…</div>}
        {!plan && !generating && (
          <div className="panel empty-panel">
            <div className="empty big">
              <div className="empty-title">尚未生成换产计划</div>
              <div className="empty-sub">在左侧选择订单（建议 2-3 个订单以体现跨订单提前准备与协同优化效果），点击“生成换产计划”。</div>
            </div>
          </div>
        )}

        {plan && schedule && !generating && (
          <>
            <div className="kpi-row">
              <Kpi label="订单数" value={plan.orders.length} unit="个" />
              <Kpi label="任务总数" value={plan.tasks.length} unit="个" />
              <Kpi label="方案A 总历时" value={plan.comparison.A.makespan} unit="分钟" />
              <Kpi label="方案B 总历时" value={plan.comparison.B.makespan} unit="分钟" />
              <Kpi label="方案C 总历时" value={plan.comparison.C.makespan} unit="分钟" accent />
              <Kpi label={`方案${mode} 在线停线合计`} value={schedule.metrics.onlineStopTotal} unit="分钟" />
              <Kpi label={`方案${mode} 离线准备工时`} value={schedule.metrics.offlinePrepTotal} unit="分钟" />
              <Kpi label={`方案${mode} 验证问题`} value={validation?.violations.length ?? '—'} unit={validation?.ok ? '校验通过' : '查看验证明细'} ok={validation?.ok} />
            </div>

            <div className="panel">
              <div className="panel-head">
                <h2>换产排程甘特图</h2>
                <div className="seg">
                  {STRATEGIES.map((s) => (
                    <button key={s.key} className={`seg-btn ${mode === s.key ? 'active' : ''}`} onClick={() => setMode(s.key)}>
                      {s.label}
                    </button>
                  ))}
                  <span className="seg-divider" />
                  <button className={`seg-btn ${ganttView === 'task' ? 'active' : ''}`} onClick={() => setGanttView('task')}>
                    按任务
                  </button>
                  <button className={`seg-btn ${ganttView === 'resource' ? 'active' : ''}`} onClick={() => setGanttView('resource')}>
                    按人员
                  </button>
                </div>
              </div>
              <p className="panel-desc">
                {schedule.description}
                {schedule.strategyAssumption && <span className="badge badge-info inline">{schedule.strategyAssumption}</span>}
              </p>
              <Gantt entries={schedule.entries} makespan={schedule.metrics.makespan} view={ganttView} />
              <div className="metric-hint">
                总历时 = 最后一个任务完成时刻；在线停线窗口 = 首个在线产线作业（清线与旧工装拆卸）开始 → 恢复生产结束，切换前的清线/拆卸/等待均计入；离线准备 = 该订单首/末个离线准备任务。
                总历时缩短不等于在线停线缩短；应分别比较实际指标。单次停线时间仅在起止口径、任务范围与基准一致时才可与赛题 30 分钟比较。
              </div>
            </div>

            <div className="panel">
              <div className="panel-head">
                <h2>各订单时间指标</h2>
                <span className="panel-hint">{schedule.modeName}</span>
              </div>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>订单</th>
                      <th className="num">离线准备起</th>
                      <th className="num">离线准备止</th>
                      <th className="num">离线准备跨度</th>
                      <th className="num">离线准备工时</th>
                      <th className="num">在线换产起</th>
                      <th className="num">恢复生产止</th>
                      <th className="num">在线停线窗口</th>
                    </tr>
                  </thead>
                  <tbody>
                    {schedule.metrics.orderMetrics.map((m) => (
                      <tr key={m.order}>
                        <td className="mono">{m.order}</td>
                        <td className="num">{m.prepStart}</td>
                        <td className="num">{m.prepEnd}</td>
                        <td className="num">{m.prepSpanMin}</td>
                        <td className="num">{m.prepWorkMin}</td>
                        <td className="num">{m.onlineStart}</td>
                        <td className="num">{m.onlineEnd}</td>
                        <td className="num strong">{m.onlineStopMin}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="metric-hint">
                方案 {mode} 在线停线窗口合计 {schedule.metrics.onlineStopTotal} 分钟，为各订单停线窗口之和，包含窗口内等待；与多订单总历时分开评价。
              </div>
            </div>

            <div className="grid-2">
              <div className="panel">
                <div className="panel-head">
                  <h2>目标产品与所需物料</h2>
                  <select className="select" value={detailOrder} onChange={(e) => setDetailOrder(e.target.value)}>
                    <option value="">选择订单查看 BOM…</option>
                    {plan.orders.map((o) => (
                      <option key={o.order} value={o.order}>
                        {o.order} · {o.product}
                      </option>
                    ))}
                  </select>
                </div>
                {detailLoading && <div className="empty small">加载 BOM…</div>}
                {!detailLoading && !detail && <div className="empty small">{detailOrder ? '未找到订单明细' : '选择订单后展示成品信息与物料清单（物料编码按字符串保留前导零）'}</div>}
                {detail && (
                  <>
                    <div className="detail-meta">
                      <div>
                        <span className="k">成品专用号</span>
                        <span className="mono">{detail.product}</span>
                      </div>
                      <div>
                        <span className="k">排产数量</span>
                        <span>{detail.qty} 件</span>
                      </div>
                      <div>
                        <span className="k">交货日期</span>
                        <span>{detail.delivery}</span>
                      </div>
                      <div>
                        <span className="k">装配面</span>
                        <span>{detail.faces.join(' / ')}</span>
                      </div>
                      <div>
                        <span className="k">物料明细</span>
                        <span>{detail.bomLines} 行 / {detail.materialTypes} 种</span>
                      </div>
                    </div>
                    <div className="table-wrap scroll">
                      <table className="data-table">
                        <thead>
                          <tr>
                            <th>物料编码</th>
                            <th>物料描述</th>
                            <th>面</th>
                            <th className="num">用量</th>
                          </tr>
                        </thead>
                        <tbody>
                          {detail.bom.slice(0, 300).map((b, i) => (
                            <tr key={`${b.material}-${b.face}-${i}`}>
                              <td className="mono">{b.material}</td>
                              <td>{b.materialDesc}</td>
                              <td>{b.face}</td>
                              <td className="num">{b.usage}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </div>

              <div className="panel">
                <div className="panel-head">
                  <h2>人员与资源分配</h2>
                  <span className="panel-hint">{schedule.modeName}</span>
                </div>
                <div className="table-wrap scroll">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>人员</th>
                        <th>工种</th>
                        <th className="num">占用(分)</th>
                        <th className="num">利用率</th>
                      </tr>
                    </thead>
                    <tbody>
                      {schedule.metrics.utilization
                        .filter((u) => u.busy > 0)
                        .sort((a, b) => b.busy - a.busy)
                        .map((u) => (
                          <tr key={u.id}>
                            <td>{u.name}</td>
                            <td>{u.skill}</td>
                            <td className="num">{u.busy}</td>
                            <td className="num">
                              <div className="bar-cell">
                                <div className="bar-fill" style={{ width: `${Math.min(100, u.utilizationPct)}%` }} />
                                <span>{u.utilizationPct}%</span>
                              </div>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
                <div className="panel-sub">独占资源占用</div>
                <div className="chips">
                  {schedule.metrics.exclusiveUsage.map((e) => (
                    <span className="chip" key={e.id}>
                      {e.name}：{e.busy} 分 / {e.utilizationPct}%
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="panel">
              <div className="panel-head">
                <h2>换产任务明细</h2>
                <span className="panel-hint">
                  {schedule.modeName} · 总历时 {schedule.metrics.makespan} 分钟 · 关键路径 {schedule.metrics.criticalPath} 分钟
                </span>
              </div>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>订单</th>
                      <th>任务</th>
                      <th>在线/离线</th>
                      <th>阶段</th>
                      <th>技能</th>
                      <th>执行人</th>
                      <th>独占资源</th>
                      <th className="num">开始</th>
                      <th className="num">结束</th>
                      <th className="num">时长</th>
                      <th className="num">资源等待</th>
                    </tr>
                  </thead>
                  <tbody>
                    {schedule.entries.map((e) => (
                      <tr key={e.id} className={e.delayedByResource ? 'row-warn' : ''}>
                        <td className="mono">{e.order}</td>
                        <td>{e.name}</td>
                        <td>
                          <span className={`mode-tag ${e.stage === 'line' ? 'online' : 'offline'}`}>{e.stage === 'line' ? '在线' : '离线'}</span>
                        </td>
                        <td>{e.phase}</td>
                        <td>{e.skillLabel}</td>
                        <td>{e.assigneeName}</td>
                        <td>{e.exclusive || '—'}</td>
                        <td className="num">{e.start}</td>
                        <td className="num">{e.end}</td>
                        <td className="num">{e.duration}</td>
                        <td className="num">{e.resourceWait > 0 ? e.resourceWait : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  )
}

function Kpi({ label, value, unit, accent, ok }: { label: string; value: ReactNode; unit?: string; accent?: boolean; ok?: boolean }) {
  return (
    <div className={`kpi ${accent ? 'accent' : ''} ${ok ? 'ok' : ''}`}>
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        {value}
        {unit && <span className="kpi-unit">{unit}</span>}
      </div>
    </div>
  )
}
