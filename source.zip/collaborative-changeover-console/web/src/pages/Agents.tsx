import { useCallback, useEffect, useState } from 'react'
import { api } from '../api'

const QUICK = [
  { intent: 'blocking', label: '当前哪个任务阻塞了换产？', question: '当前哪个任务阻塞了换产？由哪些资源、前序任务或质量门禁造成？' },
  { intent: 'agv-recovery', label: 'AGV 延迟为何采用当前恢复方案？', question: 'AGV 延迟后为什么采用当前恢复方案？R0/R1 差多少，是否持平？' },
  { intent: 'release', label: '某订单现在能否放行？', question: '订单现在能否放行？缺少什么条件，下一步由哪个角色处理？' },
  { intent: 'learned-template', label: 'P8 学习模板为何可供启用？', question: 'P8 学习模板为什么可供启用？它改善了什么、没有改善什么？' }
]

const STATUS_CLASS: Record<string, string> = {
  已完成: 'done',
  进行中: 'running',
  等待: 'waiting',
  异常: 'fail',
  待开始: 'pending'
}

export default function Agents(_props: { plan?: unknown; mode?: string; setMode?: (m: any) => void }) {
  const [status, setStatus] = useState<any>(null)
  const [source, setSource] = useState<'execution' | 'plan' | 'replay'>('execution')
  const [eventIndex, setEventIndex] = useState(0)
  const [at, setAt] = useState<number | null>(null)
  const [consoleData, setConsoleData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [evidence, setEvidence] = useState<any>(null)

  const [question, setQuestion] = useState('')
  const [answer, setAnswer] = useState<any>(null)
  const [answering, setAnswering] = useState(false)

  useEffect(() => {
    api
      .collabStatus()
      .then((s) => {
        setStatus(s)
        if (!s.sources.execution.available && s.sources.plan.available) setSource('plan')
      })
      .catch((e) => setError((e as Error).message))
      .finally(() => setLoading(false))
  }, [])

  const load = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const opts = source === 'replay' ? { eventIndex } : source === 'execution' && at != null ? { at } : {}
      const d = await api.collabConsole(source, opts)
      setConsoleData(d)
      setEvidence(null)
    } catch (e) {
      setError((e as Error).message)
      setConsoleData(null)
    } finally {
      setLoading(false)
    }
  }, [source, eventIndex, at])

  useEffect(() => {
    if (status) load()
  }, [status, load])

  const ask = useCallback(
    async (q: string, intent?: string) => {
      setAnswering(true)
      setError(null)
      try {
        const opts = source === 'replay' ? { eventIndex } : source === 'execution' && at != null ? { at } : {}
        const a = await api.collabAssistant({ question: q, intent, source, ...opts })
        setAnswer(a)
        setQuestion(q)
      } catch (e) {
        setError((e as Error).message)
      } finally {
        setAnswering(false)
      }
    },
    [source, eventIndex, at]
  )

  if (loading && !consoleData && !error) return <div className="loading-block">正在加载共享事实快照与六角色状态…</div>

  const snapshot = consoleData?.snapshot
  const answerStale = !!(answer && snapshot && answer.snapshotId !== snapshot.snapshotId)
  const roles = consoleData?.roles || []
  const messages = consoleData?.messages || []
  const modelStatus = status?.modelStatus
  const replayCount = status?.sources?.replay?.eventCount ?? 0

  return (
    <div className="collab-page">
      <div className="panel">
        <div className="panel-head">
          <h2>共享事实快照与六角色状态</h2>
          <span className="badge badge-info">协作 {status?.collaborationVersion}</span>
          <span className="badge badge-rule">助手 {status?.assistantVersion}</span>
          <span className={`badge ${modelStatus?.configured ? 'badge-warn' : 'badge-rule'}`}>模型：{modelStatus?.mode || 'rule'}{modelStatus?.configured ? '' : '（未配置凭据）'}</span>
        </div>
        <div className="cv-controls">
          <div className="seg">
            {(['execution', 'plan', 'replay'] as const).map((s) => (
              <button
                key={s}
                className={`seg-btn ${source === s ? 'active' : ''}`}
                disabled={s === 'plan' ? !status?.sources?.plan?.available : !status?.sources?.execution?.available}
                onClick={() => {
                  setSource(s)
                  setAt(null)
                  setEventIndex(0)
                }}
              >
                {s === 'execution' ? '当前仿真执行' : s === 'plan' ? '计划预测' : '历史回放'}
              </button>
            ))}
          </div>
          {source === 'replay' && (
            <label className="cv-inline">
              回放节点
              <select className="select compact" value={eventIndex} onChange={(e) => setEventIndex(Number(e.target.value))}>
                <option value={0}>计划基线（事件前）</option>
                {Array.from({ length: replayCount }, (_, i) => (
                  <option key={i + 1} value={i + 1}>
                    事件 {i + 1} 之后（已保存）
                  </option>
                ))}
              </select>
            </label>
          )}
          {source === 'execution' && (
            <label className="cv-inline">
              观察时刻(分钟，只读，不改变会话时钟)
              <input className="input compact" type="number" min={0} step={0.5} value={at ?? ''} placeholder="留空=会话时钟" onChange={(e) => setAt(e.target.value === '' ? null : Number(e.target.value))} />
            </label>
          )}
          <button className="btn btn-mini" onClick={load} disabled={loading}>
            刷新
          </button>
          <a className="btn btn-mini" href={`/api/collab/export?source=${source}${source === 'replay' ? `&eventIndex=${eventIndex}` : at != null ? `&at=${at}` : ''}`} target="_blank" rel="noreferrer">
            导出快照
          </a>
        </div>
        {error && <div className="alert alert-error">{error}</div>}
        {snapshot && (
          <>
            <div className="chips" style={{ marginTop: 8 }}>
              <span className="chip">快照 {snapshot.snapshotId}</span>
              <span className="chip">类型 {snapshot.kind}</span>
              <span className="chip">观察时刻 {snapshot.observationTime == null ? '规划视界' : `${snapshot.observationTime} 分钟`}</span>
              <span className="chip">模型 {snapshot.modelVersion}</span>
              <span className="chip">合同摘要 {snapshot.contractDigest}</span>
              <span className="chip">修订 {snapshot.revision}</span>
              <span className="chip">任务 {snapshot.taskCount} · 已知事件 {snapshot.knownEventCount}</span>
            </div>
            <p className="panel-desc">{snapshot.timeBasis}</p>
            <p className="muted small">
              未知信息：真实库存={snapshot.unknowns?.realInventory}；人员位置={snapshot.unknowns?.personnelLocation}；工厂检测值={snapshot.unknowns?.factoryInspection}
            </p>
          </>
        )}
      </div>

      {snapshot && (
        <div className="agent-grid">
          {roles.map((r: any) => (
            <div className={`agent-card ${r.status === '异常' ? 'accent' : ''}`} key={r.id}>
              <div className="agent-head">
                <div className="agent-code">{r.code}</div>
                <div>
                  <div className="agent-name">{r.name}</div>
                  <div className="agent-role">{r.role}</div>
                </div>
                <span className={`status-pill ${STATUS_CLASS[r.status] || ''}`}>{r.status}</span>
              </div>
              <ul className="agent-iop">
                <li>
                  <b>当前观察</b>：{r.observation}
                </li>
                <li>
                  <b>判断</b>：{r.judgement}
                </li>
                <li>
                  <b>待办/阻塞</b>：{r.todo}
                  {r.blocked.length > 0 && <span className="muted">（{r.blocked.map((b: any) => `${b.key}:${b.reason}`).join('；')}）</span>}
                </li>
                <li>
                  <b>请求/反馈</b>：{r.request}
                </li>
              </ul>
              {r.currentTask && (
                <div className="muted small">
                  当前任务：{r.currentTask.name}（订单 {r.currentTask.order}，{r.currentTask.status}，{r.currentTask.start}→{r.currentTask.end} 分钟）
                </div>
              )}
              <div className="chips">
                {r.evidenceRefs.slice(0, 6).map((ref: any) => (
                  <button className="chip chip-btn" key={ref.ref} onClick={() => setEvidence(ref)}>
                    {ref.type === 'task' ? `${ref.label}·${ref.order}` : ref.type === 'event' ? ref.label : ref.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {evidence && (
        <div className="panel">
          <div className="panel-head">
            <h2>证据详情</h2>
            <button className="btn btn-mini" onClick={() => setEvidence(null)}>
              关闭
            </button>
          </div>
          <table className="data-table">
            <tbody>
              <tr>
                <td>引用</td>
                <td className="mono">{evidence.ref}</td>
              </tr>
              <tr>
                <td>类型</td>
                <td>{evidence.type}</td>
              </tr>
              <tr>
                <td>说明</td>
                <td>{evidence.label}</td>
              </tr>
              {evidence.value != null && (
                <tr>
                  <td>数值</td>
                  <td>
                    {evidence.value} {evidence.unit || ''}
                  </td>
                </tr>
              )}
              <tr>
                <td>时间口径</td>
                <td>{evidence.timeBasis}</td>
              </tr>
              {evidence.start != null && (
                <tr>
                  <td>窗口</td>
                  <td>
                    {evidence.start} → {evidence.end} 分钟（时长 {evidence.duration}）
                  </td>
                </tr>
              )}
              {evidence.checks && (
                <tr>
                  <td>验证项</td>
                  <td className="small">{evidence.checks.join('；')}</td>
                </tr>
              )}
            </tbody>
          </table>
          <p className="muted small">标注：全部为补充模型下的仿真事实；真实库存/人员位置/工厂检测值未采集。</p>
        </div>
      )}

      <div className="panel">
        <div className="panel-head">
          <h2>协作记录（按时间排序）</h2>
          <span className="panel-hint">结构化消息：来源/目标角色、观察时刻、理由代码、证据引用</span>
        </div>
        {messages.length === 0 && <div className="empty small">该快照暂无协作消息</div>}
        <div className="timeline">
          {messages.map((m: any) => (
            <div className="tl-item" key={m.id}>
              <div className="tl-time">{m.time}’</div>
              <div className="tl-dot" />
              <div className="tl-body">
                <div className="tl-head">
                  <span className="tl-from">{m.from}</span>
                  <span className="tl-to">→ {m.to}</span>
                  <span className="tl-type">{m.type}</span>
                  <span className="muted mono small">{m.reasonCode}</span>
                </div>
                <div className="tl-msg">{m.text}</div>
                {m.evidenceRefs?.length > 0 && (
                  <div className="chips">
                    {m.evidenceRefs.map((ref: any) => (
                      <button className="chip chip-btn" key={ref.ref} onClick={() => setEvidence(ref)}>
                        {ref.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>换产助手</h2>
          <span className={`badge ${answer?.mode === 'model' ? 'badge-warn' : answer?.mode === 'fallback' ? 'badge-warn' : 'badge-rule'}`}>模式：{answer?.mode || modelStatus?.mode || 'rule'}</span>
          <span className="panel-hint">{modelStatus?.realCallVerified ? '真实模型调用已验证' : '真实模型调用未验证（规则模式）'}</span>
        </div>
        <div className="chips">
          {QUICK.map((q) => (
            <button className="chip chip-btn" key={q.intent} onClick={() => ask(q.question, q.intent)} disabled={answering}>
              {q.label}
            </button>
          ))}
        </div>
        <div className="cv-ask">
          <input className="input" placeholder="输入问题（支持阻塞/AGV恢复/放行/学习模板四类）" value={question} onChange={(e) => setQuestion(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && ask(question)} />
          <button className="btn btn-primary" onClick={() => ask(question)} disabled={answering || !question.trim()}>
            {answering ? '回答中…' : '提问'}
          </button>
        </div>
        <p className="muted small">未配置模型凭据时保持规则模式；模型只做受限解释，引用必须存在，数值由服务端事实渲染，助手无写权限。</p>
        {answer && (
          <div className="answer-block">
            {answerStale && (
              <div className="alert alert-warn">
                该答案对应旧快照 {answer.snapshotId}，与当前显示快照 {snapshot?.snapshotId} 不一致；旧答案保留其版本标识，请基于当前快照重新提问。
              </div>
            )}
            <div className="chips">
              <span className="chip">answerId {answer.answerId}</span>
              <span className="chip">快照 {answer.snapshotId}</span>
              <span className="chip">意图 {answer.intent}</span>
              <span className="chip">模式 {answer.mode}</span>
            </div>
            <p className="answer-conclusion">{answer.conclusion}</p>
            {answer.claims?.length > 0 && (
              <ul className="bullet">
                {answer.claims.map((c: any, i: number) => (
                  <li key={i}>{c.text}</li>
                ))}
              </ul>
            )}
            {answer.evidenceRefs?.length > 0 && (
              <div className="chips">
                {answer.evidenceRefs.map((ref: any) => (
                  <button className="chip chip-btn" key={ref.ref} onClick={() => setEvidence(ref)}>
                    {ref.label}
                    {ref.value != null ? ` = ${ref.value}${ref.unit || ''}` : ''}
                  </button>
                ))}
              </div>
            )}
            {answer.nextSteps?.length > 0 && <p className="muted">建议下一步：{answer.nextSteps.join('；')}</p>}
            {answer.limitations?.length > 0 && <p className="muted small">已知限制：{answer.limitations.join('；')}</p>}
            {answer.modelInfo && (
              <p className="muted small">
                模型信息：provider={answer.modelInfo.provider} model={answer.modelInfo.model || '—'} used={String(answer.modelInfo.used)} refCheck={answer.modelInfo.refCheck}
                {answer.modelInfo.fallbackReason ? ` 回退原因=${answer.modelInfo.fallbackReason}` : ''}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
