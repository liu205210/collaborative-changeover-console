import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { api } from '../api'
import type { ScheduleEntry, SimEventRecord, SimEventType, SimSession } from '../types'
import DrillGantt from '../components/DrillGantt'

interface Props {
  selected: string[]
}

const EVENT_TYPES: { key: SimEventType; label: string; desc: string }[] = [
  { key: 'agv_delay', label: 'AGV配送延迟', desc: '选择未完成的配送任务并设置延迟分钟数（默认15）' },
  { key: 'person_absence', label: '人员临时缺席', desc: '选择人员与不可用时段，技能约束下重分配未执行工作' },
  { key: 'equipment_failure', label: '设备故障', desc: '选择产线或校准台，设置故障发生与恢复时刻' },
  { key: 'fai_fail', label: '首件检验不合格', desc: '指定订单在检验完成时判定失败，触发返工与复检' }
]

const TYPE_LABEL: Record<string, string> = {
  agv_delay: 'AGV延迟',
  person_absence: '人员缺席',
  equipment_failure: '设备故障',
  fai_fail: '首件不合格'
}

const AGENT_OF_EVENT: Record<string, string[]> = {
  agv_delay: ['material', 'scheduler'],
  person_absence: ['employee', 'scheduler'],
  equipment_failure: ['equipment', 'tooling', 'employee', 'scheduler'],
  fai_fail: ['quality', 'employee', 'scheduler']
}

const AGENT_META: Record<string, { code: string; name: string; role: string }> = {
  scheduler: { code: 'SCH', name: '调度智能体', role: '全局编排与冲突消解' },
  equipment: { code: 'EQP', name: '设备智能体', role: '参数与设备状态' },
  material: { code: 'MAT', name: '物料智能体', role: '物料与配送' },
  tooling: { code: 'TLG', name: '工装智能体', role: '工装与产线在位配置' },
  quality: { code: 'QC', name: '质量智能体', role: '首件检验与质量门禁' },
  employee: { code: 'EMP', name: '人员调度智能体', role: '人员技能与派工' }
}

export default function Drill({ selected }: Props) {
  const [session, setSession] = useState<SimSession | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [eventType, setEventType] = useState<SimEventType>('agv_delay')
  const [target, setTarget] = useState('')
  const [at, setAt] = useState(10)
  const [duration, setDuration] = useState(15)
  const [policy, setPolicy] = useState('finish_current')
  const [redo, setRedo] = useState(false)
  const [injecting, setInjecting] = useState(false)
  const [now, setNow] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [view, setView] = useState<'plan' | 'actual' | 'R0' | 'R1'>('actual')
  const [selectedEventId, setSelectedEventId] = useState<string>('')
  const timer = useRef<number | null>(null)

  useEffect(() => {
    let alive = true
    api
      .simGet()
      .then((s) => {
        if (!alive) return
        setSession(s)
        setSelectedEventId(s.events.length ? s.events[s.events.length - 1].id : '')
      })
      .catch(() => void 0)
      .finally(() => alive && setLoading(false))
    return () => {
      alive = false
    }
  }, [])

  const horizon = useMemo(() => {
    if (!session) return 60
    const ends = session.actualEntries.map((e) => e.end)
    return Math.max(60, ...ends, ...session.basePlan.entries.map((e) => e.end)) + 2
  }, [session])

  useEffect(() => {
    if (!playing) {
      if (timer.current) window.clearInterval(timer.current)
      return
    }
    timer.current = window.setInterval(() => {
      setNow((t) => {
        const n = t + 0.5
        if (n >= horizon) {
          setPlaying(false)
          return horizon
        }
        return n
      })
    }, 100)
    return () => {
      if (timer.current) window.clearInterval(timer.current)
    }
  }, [playing, horizon])

  const initSession = useCallback(async () => {
    if (!selected.length) {
      setError('请先在“换产工作台”选择订单')
      return
    }
    setLoading(true)
    setError(null)
    try {
      const s = await api.simReset(selected)
      setSession(s)
      setNow(0)
      setView('actual')
      setSelectedEventId('')
      setNotice(`已初始化仿真会话（${s.orderIds.length} 个订单，模型 ${s.modelVersion}）`)
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setLoading(false)
    }
  }, [selected])

  const defaultTarget = useCallback(
    (type: SimEventType, s: SimSession) => {
      if (!s) return ''
      if (type === 'agv_delay') {
        const d = s.candidates.deliveries.slice().sort((a, b) => a.start - b.start)[0]
        return d ? d.id : ''
      }
      if (type === 'person_absence') return s.candidates.persons[0]?.id || ''
      if (type === 'equipment_failure') return s.candidates.resources[0]?.id || ''
      return s.candidates.orders[0]?.order || ''
    },
    []
  )

  useEffect(() => {
    if (session) setTarget(defaultTarget(eventType, session))
  }, [eventType, session, defaultTarget])

  const inject = useCallback(async () => {
    if (!session) return
    setInjecting(true)
    setError(null)
    setNotice(null)
    try {
      const ev: any = { type: eventType, target, at, duration }
      if (eventType === 'person_absence') ev.policy = policy
      if (eventType === 'equipment_failure') ev.redo = redo
      const res = await api.simEvent(ev)
      if (res.session) setSession(res.session)
      if (res.applied && res.eventRecord) {
        setSelectedEventId(res.eventRecord.id)
        setView('R1')
        setNotice(`事件已注入并完成重排：${TYPE_LABEL[eventType]} @ ${at} 分钟`)
      } else {
        setError(`事件未生效：${res.reason || '未知原因'}`)
      }
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setInjecting(false)
    }
  }, [session, eventType, target, at, duration, policy, redo])

  const selectedEvent: SimEventRecord | undefined = useMemo(
    () => session?.events.find((e) => e.id === selectedEventId) || session?.events[session.events.length - 1],
    [session, selectedEventId]
  )

  const actualWithStatus = useMemo<ScheduleEntry[]>(() => {
    if (!session) return []
    return session.actualEntries.map((e) => {
      let status = 'pending'
      if (e.end <= now) status = 'done'
      else if (e.start <= now && e.end > now) status = e.kind === 'actual-fragment' ? 'paused' : 'running'
      return { ...e, status }
    })
  }, [session, now])

  const stateCounts = useMemo(() => {
    const c = { done: 0, running: 0, paused: 0, pending: 0, blocked: 0 }
    for (const e of actualWithStatus) {
      if (e.status === 'done') c.done++
      else if (e.status === 'running') c.running++
      else if (e.status === 'paused') c.paused++
      else c.pending++
    }
    return c
  }, [actualWithStatus])

  const viewEntries: ScheduleEntry[] = useMemo(() => {
    if (!session) return []
    if (view === 'plan') return session.basePlan.entries
    if (view === 'actual') return actualWithStatus
    if (!selectedEvent) return []
    const rec = view === 'R0' ? selectedEvent.R0 : selectedEvent.R1
    return selectedEvent.frozen.concat(rec.entries)
  }, [session, view, actualWithStatus, selectedEvent])

  const viewMakespan = useMemo(() => {
    if (view === 'plan') return session?.basePlan.metrics.makespan || horizon
    if (view === 'actual') return session ? Math.max(horizon - 2, ...session.actualEntries.map((e) => e.end)) : horizon
    const rec = view === 'R0' ? selectedEvent?.R0 : selectedEvent?.R1
    return rec ? rec.metrics.makespan : horizon
  }, [view, session, selectedEvent, horizon])

  if (loading && !session) return <div className="loading-block">正在加载仿真会话…</div>

  if (!session) {
    return (
      <div className="panel empty-panel">
        <div className="empty big">
          <div className="empty-title">尚未初始化仿真会话</div>
          <div className="empty-sub">在“换产工作台”选择 2-3 个订单后，点击下方按钮初始化仿真时间轴与执行状态。</div>
          <button className="btn btn-primary" onClick={initSession} disabled={loading}>
            初始化仿真会话（{selected.length} 个订单）
          </button>
        </div>
      </div>
    )
  }

  const evMarkers = session.events.map((e) => ({ at: e.eventTime, type: e.event.type, label: `${TYPE_LABEL[e.event.type]} @ ${e.eventTime}` }))

  return (
    <div className="drill-page">
      {session.stale && (
        <div className="alert alert-warn">
          <span>历史版本会话：{session.staleReason}（历史记录保留，仅供参考）</span>
        </div>
      )}
      <div className="panel">
        <div className="panel-head">
          <h2>仿真时间轴与执行状态</h2>
          <div className="row-actions">
            <span className="badge badge-info">模型 {session.modelVersion}</span>
            <span className="badge badge-rule">规则决策模式</span>
            <button className="btn btn-mini" onClick={initSession}>
              重置会话
            </button>
            <a className="btn btn-mini" href="/api/simulate/export" target="_blank" rel="noreferrer">
              导出 JSON
            </a>
          </div>
        </div>
        <div className="timeline-controls">
          <button className="btn btn-primary btn-mini" onClick={() => setPlaying((p) => !p)}>
            {playing ? '暂停' : '播放'}
          </button>
          <input type="range" min={0} max={horizon} step={0.5} value={now} onChange={(e) => setNow(Number(e.target.value))} className="range" />
          <span className="timeline-time">当前 {now.toFixed(1)} / {horizon.toFixed(0)} 分钟</span>
        </div>
        <div className="state-strip">
          <StatePill label="已完成" value={stateCounts.done} cls="done" />
          <StatePill label="执行中" value={stateCounts.running} cls="running" />
          <StatePill label="暂停" value={stateCounts.paused} cls="paused" />
          <StatePill label="待执行" value={stateCounts.pending} cls="pending" />
          <StatePill label="受阻" value={stateCounts.blocked} cls="blocked" />
        </div>
      </div>

      <div className="grid-drill">
        <div className="panel">
          <div className="panel-head">
            <h2>异常注入</h2>
          </div>
          <div className="form-row">
            <label>事件类型</label>
            <select className="select" value={eventType} onChange={(e) => setEventType(e.target.value as SimEventType)}>
              {EVENT_TYPES.map((t) => (
                <option key={t.key} value={t.key}>
                  {t.label}
                </option>
              ))}
            </select>
          </div>
          <div className="form-hint">{EVENT_TYPES.find((t) => t.key === eventType)?.desc}</div>
          <div className="form-row">
            <label>对象</label>
            <select className="select" value={target} onChange={(e) => setTarget(e.target.value)}>
              {eventType === 'agv_delay' &&
                session.candidates.deliveries.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.order} · 配送 {d.start}→{d.end} 分钟
                  </option>
                ))}
              {eventType === 'person_absence' &&
                session.candidates.persons.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}（{p.skill}）
                  </option>
                ))}
              {eventType === 'equipment_failure' &&
                session.candidates.resources.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              {eventType === 'fai_fail' &&
                session.candidates.orders.map((o) => (
                  <option key={o.order} value={o.order}>
                    {o.order}
                    {o.releasedEnd != null ? `（已于 ${o.releasedEnd} 放行）` : ''}
                  </option>
                ))}
            </select>
          </div>
          <div className="form-row two">
            <div>
              <label>发生时刻(分钟)</label>
              <input className="input" type="number" min={0} step={0.5} value={at} onChange={(e) => setAt(Number(e.target.value))} />
            </div>
            <div>
              <label>{eventType === 'agv_delay' ? '延迟分钟' : eventType === 'fai_fail' ? '（不适用）' : '持续分钟'}</label>
              <input className="input" type="number" min={0} step={1} value={duration} disabled={eventType === 'fai_fail'} onChange={(e) => setDuration(Number(e.target.value))} />
            </div>
          </div>
          {eventType === 'person_absence' && (
            <div className="form-row">
              <label>影响在制任务时</label>
              <select className="select" value={policy} onChange={(e) => setPolicy(e.target.value)}>
                <option value="finish_current">完成当前作业后离岗</option>
                <option value="pause_handoff">暂停并交接</option>
              </select>
            </div>
          )}
          {eventType === 'equipment_failure' && (
            <label className="check-line">
              <input type="checkbox" checked={redo} onChange={(e) => setRedo(e.target.checked)} />
              受影响在制任务重做（默认暂停后续作）
            </label>
          )}
          <button className="btn btn-primary btn-block" onClick={inject} disabled={injecting || !target}>
            {injecting ? '正在重排…' : '注入并重排'}
          </button>
        </div>

        <div className="panel">
          <div className="panel-head">
            <h2>状态快照与产线配置</h2>
            <span className="panel-hint">事件时刻 {selectedEvent ? selectedEvent.eventTime : now} 分钟</span>
          </div>
          {!selectedEvent && <div className="empty small">尚未注入事件</div>}
          {selectedEvent && (
            <>
              <div className="kv-list">
                <div className="kv-row">
                  <span className="k">预约事件时刻</span>
                  <span className="v">{selectedEvent.reserveAt ?? selectedEvent.eventTime} 分钟</span>
                </div>
                <div className="kv-row">
                  <span className="k">实际触发时刻</span>
                  <span className="v">{selectedEvent.triggerAt ?? selectedEvent.eventTime} 分钟（{selectedEvent.timing?.basis}）</span>
                </div>
                <div className="kv-row">
                  <span className="k">重排快照时刻</span>
                  <span className="v">{selectedEvent.snapshotAt ?? selectedEvent.eventTime} 分钟 · 编号 {selectedEvent.sharedSnapshotId}</span>
                </div>
                <div className="kv-row">
                  <span className="k">已执行任务</span>
                  <span className="v">{selectedEvent.snapshot.doneCount} 个</span>
                </div>
                <div className="kv-row">
                  <span className="k">在制任务</span>
                  <span className="v">{selectedEvent.snapshot.running.map((r) => `${r.id}(${r.assigneeName})`).join('、') || '无'}</span>
                </div>
                <div className="kv-row">
                  <span className="k">产线配置</span>
                  <span className="v">{selectedEvent.snapshot.lockProtected}</span>
                </div>
                <div className="kv-row">
                  <span className="k">质量状态</span>
                  <span className="v">{selectedEvent.snapshot.quality.map((q) => `${q.order}:${q.faiStatus}${q.released ? '/已放行' : ''}`).join('，')}</span>
                </div>
              </div>
              <div className="panel-sub">异常处理假设（可查看）</div>
              <ul className="bullet">
                {selectedEvent.assumptions.map((a, i) => (
                  <li key={i}>
                    <b>{a.person || a.resource || a.order}</b>（{a.window}）：{a.policy}
                    <div className="muted">{a.note}</div>
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>排程与恢复甘特图</h2>
          <div className="seg">
            <button className={`seg-btn ${view === 'plan' ? 'active' : ''}`} onClick={() => setView('plan')}>
              原计划（已失效）
            </button>
            <button className={`seg-btn ${view === 'actual' ? 'active' : ''}`} onClick={() => setView('actual')}>
              实际执行
            </button>
            <button className={`seg-btn ${view === 'R0' ? 'active' : ''}`} onClick={() => setView('R0')} disabled={!selectedEvent}>
              固定顺序恢复 R0
            </button>
            <button className={`seg-btn ${view === 'R1' ? 'active' : ''}`} onClick={() => setView('R1')} disabled={!selectedEvent}>
              动态恢复 R1
            </button>
          </div>
        </div>
        <p className="panel-desc">
          {view === 'plan' && '原计划：异常发生前的 C 方案。异常后该计划已失效，仅作历史参照，不作为收益对照基准。'}
          {view === 'actual' && '实际执行：含已完成片段（实色）、暂停片段（虚线）与恢复任务。'}
          {view === 'R0' && '固定顺序恢复：保持原定优先级与顺序，在新约束下进行必要顺延与资源调整。'}
          {view === 'R1' && '动态恢复：与 R0 相同历史、故障、剩余任务、返工、资源与时长下，进行动态优化。'}
        </p>
        <DrillGantt entries={viewEntries} makespan={viewMakespan} events={evMarkers} now={view === 'actual' ? now : undefined} />
      </div>

      {selectedEvent && (
        <div className="panel">
          <div className="panel-head">
            <h2>恢复策略对比（同一执行快照）</h2>
            <select className="select compact" value={selectedEvent.id} onChange={(e) => setSelectedEventId(e.target.value)}>
              {session.events.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.id} · {TYPE_LABEL[e.event.type]} @ {e.eventTime} 分钟
                </option>
              ))}
            </select>
          </div>
          <div className="recover-grid">
            {(['R0', 'R1'] as const).map((k) => {
              const r = selectedEvent[k]
              return (
                <div className={`recover-card ${k === 'R1' ? 'accent' : ''}`} key={k}>
                  <div className="recover-title">{k === 'R0' ? 'R0 · 固定顺序恢复' : 'R1 · 动态恢复'}</div>
                  <div className="recover-metrics">
                    <div>
                      <span className="k">恢复总历时</span>
                      <span className="v">{r.metrics.makespan} 分</span>
                    </div>
                    <div>
                      <span className="k">实际触发后剩余时间</span>
                      <span className="v">{r.metrics.remainingAfterTrigger} 分</span>
                    </div>
                    <div>
                      <span className="k">预约→触发等待</span>
                      <span className="v">{r.metrics.waitReserveToTrigger} 分</span>
                    </div>
                    <div>
                      <span className="k">在线停线合计</span>
                      <span className="v">{r.metrics.onlineStopTotal} 分</span>
                    </div>
                    <div>
                      <span className="k">相对原计划延期</span>
                      <span className="v">+{r.metrics.delayVsOriginal} 分</span>
                    </div>
                    <div>
                      <span className="k">计划调整数量</span>
                      <span className="v">{r.metrics.adjustments} 项</span>
                    </div>
                    <div>
                      <span className="k">验证</span>
                      <span className={`v ${r.validation.ok ? 'ok-text' : 'bad-text'}`}>{r.validation.ok ? '通过' : '未通过'}</span>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
          <div className="compare-summary">
            同一事件快照下：R1 {selectedEvent.R1.metrics.makespan} 分钟，R0 {selectedEvent.R0.metrics.makespan} 分钟，
            差值 {Math.round((selectedEvent.R0.metrics.makespan - selectedEvent.R1.metrics.makespan) * 100) / 100} 分钟。
            该结果为算法实际计算，持平或变差时同样如实展示；不以已失效的原计划作为收益对照。
          </div>
          <div className="check-grid" style={{ marginTop: 12 }}>
            {selectedEvent.R1.validation.checks.map((c) => (
              <div className={`check-card ${c.status}`} key={c.name}>
                <div className="check-head">
                  <span className={`check-badge ${c.status}`}>{c.status === 'pass' ? '通过' : '未通过'}</span>
                  <span className="check-name">{c.name}</span>
                </div>
                <div className="check-detail">{c.detail}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedEvent && <AgentDrill event={selectedEvent} />}

      <div className="panel">
        <div className="panel-head">
          <h2>事件历史（可回放）</h2>
          <span className="panel-hint">共 {session.events.length} 个事件 · 持久化保存</span>
        </div>
        {session.events.length === 0 && <div className="empty small">暂无事件</div>}
        <div className="timeline">
          {session.events.map((e) => (
            <div className="tl-item" key={e.id}>
              <div className="tl-time">{e.eventTime}’</div>
              <div className="tl-dot" />
              <div className="tl-body">
                <div className="tl-head">
                  <span className="tl-from">{TYPE_LABEL[e.event.type]}</span>
                  <span className="tl-to">对象 {e.event.target}</span>
                  <span className="tl-type">R0 {e.R0.metrics.makespan} / R1 {e.R1.metrics.makespan}</span>
                </div>
                <div className="tl-msg">
                  {e.assumptions.map((a) => a.note).join('；') || '已处理'}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function StatePill({ label, value, cls }: { label: string; value: number; cls: string }) {
  return (
    <div className={`state-pill ${cls}`}>
      <span className="state-value">{value}</span>
      <span className="state-label">{label}</span>
    </div>
  )
}

function AgentDrill({ event }: { event: SimEventRecord }) {
  const involved = AGENT_OF_EVENT[event.event.type] || ['scheduler']
  const snapshot = event.snapshot
  const roleNotes: Record<string, { perception: string; judgment: string; action: string; result: string }> = {
    scheduler: {
      perception: `事件 ${TYPE_LABEL[event.event.type]} 发生于 ${event.eventTime} 分钟，已完成 ${snapshot.doneCount} 项，产线配置：${snapshot.lockProtected}`,
      judgment: 'R0（固定顺序）与 R1（动态优化）使用同一执行快照与新约束',
      action: `生成固定顺序恢复 R0 与动态恢复 R1 两套恢复计划，采用 R1 作为后续执行；计划调整 ${event.R1.metrics.adjustments} 项`,
      result: `R1 恢复总历时 ${event.R1.metrics.makespan} 分钟，延期 ${event.R1.metrics.delayVsOriginal} 分钟`
    },
    material: {
      perception: event.event.type === 'agv_delay' ? '配送任务发生延迟，AGV 与物料员占用情况已记录' : '监控物料与配送状态',
      judgment: '受影响配送任务及其下游依赖需要顺延',
      action: '重排物料拣配/配送，保持已完成配送记录不变',
      result: `物料相关恢复任务已排入 R1`
    },
    equipment: {
      perception: event.event.type === 'equipment_failure' ? `资源 ${event.event.target} 进入故障窗口` : '监控设备与参数状态',
      judgment: '故障窗口内不得安排依赖该设备的加工',
      action: '受影响的在制任务保留片段后续作/重做，其余继续',
      result: '恢复计划满足故障窗口约束（验证通过）'
    },
    tooling: {
      perception: '监控产线在位工装与切换状态',
      judgment: '产线在位配置锁定至质量放行，其他订单不得覆盖',
      action: '保持当前订单在线换产链条，重排工装切换',
      result: '产线一致性约束保持成立'
    },
    quality: {
      perception: event.event.type === 'fai_fail' ? `订单 ${event.event.target} 首件检验完成时判定不合格` : '监控首件检验与放行状态',
      judgment: '复检合格前不得放行或恢复生产，产线配置继续受保护',
      action: '排入返工与复检任务，放行依赖复检完成',
      result: '质量门禁约束保持成立（验证通过）'
    },
    employee: {
      perception: event.event.type === 'person_absence' ? `人员 ${event.event.target} 在指定时段不可用` : '跟踪人员可用性与技能匹配',
      judgment: '在技能约束下重分配未执行工作，保留历史执行人',
      action: '重新派工，若影响在制任务按既定策略处理',
      result: '人员分配满足技能约束且无重叠'
    }
  }
  return (
    <div className="panel">
      <div className="panel-head">
        <h2>六类智能体联动</h2>
        <span className="panel-hint">参与本次事件的角色记录动作，未参与角色保持待命</span>
      </div>
      <div className="agent-grid">
        {Object.entries(AGENT_META).map(([id, meta]) => {
          const active = involved.includes(id)
          const note = roleNotes[id]
          return (
            <div className={`agent-card small ${active ? '' : 'standby'}`} key={id}>
              <div className="agent-head">
                <div className="agent-code small">{meta.code}</div>
                <div>
                  <div className="agent-name">{meta.name}</div>
                  <div className="agent-role">{meta.role}</div>
                </div>
                <div className="agent-status">
                  <span className={`status-pill ${active ? 'done' : ''}`}>{active ? '参与' : '待命'}</span>
                </div>
              </div>
              {active ? (
                <ul className="agent-iop">
                  <li>
                    <b>感知</b>：{note.perception}
                  </li>
                  <li>
                    <b>判断</b>：{note.judgment}
                  </li>
                  <li>
                    <b>行动</b>：{note.action}
                  </li>
                  <li>
                    <b>结果</b>：{note.result}
                  </li>
                </ul>
              ) : (
                <div className="empty small">本次事件未涉及该角色，保持待命</div>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}
