import { useCallback, useEffect, useMemo, useState } from 'react'
import { api } from '../api'

const REQ = [
  { key: 'distinctProducts', label: '产品种类', need: 10, unit: '种' },
  { key: 'eventTotal', label: '换产事件', need: 50, unit: '次' },
  { key: 'equipmentTypeCount', label: '设备类型', need: 5, unit: '类' },
  { key: 'distinctMaterials', label: '物料种类', need: 50, unit: '种' },
  { key: 'personnelRoster', label: '操作人员', need: 10, unit: '名' },
  { key: 'eventSpanDays', label: '事件时间跨度', need: 30, unit: '天' }
]

export default function EvaluationCenter() {
  const [simdata, setSimdata] = useState<any>(null)
  const [catalog, setCatalog] = useState<any>(null)
  const [report, setReport] = useState<any>(null)
  const [selectedSets, setSelectedSets] = useState<string[]>(['dev', 'validation'])
  const [selectedCats, setSelectedCats] = useState<string[]>([])
  const [running, setRunning] = useState(false)
  const [progress, setProgress] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let alive = true
    ;(async () => {
      const [sd, cat, rep] = await Promise.allSettled([api.simData(), api.evalCatalog(), api.evalResults()])
      if (!alive) return
      if (sd.status === 'fulfilled') setSimdata(sd.value)
      if (cat.status === 'fulfilled') setCatalog(cat.value)
      if (rep.status === 'fulfilled') setReport(rep.value)
      setLoading(false)
    })()
    return () => {
      alive = false
    }
  }, [])

  const categories = useMemo(() => (catalog ? Object.keys(catalog.categories) : []), [catalog])

  const run = useCallback(async () => {
    setRunning(true)
    setError(null)
    setProgress('正在运行评测（首次可能需要数十秒）…')
    try {
      const rep = await api.evalRun({ sets: selectedSets, categories: selectedCats.length ? selectedCats : undefined })
      setReport(rep)
      setProgress('')
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setRunning(false)
    }
  }, [selectedSets, selectedCats])

  const toggle = (arr: string[], v: string, set: (x: string[]) => void) => set(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v])

  if (loading) return <div className="loading-block">正在加载仿真数据与评测配置…</div>

  const stats = simdata?.stats || {}
  const summary = report?.summary

  return (
    <div className="eval-page">
      <div className="panel">
        <div className="panel-head">
          <h2>仿真数据规模核查表</h2>
          <span className="badge badge-info">模型 {simdata?.modelVersion || '-'}</span>
          <a className="btn btn-mini" href="/api/simdata" target="_blank" rel="noreferrer">
            查看仿真数据层
          </a>
        </div>
        <p className="panel-desc">
          {simdata?.declaration} 原始 Excel 事实（{stats.sourceDataUnchanged?.rows} 行 / {stats.sourceDataUnchanged?.orders} 订单 / {stats.sourceDataUnchanged?.materials} 物料 / 交期 {stats.sourceDataUnchanged?.deliveryDate}）保持不变。
        </p>
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>赛题要求</th>
                <th className="num">要求值</th>
                <th className="num">实际记录</th>
                <th>判定</th>
              </tr>
            </thead>
            <tbody>
              {REQ.map((r) => {
                const actual = stats[r.key]
                const ok = typeof actual === 'number' && actual >= r.need
                return (
                  <tr key={r.key}>
                    <td>{r.label}</td>
                    <td className="num">≥ {r.need} {r.unit}</td>
                    <td className="num strong">{actual != null ? actual : '-'} {r.unit}</td>
                    <td>
                      <span className={`check-badge ${ok ? 'pass' : 'fail'}`}>{ok ? '满足' : '不足'}</span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        <div className="chips" style={{ marginTop: 10 }}>
          <span className="chip">场景 {stats.scenarioCount} 个（验证通过 {stats.scenarioValidatedCount}）</span>
          <span className="chip">总事件 {stats.eventTotal}</span>
          <span className="chip">计划 {stats.eventPlanned}</span>
          <span className="chip">有效已完成 {stats.eventCompleted}</span>
          <span className="chip chip-warn">异常事件 {stats.eventAbnormal}</span>
          <span className="chip">人员 名册{stats.personnelRoster}/可用{stats.personnelAvailableAtZero}/实际{stats.personnelActuallyUsed}</span>
          <span className="chip">设备 库存{stats.equipmentInventoryCount}/实际使用{stats.equipmentActuallyUsed}</span>
          <span className="chip">事件跨度 {stats.eventSpanDays} 天（日历 {stats.spanDays} 天）</span>
          <span className="chip">起始 {simdata?.calendar?.start} → 结束 {simdata?.calendar?.end}</span>
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>批量评测</h2>
          <span className="panel-hint">先固定场景清单与随机种子，再运行</span>
        </div>
        <div className="eval-controls">
          <div className="eval-group">
            <div className="sub-title">评测集</div>
            {['dev', 'validation', 'frozen', 'reserved'].map((s) => (
              <label className="check-line" key={s}>
                <input type="checkbox" checked={selectedSets.includes(s)} onChange={() => toggle(selectedSets, s, setSelectedSets)} />
                {s === 'dev' ? '开发集' : s === 'validation' ? '验证集' : s === 'frozen' ? '冻结集（已使用）' : '保留集（参数定稿后）'}（{catalog?.sets?.[s] ?? 0}）
              </label>
            ))}
          </div>
          <div className="eval-group">
            <div className="sub-title">场景类别（不选=全部）</div>
            <div className="chips">
              {categories.map((c) => (
                <label className={`chip ${selectedCats.includes(c) ? 'chip-active' : ''}`} key={c}>
                  <input type="checkbox" checked={selectedCats.includes(c)} onChange={() => toggle(selectedCats, c, setSelectedCats)} />
                  {c}（{catalog.categories[c]}）
                </label>
              ))}
            </div>
          </div>
          <div className="eval-actions">
            <button className="btn btn-primary" onClick={run} disabled={running}>
              {running ? '评测运行中…' : `启动评测（案例 ${catalog?.caseCount ?? 0}）`}
            </button>
            {report && (
              <>
                <a className="btn btn-mini" href="/api/eval/export.csv" target="_blank" rel="noreferrer">
                  导出 CSV
                </a>
                <a className="btn btn-mini" href="/api/eval/export.json" target="_blank" rel="noreferrer">
                  导出 JSON
                </a>
              </>
            )}
          </div>
        </div>
        {running && <div className="loading-block">{progress}</div>}
        {error && <div className="alert alert-error">{error}</div>}
      </div>

      {report && summary && (
        <>
          <div className="kpi-row">
            <Kpi label="评测案例数" value={report.caseCount} unit="例" />
            <Kpi label="换产实例数" value={report.changeoverInstanceCount} unit="次" />
            <Kpi label="唯一基线数" value={report.uniqueBaselineCount} unit="组" />
            <Kpi label="异常注入数" value={report.anomalyInjectionCount} unit="次" />
            <Kpi label="开发/验证/冻结/保留" value={`${report.sets.dev}/${report.sets.validation}/${report.sets.frozen}/${report.sets.reserved}`} unit="例" />
            <Kpi label="模型版本" value={report.modelVersion} />
            <Kpi label="运行环境" value={report.runtime} />
          </div>
          <div className="panel">
            <div className="panel-head">
              <h2>在线停线取舍</h2>
            </div>
            <p className="muted">
              A 在线停线合计均值 {report.summary.onlineStopComparison?.AtoC?.A ?? '—'} 分钟，C 为 {report.summary.onlineStopComparison?.AtoC?.C ?? '—'} 分钟（Δ {report.summary.onlineStopComparison?.AtoC?.delta ?? '—'}）。
              {report.summary.onlineStopComparison?.note}
            </p>
            <p className="muted">运行集合：{(report.effectiveSets || []).join('、')}；非法集合：{(report.unknownSets || []).join('、') || '无'}；被保护而未运行的保留案例：{(report.excludedReserved || []).length}。</p>
            <p className="muted">
              保留集：当前可用 {catalog?.reservedStatus?.actualReservedCount ?? '—'} 个（已与历史实际使用输入去重，仅生成与检查，不求解）；
              历史已使用保留案例 {catalog?.reservedStatus?.historicalUsedCount ?? 0} 个；退役未使用 {catalog?.reservedStatus?.retiredUnused?.id || '—'}。
              本次是否求解保留集：{report.reservedRun ? '是' : '否'}。
            </p>
          </div>

          <div className="panel">
            <div className="panel-head">
              <h2>分类汇总</h2>
              <span className="panel-hint">可行计划 / 计划总数 · 违规 · 不可行 · 不适用 · 部分 · 性能警戒 · 错误</span>
            </div>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>场景类别</th>
                    <th className="num">案例数</th>
                    <th className="num">可行/总计划</th>
                    <th className="num">有效配对</th>
                    <th className="num">违规</th>
                    <th className="num">不可行</th>
                    <th className="num">不适用</th>
                    <th className="num">部分</th>
                    <th className="num">性能警戒</th>
                    <th className="num">错误</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.byCategory.map((b: any) => (
                    <tr key={b.category}>
                      <td>{b.category}</td>
                      <td className="num">{b.cases}</td>
                      <td className="num">{b.feasiblePlans}/{b.totalPlans}</td>
                      <td className="num">{b.validPairs}</td>
                      <td className="num">{b.violations}</td>
                      <td className="num">{b.infeasible}</td>
                      <td className="num">{b.notApplicable}</td>
                      <td className="num">{b.partial}</td>
                      <td className="num">{b.perfWarn}</td>
                      <td className="num">{b.errors}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid-2">
            <div className="panel">
              <div className="panel-head">
                <h2>静态场景指标（A/B/C）</h2>
                <span className="panel-hint">均值 / 中位数 / P95</span>
              </div>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>指标</th>
                      <th>方案</th>
                      <th className="num">均值</th>
                      <th className="num">中位数</th>
                      <th className="num">P95</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(['makespan', 'onlineStopTotal'] as const).map((mk) =>
                      ['A', 'B', 'C'].map((m) => {
                        const s = summary.metricBlock[mk][m]
                        return (
                          <tr key={mk + m}>
                            <td>{mk === 'makespan' ? '多订单总历时' : '在线停线合计'}</td>
                            <td>{m}</td>
                            <td className="num">{s.mean ?? '-'}</td>
                            <td className="num">{s.median ?? '-'}</td>
                            <td className="num">{s.p95 ?? '-'}</td>
                          </tr>
                        )
                      })
                    )}
                    <tr>
                      <td>重排计算耗时</td>
                      <td>—</td>
                      <td className="num">{summary.metricBlock.computeTimeMs.mean} ms</td>
                      <td className="num">{summary.metricBlock.computeTimeMs.median} ms</td>
                      <td className="num">{summary.metricBlock.computeTimeMs.p95} ms</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            <div className="panel">
              <div className="panel-head">
                <h2>改善统计（仅两方案均可行）</h2>
                <span className="panel-hint">加权改善率与逐案例均值分别标注</span>
              </div>
              <div className="table-wrap">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>对照</th>
                      <th className="num">有效对</th>
                      <th className="num">改善</th>
                      <th className="num">持平</th>
                      <th className="num">变差</th>
                      <th className="num">加权改善率</th>
                      <th className="num">逐案例均值</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(['AtoB', 'BtoC', 'AtoC'] as const).map((k) => {
                      const im = summary.improvement[k]
                      return (
                        <tr key={k}>
                          <td>{k === 'AtoB' ? 'A→B' : k === 'BtoC' ? 'B→C' : 'A→C'}</td>
                          <td className="num">{im.n}</td>
                          <td className="num">{im.improved}</td>
                          <td className="num">{im.tie}</td>
                          <td className="num">{im.worse}</td>
                          <td className="num strong">{im.weightedPct != null ? im.weightedPct + '%' : '-'}</td>
                          <td className="num">{im.perCaseMeanPct != null ? im.perCaseMeanPct + '%' : '-'}</td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
              <div className="chips" style={{ marginTop: 10 }}>
                <span className="chip">R1 采用 R0 回退：{summary.anomaly.r0FallbackCount} 例</span>
                <span className="chip">异常 R1 改善 {summary.anomaly.improved} / 持平 {summary.anomaly.tie} / 变差 {summary.anomaly.worse}</span>
              </div>
            </div>
          </div>

          <div className="panel">
            <div className="panel-head">
              <h2>失败与不可行案例</h2>
              <span className="panel-hint">失败案例保留，不删除、不填 0</span>
            </div>
            {report.cases.filter((c: any) => c.result.status !== 'ok').length === 0 && <div className="empty small">无失败或不可行案例</div>}
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>案例</th>
                    <th>类别</th>
                    <th>状态</th>
                    <th>原因</th>
                  </tr>
                </thead>
                <tbody>
                  {report.cases
                    .filter((c: any) => c.result.status !== 'ok')
                    .map((c: any) => (
                      <tr key={c.id}>
                        <td className="mono">{c.id}</td>
                        <td>{c.category}</td>
                        <td>{c.result.status}</td>
                        <td>{c.result.reason || c.result.failureReason || '—'}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="panel">
            <div className="panel-head">
              <h2>逐案例结果</h2>
              <span className="panel-hint">共 {report.cases.length} 例 · 可导出 CSV/JSON</span>
            </div>
            <div className="table-wrap scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>案例</th>
                    <th>集</th>
                    <th>类别</th>
                    <th>订单数</th>
                    <th className="num">A</th>
                    <th className="num">B</th>
                    <th className="num">C</th>
                    <th className="num">R0</th>
                    <th className="num">R1</th>
                    <th className="num">耗时</th>
                    <th>状态</th>
                  </tr>
                </thead>
                <tbody>
                  {report.cases.map((c: any) => (
                    <tr key={c.id}>
                      <td className="mono">{c.id}</td>
                      <td>{c.set}</td>
                      <td>{c.category}</td>
                      <td className="num">{c.input.orders.length}</td>
                      <td className="num">{c.result.makespan ? c.result.makespan.A : '—'}</td>
                      <td className="num">{c.result.makespan ? c.result.makespan.B : '—'}</td>
                      <td className="num">{c.result.makespan ? c.result.makespan.C : '—'}</td>
                      <td className="num">{c.result.r0Makespan ?? '—'}</td>
                      <td className="num">{c.result.r1Makespan ?? '—'}</td>
                      <td className="num">{c.result.computeTimeMs ?? '—'}</td>
                      <td>{c.result.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="panel panel-oee">
            <div className="panel-head">
              <h2>声明与边界</h2>
            </div>
            <p>{report.declaration}</p>
            <p className="muted">
              搜索上限：{report.searchCap?.strategyC}；{report.searchCap?.recoveryR1}。超时阈值 {report.searchCap?.timeoutThresholdMs} ms。
              启发式解不宣称为全局最优。OEE 继续“待验证”。
            </p>
            <p className="muted">{report.note}</p>
          </div>
        </>
      )}
    </div>
  )
}

function Kpi({ label, value, unit }: { label: string; value: any; unit?: string }) {
  return (
    <div className="kpi">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        {value}
        {unit && <span className="kpi-unit">{unit}</span>}
      </div>
    </div>
  )
}
