import type { DatasetMeta, Plan, StrategyKey } from '../types'
import PlanPlayback from '../components/PlanPlayback'
import './Overview.css'

interface Props {
  meta: DatasetMeta | null
  plan: Plan | null
  mode: StrategyKey
  setMode: (mode: StrategyKey) => void
  navigate: (page: 'workbench' | 'agents' | 'drill' | 'validation') => void
}
const names = { A: '订单串行', B: '提前准备', C: '协同优化' }
const number = (v: number | undefined) => Number.isFinite(v) ? v!.toLocaleString('zh-CN', { maximumFractionDigits: 2 }) : '—'

export default function Overview({ meta, plan, mode, setMode, navigate }: Props) {
  const schedule = plan?.schedules[mode]
  const validation = plan?.validation[mode]
  const maxSpan = Math.max(1, ...(['A', 'B', 'C'] as const).map(k => plan?.schedules[k]?.metrics.makespan || 0))
  const difference = plan ? plan.schedules.A.metrics.makespan - plan.schedules.C.metrics.makespan : 0
  const percent = plan && plan.schedules.A.metrics.makespan > 0 ? difference / plan.schedules.A.metrics.makespan * 100 : null
  const sourceTime = plan?.createdAt || plan?.generatedAt
  return <div className="overview-page">
    <section className="overview-hero">
      <div className="overview-hero-copy">
        <div className="overview-eyebrow"><span /> CHANGEOVER / 协同换产</div>
        <h2>看清等待，<br />让每一步换产有据可循。</h2>
        <p>从订单到放行，把任务、人员与产线条件放进同一份计划。<br className="desktop-break" />沿着时间轴，查看准备如何并行、产线何时锁定。</p>
        <div className="overview-actions">
          <a className="overview-cta" href="#plan-preview">预演当前计划 <span aria-hidden="true">↗</span></a>
          <button onClick={() => navigate('workbench')} className="overview-secondary">选择订单与排程 →</button>
        </div>
        <div className="overview-hero-note">原始 BOM 数据 · 补充仿真工时 · 规则协同</div>
      </div>
      <div className="overview-hero-data">
        <div className="overview-data-label">当前方案 {mode} / {names[mode]}<span>仿真计划</span></div>
        <div className="overview-main-number">{number(schedule?.metrics.makespan)}<small>分钟</small></div>
        <div className="overview-main-caption">多订单总历时</div>
        <div className="overview-data-line"><span>在线停线合计</span><b>{number(schedule?.metrics.onlineStopTotal)} <small>分钟</small></b></div>
        <div className="overview-data-line"><span>离线准备工时</span><b>{number(schedule?.metrics.offlinePrepTotal)} <small>分钟</small></b></div>
        <div className="overview-source">{sourceTime ? `计划生成于 ${sourceTime.replace('T', ' ').replace('Z', ' UTC')}` : '选择订单后生成计划'}<br />不是工厂实时监测；OEE 待验证</div>
      </div>
    </section>
    <section className="overview-stats" aria-label="当前数据范围">
      <div><span>原始订单</span><strong>{number(meta?.orders)}<small>个</small></strong><em>来自导入工作簿</em></div>
      <div><span>当前计划订单</span><strong>{number(plan?.orders.length)}<small>个</small></strong><em>以已生成计划为准</em></div>
      <div><span>计划任务</span><strong>{number(schedule?.entries.length)}<small>项</small></strong><em>准备、换产与质量放行</em></div>
      <div><span>独立校验</span><strong className={validation?.ok ? 'overview-positive' : ''}>{validation ? `${validation.checks.filter(c => c.status === 'pass').length}/${validation.checks.length}` : '—'}<small>项通过</small></strong><em>{validation ? validation.ok ? '当前方案校验通过' : '存在未通过项，查看验证明细' : '尚无验证结果'}</em></div>
    </section>
    <div className="overview-grid">
      <section className="panel overview-comparison">
        <div className="panel-head"><div><div className="overview-kicker">01 / 同条件对照</div><h2>时间花在哪里，改善来自哪里</h2></div><span className="badge badge-rule">同一组订单</span></div>
        {plan ? <>
          <div className="overview-bars">
            {(['A', 'B', 'C'] as const).map(key => <button className={`overview-bar-row ${mode === key ? 'selected' : ''}`} aria-pressed={mode === key} onClick={() => setMode(key)} key={key}>
              <span className="overview-bar-label"><b>{key}</b>{names[key]}</span>
              <span className="overview-bar-track"><span style={{ width: `${plan.schedules[key].metrics.makespan / maxSpan * 100}%` }} /></span>
              <strong>{number(plan.schedules[key].metrics.makespan)}<small>分</small></strong>
            </button>)}
          </div>
          <div className="overview-delta"><span>A → C 多订单总历时</span><b>{difference >= 0 ? '减少' : '增加'} {number(Math.abs(difference))} 分钟{percent != null && <small> / {number(Math.abs(percent))}%</small>}</b></div>
          <p className="overview-footnote">柱长取自实际排程。点击方案可切换下方预演；总历时与在线停线是两个指标，不能互相替代。</p>
        </> : <div className="empty">生成计划后，展示三个方案的实际计算结果。</div>}
      </section>
      <section className="panel overview-rules">
        <div className="overview-kicker">02 / 执行条件</div><h2>先确认可行，再比较快慢</h2>
        <ol><li><b>离线提前准备</b><span>物料、工装与参数方案允许并行准备。</span></li><li><b>在线配置锁定</b><span>从清线开始到恢复生产结束，保持订单一致。</span></li><li><b>质量门禁放行</b><span>检验、质量放行、恢复生产按依赖推进。</span></li></ol>
        <button className="overview-link" onClick={() => navigate('validation')}>查看约束与仿真假设 <span>↗</span></button>
      </section>
    </div>
    <section id="plan-preview" className="overview-preview-anchor">
      {plan ? <PlanPlayback plan={plan} mode={mode} /> : <div className="panel empty"><h2>为你的换产计划按下播放键</h2><p>先到工作台选择订单并生成计划，再按真实任务起止时间预演。</p><button className="btn btn-primary" onClick={() => navigate('workbench')}>前往工作台</button></div>}
    </section>
    <div className="overview-next"><div><span className="overview-kicker">继续探索</span><h3>正常计划之外，看看异常发生以后。</h3><p>异常演练有独立会话与快照，不受上方预演时钟影响。</p></div><div><button className="btn btn-ghost" onClick={() => navigate('agents')}>共享事实与角色</button><button className="btn btn-primary" onClick={() => navigate('drill')}>进入异常演练 →</button></div></div>
  </div>
}
