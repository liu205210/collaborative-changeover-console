import { useCallback, useEffect, useState } from 'react'
import { api } from '../api'

export default function Lab() {
  const [status, setStatus] = useState<any>(null)
  const [busy, setBusy] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      setStatus(await api.labStatus())
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    load()
  }, [load])

  const run = useCallback(
    async (label: string, fn: () => Promise<any>, ok: string) => {
      setBusy(label)
      setError(null)
      setNotice(null)
      try {
        const r = await fn()
        await load()
        setNotice(typeof ok === 'string' ? ok : '完成')
        return r
      } catch (e) {
        setError((e as Error).message)
      } finally {
        setBusy('')
      }
    },
    [load]
  )

  if (loading) return <div className="loading-block">正在加载策略自优化实验室状态…</div>
  if (!status) return <div className="alert alert-error">{error || '实验室状态不可用'}</div>

  const { history, experiment, selection, validation, state, applicability, reserved, effectiveStrategy } = status

  return (
    <div className="eval-page">
      <div className="panel">
        <div className="panel-head">
          <h2>策略自优化实验室</h2>
          <span className="badge badge-info">模型 {status.modelVersion}</span>
          <span className="badge badge-rule">特征 {status.featureVersion}</span>
          <span className="badge badge-rule">参数 {status.paramVersion}</span>
        </div>
        <p className="panel-desc">{status.declaration}</p>
        <p className="muted">
          当前生效策略：<b>{effectiveStrategy}</b>
          {state.activeStrategy === 'C-learned' && !applicability.applicable ? `（模板失效，已回到原策略：${applicability.reason}）` : ''}
          {state.activeTemplateId ? ` · 模板 ${state.activeTemplateId}` : ''}
        </p>
        <div className="eval-actions" style={{ flexWrap: 'wrap', gap: 8 }}>
          <button className="btn btn-mini" onClick={() => run('analyze', api.labAnalyze, '开发历史分析完成')} disabled={!!busy}>
            {busy === 'analyze' ? '分析中…' : '1. 开发历史分析'}
          </button>
          <button className="btn btn-mini" onClick={() => run('experiment', api.labExperiment, '参数实验完成并锁定参数')} disabled={!!busy}>
            {busy === 'experiment' ? '实验中…' : '2. 启动参数实验并锁定'}
          </button>
          <button className="btn btn-mini" onClick={() => run('validate', api.labValidate, '验证对照完成（仅一次）')} disabled={!!busy || !selection}>
            {busy === 'validate' ? '验证中…' : '3. 验证对照（validation）'}
          </button>
          <button className="btn btn-primary" onClick={() => run('activate', api.labActivate, '已启用候选模板')} disabled={!!busy || !validation || !validation.eligibleForActivation}>
            4. 启用候选模板
          </button>
          <button className="btn btn-ghost" onClick={() => run('rollback', api.labRollback, '已回滚到 v4.2.2 原策略 C')} disabled={!!busy}>
            一键回滚原策略
          </button>
          <button className="btn btn-ghost" onClick={() => run('reset', api.labReset, '实验室已重置')} disabled={!!busy}>
            重置新一轮
          </button>
          <a className="btn btn-mini" href="/api/lab/export.json" target="_blank" rel="noreferrer">
            导出 JSON
          </a>
          <a className="btn btn-mini" href="/api/lab/export.csv" target="_blank" rel="noreferrer">
            导出验证 CSV
          </a>
        </div>
        {busy && <div className="loading-block">正在执行：{busy}（真实求解并计入统一使用记录）…</div>}
        {error && <div className="alert alert-error">{error}</div>}
        {notice && <div className="alert alert-ok">{notice}</div>}
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>开发历史与瓶颈分析</h2>
          <span className="panel-hint">来源：{history ? history.source : '尚未运行'}</span>
        </div>
        {!history && <div className="empty small">尚未运行开发历史分析</div>}
        {history && (
          <>
            <div className="chips">
              <span className="chip">开发案例 {history.caseCount} 例</span>
              <span className="chip">关键路径累计 {history.criticalPathTotal} 分钟</span>
              <span className="chip">生成于 {history.generatedAt}</span>
            </div>
            <div className="table-wrap" style={{ marginTop: 10 }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>瓶颈排名</th>
                    <th>工序</th>
                    <th className="num">累计资源等待(分钟)</th>
                    <th className="num">关键路径贡献(分钟)</th>
                    <th className="num">受资源延迟次数</th>
                  </tr>
                </thead>
                <tbody>
                  {history.bottlenecks.map((b: any) => (
                    <tr key={b.key}>
                      <td className="num">{b.rank}</td>
                      <td>{b.name}</td>
                      <td className="num strong">{b.waitTotal}</td>
                      <td className="num">{b.criticalContribution}</td>
                      <td className="num">{b.delayedCount}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="muted">瓶颈依据：对该工序全部离线准备任务的资源等待、时长与关键路径剩余量按 caseId/taskId/资源标识汇总，不使用字符串描述或随机数。</p>
          </>
        )}
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>候选参数与开发集结果</h2>
          <span className="panel-hint">至多 9 组可解释参数 · 原 C 可行的开发案例必须全部可行</span>
        </div>
        {!experiment && <div className="empty small">尚未运行参数实验</div>}
        {experiment && (
          <>
            <p className="muted">{experiment.selectionBasis}</p>
            <p className="muted">{experiment.historyCostNote}</p>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>编号</th>
                    <th>名称</th>
                    <th>含义</th>
                    <th>开发可行</th>
                    <th className="num">可行率</th>
                    <th className="num">总历时之和</th>
                    <th className="num">在线停线合计</th>
                    <th className="num">实际候选次数</th>
                    <th className="num">耗时(ms)</th>
                    <th>选中</th>
                  </tr>
                </thead>
                <tbody>
                  {experiment.candidates.map((c: any) => (
                    <tr key={c.id}>
                      <td className="mono">{c.id}</td>
                      <td>{c.name}</td>
                      <td className="muted small">{c.meaning}</td>
                      <td className="num">{c.feasibleCount}/{c.caseCount}</td>
                      <td className="num">{c.feasibleRate}%</td>
                      <td className="num">{c.sumMakespan}</td>
                      <td className="num">{c.sumOnlineStop}</td>
                      <td className="num">{c.actualAttempts}</td>
                      <td className="num">{c.totalComputeMs}</td>
                      <td>{experiment.selectedId === c.id ? <span className="check-badge pass">选中</span> : c.feasibleOnBaselineCases ? '' : <span className="check-badge fail">不满足</span>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>锁定参数与验证对照</h2>
          <span className="panel-hint">验证集为“已使用的固定验证集”，本轮仅运行一次正式对照</span>
        </div>
        {!selection && <div className="empty small">尚未锁定参数</div>}
        {selection && (
          <p className="muted">
            锁定模板 <b>{selection.templateId}</b>（{selection.name}）· 锁定于 {selection.lockedAt} · 记录 {selection.selectionId}（不可变）· 参数 {JSON.stringify(selection.weights)}
          </p>
        )}
        {validation && (
          <>
            <p className={validation.eligibleForActivation ? 'alert alert-ok' : 'alert alert-warn'}>{validation.conclusion}</p>
            {validation.reasons && validation.reasons.length > 0 && <p className="muted">未通过原因：{validation.reasons.join('；')}</p>}
            <div className="kpi-row">
              <Kpi label="改善/持平/变差" value={`${validation.improvement.improved}/${validation.improvement.tie}/${validation.improvement.worse}`} />
              <Kpi label="有效对/分母" value={`${validation.improvement.n}/${validation.improvement.denominator}`} />
              <Kpi label="加权改善率" value={validation.improvement.weightedPct != null ? validation.improvement.weightedPct + '%' : '—'} />
              <Kpi label="逐案例均值" value={validation.improvement.perCaseMeanPct != null ? validation.improvement.perCaseMeanPct + '%' : '—'} />
              <Kpi label="新增不可行" value={validation.newlyInfeasibleCount} unit="例" />
              <Kpi label="运行时回退" value={validation.usedFallbackCount} unit="例" />
            </div>
            <div className="grid-2">
              <div className="panel">
                <div className="panel-head">
                  <h2>总历时（分钟）</h2>
                </div>
                <div className="table-wrap">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>策略</th>
                        <th className="num">n</th>
                        <th className="num">均值</th>
                        <th className="num">中位数</th>
                        <th className="num">P95</th>
                        <th className="num">合计</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>原 C</td>
                        <td className="num">{validation.makespan.baseline.n}</td>
                        <td className="num">{validation.makespan.baseline.mean}</td>
                        <td className="num">{validation.makespan.baseline.median}</td>
                        <td className="num">{validation.makespan.baseline.p95}</td>
                        <td className="num">{validation.makespan.sumBaseline}</td>
                      </tr>
                      <tr>
                        <td>C-learned</td>
                        <td className="num">{validation.makespan.learned.n}</td>
                        <td className="num">{validation.makespan.learned.mean}</td>
                        <td className="num">{validation.makespan.learned.median}</td>
                        <td className="num">{validation.makespan.learned.p95}</td>
                        <td className="num">{validation.makespan.sumLearned}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div className="panel">
                <div className="panel-head">
                  <h2>在线停线合计（分钟）</h2>
                </div>
                <div className="table-wrap">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>策略</th>
                        <th className="num">n</th>
                        <th className="num">均值</th>
                        <th className="num">中位数</th>
                        <th className="num">P95</th>
                        <th className="num">合计</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>原 C</td>
                        <td className="num">{validation.onlineStop.baseline.n}</td>
                        <td className="num">{validation.onlineStop.baseline.mean}</td>
                        <td className="num">{validation.onlineStop.baseline.median}</td>
                        <td className="num">{validation.onlineStop.baseline.p95}</td>
                        <td className="num">{validation.onlineStop.sumBaseline}</td>
                      </tr>
                      <tr>
                        <td>C-learned</td>
                        <td className="num">{validation.onlineStop.learned.n}</td>
                        <td className="num">{validation.onlineStop.learned.mean}</td>
                        <td className="num">{validation.onlineStop.learned.median}</td>
                        <td className="num">{validation.onlineStop.learned.p95}</td>
                        <td className="num">{validation.onlineStop.sumLearned}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <p className="muted">
              预算：原 C 实际候选尝试 {validation.budget.baselineAttempts} 次 / C-learned {validation.budget.learnedAttempts} 次（相同上限 {validation.budget.baselineMax}）。失败与退化案例保留，不计为 0。
            </p>
            <div className="table-wrap scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>案例</th>
                    <th>类别</th>
                    <th>状态</th>
                    <th className="num">原 C 总历时</th>
                    <th className="num">C-learned 总历时</th>
                    <th className="num">原 C 停线</th>
                    <th className="num">C-learned 停线</th>
                    <th>采用</th>
                    <th>原因</th>
                  </tr>
                </thead>
                <tbody>
                  {validation.cases.map((c: any) => (
                    <tr key={c.id}>
                      <td className="mono">{c.id}</td>
                      <td>{c.category}</td>
                      <td>{c.status}</td>
                      <td className="num">{c.baseline.makespan ?? '—'}</td>
                      <td className="num">{c.learned.makespan ?? '—'}</td>
                      <td className="num">{c.baseline.onlineStopTotal ?? '—'}</td>
                      <td className="num">{c.learned.onlineStopTotal ?? '—'}</td>
                      <td>{c.adopted.source}</td>
                      <td className="muted small">{c.learned.reason || c.baseline.reason || '—'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2>保留集与记账</h2>
        </div>
        <p className="muted">
          当前可用保留案例 {reserved.available} 个、历史已使用 {reserved.historicalUsed} 个、退役未使用 {reserved.retiredUnused?.id}。本轮是否求解保留集：<b>{reserved.solved ? '是' : '否'}</b>。学习/选择接口限定 dev，验证接口限定 validation，禁止绕行求解 reserved。
        </p>
        <p className="muted">候选搜索、验证、失败与回退的真实求解均进入统一使用记录（eval-usage.json），纯筛选不计为执行；默认记账与写入失败处理沿用 v4.2.2 补丁。</p>
      </div>
    </div>
  )
}

function Kpi({ label, value, unit }: { label: string; value: any; unit?: string }) {
  return (
    <div className="kpi">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        {value}
        {unit && <span className="kpi-unit">{unit}</span>}
      </div>
    </div>
  )
}
