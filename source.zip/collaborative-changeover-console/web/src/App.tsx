import { useCallback, useEffect, useMemo, useState } from 'react'
import { api } from './api'
import type { DatasetMeta, OrderSummary, Plan, StrategyKey } from './types'
import Workbench from './pages/Workbench'
import Agents from './pages/Agents'
import Validation from './pages/Validation'
import Drill from './pages/Drill'
import EvaluationCenter from './pages/EvaluationCenter'
import Lab from './pages/Lab'
import Overview from './pages/Overview'
import NavIcon from './components/NavIcon'

type PageKey = 'overview' | 'workbench' | 'agents' | 'drill' | 'eval' | 'lab' | 'validation'

const NAV: { key: PageKey; label: string; desc: string }[] = [
  { key: 'overview', label: '指挥总览', desc: '方案对照 / 计划预演' },
  { key: 'workbench', label: '换产工作台', desc: '订单 / 物料 / 排程 / 甘特图' },
  { key: 'agents', label: '智能体协同', desc: '六类角色状态与协作记录' },
  { key: 'drill', label: '异常演练', desc: '异常注入 / 时间轴 / R0R1 恢复' },
  { key: 'eval', label: '评测中心', desc: '仿真数据 / 批量评测 / 汇总' },
  { key: 'lab', label: '自优化实验室', desc: '历史分析 / 参数选择 / 验证 / 回滚' },
  { key: 'validation', label: '数据与验证', desc: '导入数据 / 仿真假设 / 约束校验' }
]

const SELECTION_KEY = 'ccc.selection.v1'

export default function App() {
  const [page, setPage] = useState<PageKey>('overview')
  const [meta, setMeta] = useState<DatasetMeta | null>(null)
  const [orders, setOrders] = useState<OrderSummary[]>([])
  const [selected, setSelected] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(SELECTION_KEY)
      return raw ? (JSON.parse(raw) as string[]) : []
    } catch {
      return []
    }
  })
  const [plan, setPlan] = useState<Plan | null>(null)
  const [mode, setMode] = useState<StrategyKey>('C')
  const [loadingData, setLoadingData] = useState(true)
  const [generating, setGenerating] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [notice, setNotice] = useState<string | null>(null)
  const navigate = useCallback((next: PageKey) => {
    setPage(next)
    window.scrollTo({ top: 0, behavior: 'instant' })
  }, [])

  useEffect(() => {
    let alive = true
    ;(async () => {
      try {
        const [ds, last] = await Promise.allSettled([api.dataset(), api.lastPlan()])
        if (!alive) return
        if (ds.status === 'fulfilled') {
          setMeta(ds.value.meta)
          setOrders(ds.value.orders)
        } else {
          setError((ds.reason as Error).message)
        }
        if (last.status === 'fulfilled') {
          setPlan(last.value)
          setSelected(last.value.orderIds)
        }
      } catch (e) {
        if (alive) setError((e as Error).message)
      } finally {
        if (alive) setLoadingData(false)
      }
    })()
    return () => {
      alive = false
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(SELECTION_KEY, JSON.stringify(selected))
    } catch {
      /* ignore */
    }
  }, [selected])

  const orderMap = useMemo(() => new Map(orders.map((o) => [o.order, o])), [orders])

  const createPlan = useCallback(async () => {
    if (!selected.length) {
      setError('请至少选择一个订单后再生成换产计划')
      return
    }
    setGenerating(true)
    setError(null)
    setNotice(null)
    try {
      const p = await api.createPlan(selected)
      setPlan(p)
      setNotice(`已生成 ${p.orders.length} 个订单的三套排程方案（A/B/C）`)
      setPage('workbench')
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setGenerating(false)
    }
  }, [selected])

  const reimport = useCallback(async () => {
    setLoadingData(true)
    setError(null)
    try {
      const r = await api.reimport()
      const ds = await api.dataset()
      setMeta(ds.meta)
      setOrders(ds.orders)
      setNotice(`数据重新导入成功，共 ${r.orderCount} 个订单`)
    } catch (e) {
      setError((e as Error).message)
    } finally {
      setLoadingData(false)
    }
  }, [])

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">协同</div>
          <div className="brand-text">
            <div className="brand-overline">CHANGEOVER / 01</div>
            <div className="brand-title">协同换产指挥台</div>
            <div className="brand-sub">多智能体协同 · 高效换产</div>
          </div>
        </div>
        <div className="nav-section-label">工作空间 / WORKSPACE</div>
        <nav className="nav" aria-label="主要功能">
          {NAV.map((item) => (
            <button key={item.key} className={`nav-item ${page === item.key ? 'active' : ''}`} aria-current={page === item.key ? 'page' : undefined} onClick={() => navigate(item.key)}>
              <span className="nav-icon"><NavIcon name={item.key} /></span>
              <span className="nav-copy"><span className="nav-label">{item.label}</span><span className="nav-desc">{item.desc}</span></span>
            </button>
          ))}
        </nav>
        <div className="sidebar-foot">
          <div className="badge badge-rule">规则决策模式</div>
          <div className="foot-note">默认规则模式 · 可选模型仅选择经核验结论，真实模型调用未验证</div>
          <div className="foot-note">赛题：基于多智能体协同的高效换产</div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="topbar-eyebrow">协同换产 / {String(NAV.findIndex(n => n.key === page) + 1).padStart(2, '0')}</div>
            <h1>{NAV.find((n) => n.key === page)?.label}</h1>
            <div className="topbar-sub">
              {meta ? (
                <>
                  <span>数据源：{meta.sourceFile}</span>
                  <span className="dot" />
                  <span>{meta.dataRows} 行 / {meta.orders} 订单 / {meta.materials} 物料</span>
                </>
              ) : (
                <span>数据加载中…</span>
              )}
            </div>
          </div>
          <div className="topbar-right">
            {page === 'workbench' && <span className="badge badge-info">待排选择 {selected.length} 个订单</span>}
            <span className="badge badge-warn" title="缺少生产工时、产出与良率数据">OEE 待验证</span>
            {page === 'validation' && <button className="btn btn-ghost" onClick={reimport} disabled={loadingData}>
              重新导入数据
            </button>}
            {page === 'workbench' ? <button className="btn btn-primary" onClick={createPlan} disabled={generating || !selected.length}>
              {generating ? '正在计算排程…' : '生成换产计划'}
            </button> : <button className="btn btn-primary" onClick={() => navigate('workbench')}>打开排程工作台 ↗</button>}
          </div>
        </header>

        {error && (
          <div className="alert alert-error">
            <span>{error}</span>
            <button className="alert-close" onClick={() => setError(null)}>
              关闭
            </button>
          </div>
        )}
        {notice && (
          <div className="alert alert-ok">
            <span>{notice}</span>
            <button className="alert-close" onClick={() => setNotice(null)}>
              关闭
            </button>
          </div>
        )}
        {plan?.stale && (
          <div className="alert alert-warn">
            <span>
              首页计划为历史版本：{plan.staleReason}
            </span>
            <button className="btn btn-mini" onClick={createPlan} disabled={generating}>
              用当前模型重新生成
            </button>
          </div>
        )}

        <div className="content">
          <div className="context-strip"><span>真实 BOM 导入 · 补充仿真模型</span><span>{(page === 'overview' || page === 'workbench') && plan ? `当前计划 ${plan.orders.length} 个订单 / 方案 ${mode} · ${plan.modelVersion || '版本未提供'}` : '各模块以自己的数据版本与观察时刻为准'}</span></div>
          {page === 'overview' && <Overview meta={meta} plan={plan} mode={mode} setMode={setMode} navigate={navigate} />}
          {page === 'workbench' && (
            <Workbench
              orders={orders}
              orderMap={orderMap}
              selected={selected}
              setSelected={setSelected}
              plan={plan}
              mode={mode}
              setMode={setMode}
              generating={generating}
              loadingData={loadingData}
              onCreatePlan={createPlan}
            />
          )}
          {page === 'agents' && <Agents plan={plan} mode={mode} setMode={setMode} />}
          {page === 'drill' && <Drill selected={selected} />}
          {page === 'eval' && <EvaluationCenter />}
          {page === 'lab' && <Lab />}
          {page === 'validation' && <Validation meta={meta} plan={plan} mode={mode} setMode={setMode} />}
        </div>
      </main>
    </div>
  )
}
