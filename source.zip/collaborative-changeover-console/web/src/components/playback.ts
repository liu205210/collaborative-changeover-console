import type { OrderMetric, ScheduleEntry } from '../types'

export type PlaybackTaskState = 'pending' | 'running' | 'done'
export type PlaybackEntry = ScheduleEntry & { equipment?: string | null }

/** Playback is a local projection of a saved plan; it never represents actual execution. */
export function isValidPlaybackEntry(entry: ScheduleEntry): boolean {
  return Number.isFinite(entry.start) && Number.isFinite(entry.end) && entry.start >= 0 && entry.end >= entry.start
}

export function playbackTaskState(entry: Pick<ScheduleEntry, 'start' | 'end'>, at: number): PlaybackTaskState {
  if (entry.end <= at) return 'done'
  if (entry.start <= at && at < entry.end) return 'running'
  return 'pending'
}

export function playbackDuration(entries: ScheduleEntry[], makespan: number): number {
  return entries.reduce((end, entry) => Math.max(end, entry.end), Number.isFinite(makespan) ? Math.max(0, makespan) : 0)
}

export function clampPlaybackTime(at: number, duration: number): number {
  return Math.min(Math.max(0, Number.isFinite(duration) ? duration : 0), Math.max(0, Number.isFinite(at) ? at : 0))
}

export function displayedPlaybackTime(at: number, duration: number): number {
  return Math.floor((clampPlaybackTime(at, duration) + 1e-9) * 100) / 100
}

export function validLineWindows(windows: OrderMetric[]): OrderMetric[] {
  return windows.filter(window => Number.isFinite(window.onlineStart) && Number.isFinite(window.onlineEnd)
    && window.onlineStart >= 0 && window.onlineEnd > window.onlineStart)
    .slice().sort((a, b) => a.onlineStart - b.onlineStart || a.order.localeCompare(b.order))
}

export function activeLineWindows(windows: OrderMetric[], at: number): OrderMetric[] {
  return windows.filter(window => window.onlineStart <= at && at < window.onlineEnd)
}

export function playbackBoundaries(entries: ScheduleEntry[], windows: OrderMetric[], duration: number): number[] {
  return [...new Set([0, duration, ...entries.flatMap(entry => [entry.start, entry.end]),
    ...windows.flatMap(window => [window.onlineStart, window.onlineEnd])])]
    .filter(value => Number.isFinite(value) && value >= 0 && value <= duration).sort((a, b) => a - b)
}

export function adjacentPlaybackBoundary(boundaries: number[], at: number, direction: -1 | 1): number {
  if (direction === 1) return boundaries.find(boundary => boundary > at + 0.000001) ?? boundaries[boundaries.length - 1] ?? 0
  for (let index = boundaries.length - 1; index >= 0; index -= 1) {
    if (boundaries[index] < at - 0.000001) return boundaries[index]
  }
  return boundaries[0] ?? 0
}

export function derivePlayback(entries: PlaybackEntry[], windows: OrderMetric[], at: number) {
  const done: PlaybackEntry[] = []
  const running: PlaybackEntry[] = []
  const pending: PlaybackEntry[] = []
  for (const entry of entries) {
    const state = playbackTaskState(entry, at)
    if (state === 'done') done.push(entry)
    else if (state === 'running') running.push(entry)
    else pending.push(entry)
  }
  const assignees = new Map<string, string>()
  for (const entry of running) {
    if (entry.assigneeId) assignees.set(entry.assigneeId, entry.assigneeName || entry.assigneeId)
  }
  return { done, running, pending, assignees, locked: activeLineWindows(windows, at) }
}

export function pendingPlaybackReason(entry: ScheduleEntry, entriesById: Map<string, ScheduleEntry>, at: number): string {
  const prerequisites = (entry.deps || []).map(id => entriesById.get(id))
  if (prerequisites.some(prerequisite => !prerequisite)) return '前序记录未提供'
  if (prerequisites.some(prerequisite => prerequisite!.end > at)) return '前序未完成'
  return '按计划等待开始'
}

export function playbackEntryResources(entry: PlaybackEntry): string[] {
  return [...new Set([entry.exclusive, entry.equipment].filter((value): value is string => typeof value === 'string' && value.length > 0))]
}
