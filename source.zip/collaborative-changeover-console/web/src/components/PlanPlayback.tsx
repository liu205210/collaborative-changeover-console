import { useEffect, useMemo, useState } from 'react'
import type { Plan, ScheduleEntry, StrategyKey } from '../types'
import {
  adjacentPlaybackBoundary, clampPlaybackTime, displayedPlaybackTime, derivePlayback, isValidPlaybackEntry,
  pendingPlaybackReason, playbackBoundaries, playbackDuration, playbackEntryResources,
  playbackTaskState, validLineWindows
} from './playback'
import type { PlaybackEntry } from './playback'
import './PlanPlayback.css'

const ROLES = [
  { id: 'dispatch', name: '调度', code: 'SC', description: '全局任务与上线节奏', accepts: (_entry: ScheduleEntry) => true },
  { id: 'material', name: '物料', code: 'MT', description: '拣配与线边配送', accepts: (entry: ScheduleEntry) => entry.skill === 'material' },
  { id: 'tooling', name: '工装', code: 'TL', description: '工装人员准备任务', accepts: (entry: ScheduleEntry) => entry.skill === 'tooling' },
  { id: 'equipment', name: '设备', code: 'EQ', description: '设备人员执行任务', accepts: (entry: ScheduleEntry) => entry.skill === 'equipment' },
  { id: 'quality', name: '质量', code: 'QC', description: '检验与质量放行', accepts: (entry: ScheduleEntry) => entry.skill === 'quality' },
  { id: 'personnel', name: '人员', code: 'PE', description: '全部已分配人员', accepts: (entry: ScheduleEntry) => Boolean(entry.assigneeId) }
]

const formatTime = (value: number) => value.toFixed(2)

function Arrow({ reverse = false }: { reverse?: boolean }) {
  return <svg viewBox="0 0 20 20" width="17" height="17" aria-hidden="true" style={reverse ? { transform: 'rotate(180deg)' } : undefined}>
    <path d="M5 4v12l8-6zM15 4v12" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
  </svg>
}

export default function PlanPlayback({ plan, mode }: { plan: Plan; mode: StrategyKey }) {
  const schedule = plan?.schedules?.[mode]
  const rawEntries = schedule?.entries || []
  const entries = useMemo(() => rawEntries.filter(isValidPlaybackEntry).slice()
    .sort((a, b) => a.start - b.start || a.id.localeCompare(b.id)) as PlaybackEntry[], [rawEntries])
  const windows = useMemo(() => validLineWindows(schedule?.metrics?.orderMetrics || []), [schedule?.metrics?.orderMetrics])
  const duration = useMemo(() => playbackDuration(entries, schedule?.metrics?.makespan || 0), [entries, schedule?.metrics?.makespan])
  const boundaries = useMemo(() => playbackBoundaries(entries, windows, duration), [entries, windows, duration])
  const entriesById = useMemo(() => new Map(entries.map(entry => [entry.id, entry])), [entries])
  const [at, setAt] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [speed, setSpeed] = useState(1)
  const [reducedMotion, setReducedMotion] = useState(() => typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  // Display and all derived states share the same 0.01-minute clock, never round into a future boundary.
  const current = displayedPlaybackTime(at, duration)
  const state = useMemo(() => derivePlayback(entries, windows, current), [entries, windows, current])
  const progress = duration > 0 ? current / duration * 100 : 0
  const canPlay = entries.length > 0 && duration > 0

  useEffect(() => { setAt(0); setPlaying(false) }, [plan, mode])

  useEffect(() => {
    const query = window.matchMedia('(prefers-reduced-motion: reduce)')
    const onChange = () => { setReducedMotion(query.matches); if (query.matches) setPlaying(false) }
    query.addEventListener('change', onChange)
    return () => query.removeEventListener('change', onChange)
  }, [])

  useEffect(() => {
    if (!playing || !canPlay) return
    let previous: number | undefined
    let frame = 0
    const tick = (now: number) => {
      if (previous !== undefined) {
        const minutes = (now - previous) / 1000 * speed
        setAt(value => clampPlaybackTime(value + minutes, duration))
      }
      previous = now
      frame = window.requestAnimationFrame(tick)
    }
    frame = window.requestAnimationFrame(tick)
    return () => window.cancelAnimationFrame(frame)
  }, [playing, canPlay, duration, speed])

  useEffect(() => { if (current >= duration) setPlaying(false) }, [current, duration])

  function seek(value: number) {
    setPlaying(false)
    setAt(clampPlaybackTime(value, duration))
  }

  function togglePlay() {
    if (!canPlay) return
    if (playing) setPlaying(false)
    else { if (current >= duration) setAt(0); setPlaying(true) }
  }

  return <section className="plan-playback" aria-label="换产计划预演">
    <div className="pp-heading">
      <div><span className="pp-eyebrow">PLAN REPLAY</span><h2>看见每一步如何衔接</h2><p>沿真实排程时间推进，观察任务、人员与产线占用。</p></div>
      <span className="pp-simulation-badge"><span />计划预演 · 非现场实时</span>
    </div>

    <div className="pp-stage">
      <div className="pp-clock-row">
        <div className="pp-clock"><span className="pp-clock-label">方案 {mode} · 计划时刻</span><div><strong>{formatTime(current)}</strong><span> / {formatTime(duration)} 分钟</span></div></div>
        <div className="pp-counters" aria-label="当前计划任务状态">
          <div><span className="pp-counter-label"><i className="pp-dot done" />已完成</span><strong>{state.done.length}<small>项</small></strong></div>
          <div><span className="pp-counter-label"><i className="pp-dot running" />进行中</span><strong>{state.running.length}<small>项</small></strong></div>
          <div><span className="pp-counter-label"><i className="pp-dot pending" />待开始</span><strong>{state.pending.length}<small>项</small></strong></div>
        </div>
      </div>

      <div className="pp-timeline">
        <div className="pp-timeline-caption"><span>{playing ? '正在预演' : current >= duration && canPlay ? '已到计划终点' : '预演已暂停'}</span><span>时间进度 {Math.round(progress)}%</span></div>
        <input aria-label="计划预演时刻（分钟）" aria-valuetext={`${formatTime(current)} 分钟`} className="pp-range" type="range" min={0} max={duration || 1} step="0.01" value={current} disabled={!canPlay} onChange={event => seek(Number(event.target.value))} style={{ background: `linear-gradient(to right, #63dfc1 0%, #63dfc1 ${progress}%, #40514c ${progress}%, #40514c 100%)` }} />
        <div className="pp-timeline-ticks"><span>0.00</span><span>{formatTime(duration / 2)}</span><span>{formatTime(duration)} min</span></div>
      </div>

      <div className="pp-controls">
        <div className="pp-control-buttons">
          <button type="button" className="pp-play-button" onClick={togglePlay} disabled={!canPlay} aria-label={playing ? '暂停计划预演' : '播放计划预演'}><span aria-hidden="true">{playing ? 'Ⅱ' : '▶'}</span>{playing ? '暂停' : current >= duration && canPlay ? '重新播放' : '播放预演'}</button>
          <button type="button" className="pp-step-button" onClick={() => seek(adjacentPlaybackBoundary(boundaries, current, -1))} disabled={!canPlay || current <= 0} title="跳到上一个任务或产线边界" aria-label="上一个时间边界"><Arrow reverse /></button>
          <button type="button" className="pp-step-button" onClick={() => seek(adjacentPlaybackBoundary(boundaries, current, 1))} disabled={!canPlay || current >= duration} title="跳到下一个任务或产线边界" aria-label="下一个时间边界"><Arrow /></button>
          <button type="button" className="pp-reset-button" onClick={() => seek(0)} disabled={!canPlay}>回到起点</button>
        </div>
        <div className="pp-speed"><label htmlFor="plan-playback-speed">播放速度</label><select id="plan-playback-speed" value={speed} onChange={event => setSpeed(Number(event.target.value))}><option value={0.5}>0.5×</option><option value={1}>1×</option><option value={2}>2×</option></select><span>1× = 每秒推进 1 仿真分钟</span></div>
      </div>
    </div>

    {!entries.length ? <div className="pp-empty">当前方案暂无可预演任务。生成有效换产计划后，可在此查看时间进程。</div> : <>
      <div className="pp-line-status">
        <div className="pp-line-copy"><span className="pp-eyebrow">LINE WINDOW</span><h3>{state.locked.length ? '产线在位配置已锁定' : '当前无订单占线窗口'}</h3><p>{state.locked.length ? state.locked.map(window => `订单 ${window.order} · ${formatTime(window.onlineStart)}—${formatTime(window.onlineEnd)} 分钟`).join('；') : '以下色带来自计划的在线停线窗口。'}</p></div>
        <div className="pp-person-count"><strong>{state.assignees.size}</strong><span>计划当前占用人员</span><small>按执行人 ID 去重</small></div>
      </div>
      <div className="pp-line-track" aria-label="产线订单锁定时间带">
        {windows.map((window, index) => {
          const active = window.onlineStart <= current && current < window.onlineEnd
          return <button type="button" key={`${window.order}-${index}`} className={`pp-line-window ${active ? 'is-active' : ''} ${window.onlineEnd <= current ? 'is-done' : ''}`} style={{ left: `${Math.min(100, window.onlineStart / (duration || 1) * 100)}%`, width: `${Math.max(0, Math.min(window.onlineEnd, duration) - window.onlineStart) / (duration || 1) * 100}%` }} onClick={() => seek(window.onlineStart)} title={`订单 ${window.order}：${formatTime(window.onlineStart)}—${formatTime(window.onlineEnd)} 分钟；点击跳到开始`} aria-label={`跳到订单 ${window.order} 的在线停线开始 ${formatTime(window.onlineStart)} 分钟`}><span>{window.order}</span></button>
        })}
        <div className="pp-line-playhead" style={{ left: `${progress}%` }} aria-hidden="true" />
      </div>
      <p className="pp-line-note">锁定从清线开始持续至恢复生产结束，包含检验、放行与期间等待；不代表设备正在连续加工。</p>

      <div className="pp-role-heading"><h3>六个协作视角</h3><span>由计划条目推演 · 非后端执行状态</span></div>
      <div className="pp-roles">
        {ROLES.map(role => {
          const roleEntries = entries.filter(role.accepts)
          const active = roleEntries.filter(entry => playbackTaskState(entry, current) === 'running')
          const pending = roleEntries.filter(entry => playbackTaskState(entry, current) === 'pending')
          const done = roleEntries.length - active.length - pending.length
          const status = active.length ? 'running' : pending.length ? 'pending' : roleEntries.length ? 'done' : 'empty'
          const statusText = active.length ? '进行中' : pending.length ? '待开始' : roleEntries.length ? '已完成' : '无任务'
          const visible = (active.length ? active : pending).slice(0, 2)
          const additional = (active.length ? active.length : pending.length) - visible.length
          return <article className={`pp-role-card pp-role-${status}`} key={role.id}>
            <div className="pp-role-top"><span className="pp-role-icon">{role.code}</span><div><h4>{role.name}</h4><p>{role.description}</p></div><span className={`pp-state-pill ${status}`}>{statusText}</span></div>
            <div className="pp-role-progress"><span>已完成 {done} / {roleEntries.length}</span><span>{active.length ? `${active.length} 项进行中` : `${pending.length} 项待开始`}</span></div>
            <div className="pp-role-meter"><span style={{ width: `${roleEntries.length ? done / roleEntries.length * 100 : 0}%` }} /></div>
            <div className="pp-role-tasks">
              {visible.length > 0 ? visible.map(entry => <div className="pp-task" key={entry.id}>
                <div className="pp-task-name"><strong>{entry.name}</strong><span>{formatTime(entry.start)}—{formatTime(entry.end)}</span></div>
                <p>订单 {entry.order} · {entry.assigneeName || entry.assigneeId || '执行人未提供'}</p>
                <div className="pp-task-resource">{active.length ? '资源' : pendingPlaybackReason(entry, entriesById, current)}{active.length ? `：${playbackEntryResources(entry).join(' / ') || '未指定独占资源'}` : ''}</div>
              </div>) : <p className="pp-role-empty">{roleEntries.length ? '该视角的计划任务均已完成。' : '此方案没有对应任务记录。'}</p>}
              {additional > 0 && <span className="pp-more">另有 {additional} 项{active.length ? '进行中' : '待开始'}任务</span>}
            </div>
          </article>
        })}
      </div>
    </>}
    <div className="pp-footnote"><span>仅在本地浏览已保存计划，不求解、不改变仿真会话时钟。调度与人员为汇总视角，卡片间任务可重复。</span>{reducedMotion && <span>已遵循减少动态效果设置，可手动逐边界查看。</span>}{rawEntries.length !== entries.length && <span>有 {rawEntries.length - entries.length} 条无效时间记录未参与预演。</span>}</div>
  </section>
}
