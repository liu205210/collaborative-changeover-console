import type { ScheduleEntry } from '../types'

const PHASE_COLORS: Record<string, string> = {
  物料准备与配送: '#2f7ff0',
  工装准备与切换: '#13b5a2',
  设备参数准备与校准: '#7a5af0',
  首件检验与质量放行: '#e08a1e'
}

const STATUS_STYLE: Record<string, { opacity: number; border?: string }> = {
  done: { opacity: 1 },
  running: { opacity: 0.9, border: '2px solid #0b2a55' },
  paused: { opacity: 0.45, border: '2px dashed #b3382f' },
  pending: { opacity: 0.35 }
}

export interface DrillEventMarker {
  at: number
  type: string
  label: string
}

interface Props {
  entries: ScheduleEntry[]
  makespan: number
  events?: DrillEventMarker[]
  now?: number
  dimPending?: boolean
}

const TYPE_LABEL: Record<string, string> = {
  agv_delay: 'AGV延迟',
  person_absence: '人员缺席',
  equipment_failure: '设备故障',
  fai_fail: '首件不合格'
}

export default function DrillGantt({ entries, makespan, events = [], now, dimPending }: Props) {
  const total = Math.max(makespan, 1)
  if (!entries.length) return <div className="empty">暂无数据</div>
  const orders = Array.from(new Set(entries.map((e) => e.order)))

  const statusOf = (e: ScheduleEntry) => {
    if ((e as any).status) return (e as any).status
    if (now == null) return ''
    if (e.end <= now) return 'done'
    if (e.start <= now && e.end > now) return (e as any).kind === 'actual-fragment' ? 'paused' : 'running'
    return 'pending'
  }

  return (
    <div className="gantt">
      <div className="gantt-axis">
        <div className="gantt-axis-label">订单 / 任务 · 时间(分钟)</div>
        <div className="gantt-axis-track">
          {ticks(total).map((t) => (
            <div key={t} className="gantt-tick" style={{ left: `${(t / total) * 100}%` }}>
              <span>{t}</span>
            </div>
          ))}
        </div>
      </div>
      {orders.map((order) => (
        <div className="gantt-group" key={order}>
          <div className="gantt-order-head">
            <span className="gantt-order-id">订单 {order}</span>
            <span className="gantt-order-meta">{entries.filter((e) => e.order === order).length} 个任务</span>
          </div>
          {entries
            .filter((e) => e.order === order)
            .sort((a, b) => a.start - b.start)
            .map((e) => {
              const st = statusOf(e)
              const style = STATUS_STYLE[st] || { opacity: 0.7 }
              const color = PHASE_COLORS[e.phase] || '#5b6b82'
              const isRework = (e as any).kind === 'rework' || (e as any).kind === 'recheck'
              return (
                <div className="gantt-row" key={e.id}>
                  <div className="gantt-row-label" title={`${e.name} · ${e.skillLabel}`}>
                    <span className="gantt-task-name">
                      {e.name}
                      {isRework ? ' ⟲' : ''}
                    </span>
                    <span className="gantt-task-skill">{e.assigneeName}</span>
                  </div>
                  <div className="gantt-track">
                    {ticks(total).map((t) => (
                      <div key={t} className="gantt-gridline" style={{ left: `${(t / total) * 100}%` }} />
                    ))}
                    {events.map((ev, i) => (
                      <div key={i} className="event-marker" style={{ left: `${(ev.at / total) * 100}%` }} title={`${TYPE_LABEL[ev.type] || ev.type} @ ${ev.at}`}>
                        <span>{TYPE_LABEL[ev.type] || ev.type}</span>
                      </div>
                    ))}
                    {now != null && <div className="now-line" style={{ left: `${(now / total) * 100}%` }} />}
                    <div
                      className="gantt-bar"
                      style={{
                        left: `${(e.start / total) * 100}%`,
                        width: `${Math.max((e.duration / total) * 100, 1.2)}%`,
                        background: isRework ? '#d64545' : color,
                        opacity: style.opacity,
                        border: style.border
                      }}
                      title={`${e.name} · 订单 ${e.order}\n计划 ${e.start} → ${e.end} 分钟\n执行人：${e.assigneeName}\n资源：${e.exclusive || '常规'}${st ? `\n状态：${st}` : ''}`}
                    >
                      <span className="gantt-bar-text">
                        {e.duration}m
                        {st === 'running' ? ' ▶' : st === 'paused' ? ' ⏸' : ''}
                      </span>
                    </div>
                  </div>
                </div>
              )
            })}
        </div>
      ))}
      <div className="gantt-legend">
        {Object.entries(PHASE_COLORS).map(([phase, color]) => (
          <span className="legend-item" key={phase}>
            <i style={{ background: color }} />
            {phase}
          </span>
        ))}
        <span className="legend-item">
          <i style={{ background: '#d64545' }} />
          返工/复检
        </span>
        <span className="legend-item">
          <i style={{ background: '#b3382f' }} />
          事件时刻
        </span>
      </div>
    </div>
  )
}

function ticks(total: number) {
  const step = total <= 20 ? 2 : total <= 60 ? 5 : 10
  const arr: number[] = []
  for (let t = 0; t <= total + 0.001; t += step) arr.push(Math.round(t * 10) / 10)
  if (arr[arr.length - 1] < total) arr.push(Math.round(total * 10) / 10)
  return arr
}
