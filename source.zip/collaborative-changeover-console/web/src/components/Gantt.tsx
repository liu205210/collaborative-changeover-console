import { useMemo } from 'react'
import type { ScheduleEntry } from '../types'

const PHASE_COLORS: Record<string, string> = {
  物料准备与配送: '#2f7ff0',
  工装准备与切换: '#13b5a2',
  设备参数准备与校准: '#7a5af0',
  首件检验与质量放行: '#e08a1e'
}

function phaseColor(phase: string) {
  return PHASE_COLORS[phase] || '#5b6b82'
}

interface GanttProps {
  entries: ScheduleEntry[]
  makespan: number
  view: 'task' | 'resource'
}

export default function Gantt({ entries, makespan, view }: GanttProps) {
  const total = Math.max(makespan, 1)
  const ticks = useMemo(() => {
    const step = total <= 20 ? 2 : total <= 60 ? 5 : 10
    const arr: number[] = []
    for (let t = 0; t <= total + 0.001; t += step) arr.push(Math.round(t * 10) / 10)
    if (arr[arr.length - 1] < total) arr.push(Math.round(total * 10) / 10)
    return arr
  }, [total])

  if (!entries.length) {
    return <div className="empty">暂无排程数据，请先生成换产计划</div>
  }

  if (view === 'resource') {
    const people = Array.from(new Set(entries.map((e) => e.assigneeName)))
    return (
      <div className="gantt">
        <div className="gantt-axis">
          <div className="gantt-axis-label">人员 / 时间(分钟)</div>
          <div className="gantt-axis-track">
            {ticks.map((t) => (
              <div key={t} className="gantt-tick" style={{ left: `${(t / total) * 100}%` }}>
                <span>{t}</span>
              </div>
            ))}
          </div>
        </div>
        {people.map((p) => {
          const rows = entries.filter((e) => e.assigneeName === p)
          return (
            <div className="gantt-row" key={p}>
              <div className="gantt-row-label" title={p}>
                {p}
              </div>
              <div className="gantt-track">
                {ticks.map((t) => (
                  <div key={t} className="gantt-gridline" style={{ left: `${(t / total) * 100}%` }} />
                ))}
                {rows.map((e) => (
                  <div
                    key={e.id}
                    className="gantt-bar"
                    style={{
                      left: `${(e.start / total) * 100}%`,
                      width: `${Math.max(0, e.end - e.start) / total * 100}%`,
                      background: phaseColor(e.phase)
                    }}
                    title={`${e.name} · 订单 ${e.order}\n${e.start} → ${e.end} 分钟（${e.duration} 分钟）\n资源：${e.exclusive || '常规'}`}
                  >
                    <span className="gantt-bar-text">{e.name}</span>
                  </div>
                ))}
              </div>
            </div>
          )
        })}
      </div>
    )
  }

  const orders = Array.from(new Set(entries.map((e) => e.order)))
  return (
    <div className="gantt">
      <div className="gantt-axis">
        <div className="gantt-axis-label">订单 / 任务 · 时间(分钟)</div>
        <div className="gantt-axis-track">
          {ticks.map((t) => (
            <div key={t} className="gantt-tick" style={{ left: `${(t / total) * 100}%` }}>
              <span>{t}</span>
            </div>
          ))}
        </div>
      </div>
      {orders.map((order) => {
        const rows = entries.filter((e) => e.order === order).sort((a, b) => a.start - b.start)
        return (
          <div className="gantt-group" key={order}>
            <div className="gantt-order-head">
              <span className="gantt-order-id">订单 {order}</span>
              <span className="gantt-order-meta">{rows.length} 个任务</span>
            </div>
            {rows.map((e) => (
              <div className="gantt-row" key={e.id}>
                <div className="gantt-row-label" title={`${e.name} · ${e.skillLabel}`}>
                  <span className="gantt-task-name">{e.name}</span>
                  <span className="gantt-task-skill">{e.assigneeName}</span>
                </div>
                <div className="gantt-track">
                  {ticks.map((t) => (
                    <div key={t} className="gantt-gridline" style={{ left: `${(t / total) * 100}%` }} />
                  ))}
                  <div
                    className="gantt-bar"
                    style={{
                      left: `${(e.start / total) * 100}%`,
                      width: `${Math.max(0, e.end - e.start) / total * 100}%`,
                      background: phaseColor(e.phase)
                    }}
                    title={`${e.name} · 订单 ${e.order}\n${e.start} → ${e.end} 分钟（${e.duration} 分钟）\n执行人：${e.assigneeName}\n资源：${e.exclusive || '常规'}${e.delayedByResource ? `\n资源等待：${e.resourceWait} 分钟` : ''}`}
                  >
                    <span className="gantt-bar-text">
                      {e.duration}m{e.delayedByResource ? ` · 等${e.resourceWait}` : ''}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )
      })}
      <div className="gantt-legend">
        {Object.entries(PHASE_COLORS).map(([phase, color]) => (
          <span className="legend-item" key={phase}>
            <i style={{ background: color }} />
            {phase}
          </span>
        ))}
      </div>
    </div>
  )
}
