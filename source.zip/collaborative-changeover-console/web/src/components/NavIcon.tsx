export default function NavIcon({ name }: { name: string }) {
  const paths: Record<string, string> = {
    overview: 'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',
    workbench: 'M4 5h16 M4 12h16 M4 19h16 M8 3v4 M15 10v4 M10 17v4',
    agents: 'M9 3h6v6H9z M2 16h6v5H2z M16 16h6v5h-6z M12 9v4 M5 16v-3h14v3',
    drill: 'M12 3 2 21h20L12 3z M12 9v5 M12 17v1',
    eval: 'M4 3v18h17 M8 16v-5 M13 16V7 M18 16V4',
    lab: 'M9 3h6 M10 3v6l-6 10q-1 2 2 2h12q3 0 2-2L14 9V3 M7 15h10',
    validation: 'M12 2 3 6v6c0 5 9 10 9 10s9-5 9-10V6L12 2z M8 12l3 3 5-6'
  }
  return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name] || paths.overview} /></svg>
}
