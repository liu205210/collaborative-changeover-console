export interface DatasetMeta {
  sourceFile: string
  sheet: string
  sheetCount: number
  sheetNames: string[]
  dataRows: number
  blankRows: number
  orders: number
  products: number
  materials: number
  dateRange: { min: string; max: string; distinctDays: number }
  missing: Record<string, number>
  duplicates: { fullRows: number; compositeKeys: number; compositeKeyDefinition: string }
  quantityAggregation: {
    rawMaterialDetailSum: number
    rawMaterialDetailRows: number
    aggregatedByOrderSum: number
    inflatedTimes: number | null
    note: string
  }
  bomLineTotal: number
  materialCategories: { name: string; count: number }[]
}

export interface OrderSummary {
  order: string
  product: string
  productDesc: string
  qty: number
  delivery: string
  faces: string[]
  bomLines: number
  materialTypes: number
}

export interface BomLine {
  material: string
  materialDesc: string
  usage: number
  face: string
  lineQty: number
}

export interface OrderDetail extends OrderSummary {
  productCount: number
  bom: BomLine[]
}

export type StrategyKey = 'A' | 'B' | 'C'

export interface ScheduleEntry {
  id: string
  key: string
  name: string
  phase: string
  order: string
  product: string
  skill: string
  skillLabel: string
  exclusive: string | null
  mode: 'offline' | 'online'
  stage: 'prep' | 'line' | 'post'
  deps: string[]
  duration: number
  assigneeId: string
  assigneeName: string
  start: number
  end: number
  depEarliest: number
  resourceWait: number
  delayedByResource: boolean
  kind?: string
  status?: string
  result?: string
  segStart?: number
  segEnd?: number
}

export interface OrderMetric {
  order: string
  prepStart: number
  prepEnd: number
  prepSpanMin: number
  prepWorkMin: number
  onlineStart: number
  onlineEnd: number
  onlineStopMin: number
  produceStart: number
}

export interface ScheduleMetrics {
  makespan: number
  criticalPath: number
  taskCount: number
  resourceWaitTotal: number
  conflictEvents: number
  onlineStopTotal: number
  offlinePrepTotal: number
  offlinePrepSpanTotal: number
  orderMetrics: OrderMetric[]
  utilization: { id: string; name: string; skill: string; busy: number; utilizationPct: number }[]
  exclusiveUsage: { id: string; name: string; busy: number; utilizationPct: number }[]
}

export interface Schedule {
  mode: StrategyKey
  modeName: string
  description: string
  strategyAssumption?: string
  optimizedSequence?: string[]
  entries: ScheduleEntry[]
  metrics: ScheduleMetrics
}

export interface ValidationCheck {
  name: string
  status: 'pass' | 'fail'
  detail: string
  violations: number
}

export interface ValidationResult {
  ok: boolean
  checks: ValidationCheck[]
  violations: { type: string; task?: string; resource?: string; detail: string }[]
}

export interface AgentView {
  id: string
  code: string
  name: string
  role: string
  mode: string
  status: string
  window: string
  inputs: { label: string; value: string }[]
  decisions: string[]
  executions: { task: string; order: string; window: string; assignee: string; resource: string; result: string; resourceWait: number; mode: string }[]
  taskCount: number
}

export interface CollaborationEvent {
  time: number
  from: string
  to: string
  type: string
  message: string
}

export interface MetricDelta {
  from: string
  to: string
  makespanDeltaMin: number
  makespanDeltaPct: number
  onlineStopDeltaMin: number
}

export interface Comparison {
  A: ScheduleMetrics
  B: ScheduleMetrics
  C: ScheduleMetrics
  deltas: { AtoB: MetricDelta; BtoC: MetricDelta; AtoC: MetricDelta }
  interpretation: { AtoB: string; BtoC: string; AtoC: string }
  note: string
}

export interface Plan {
  generatedAt: string
  createdAt?: string
  planId?: string
  modelVersion?: string
  currentModelVersion?: string
  inputDigest?: string
  stale?: boolean
  staleReason?: string | null
  orderIds: string[]
  orders: OrderDetail[]
  tasks: any[]
  resources: { personnel: any[]; exclusive: any[] }
  schedules: Record<StrategyKey, Schedule>
  validation: Record<StrategyKey, ValidationResult>
  agents: Record<StrategyKey, { agents: AgentView[]; log: CollaborationEvent[]; modeName: string; ruleBased: boolean }>
  comparison: Comparison
  assumptions: Assumptions
}

export interface MetricDefinition {
  name: string
  startEvent: string
  endEvent: string
  formula: string
  note: string
}

export interface Assumptions {
  modelName: string
  modelType: string
  dataSource: { real: string; missing: string[]; simulated: string }
  declaration: string
  boundary: { title: string; statement: string; comparableMetric: string }
  lineStateModel: { title: string; rules: string[]; readiness: string[] }
  eventModel?: { title: string; supported: string[]; assumptions: string[] }
  phases: string[]
  offlinePrepKeys: string[]
  onlineKeys: string[]
  postOfflineKeys: string[]
  personnel: { id: string; name: string; skill: string; efficiency: number; shift: string }[]
  efficiencyNote?: string
  exclusive: { id: string; name: string; capacity: number; note: string }[]
  taskTemplates: {
    key: string
    name: string
    phase: string
    skill: string
    skillLabel: string
    exclusive: string | null
    mode: 'offline' | 'online'
    stage: string
    deps: string[]
    formula: string
    rationale: string
  }[]
  metricDefinitions: Record<string, MetricDefinition>
  oeeNote: { status: string; reason: string; required: string[] }
}

export type SimEventType = 'agv_delay' | 'person_absence' | 'equipment_failure' | 'fai_fail'

export interface RecoveryMetrics {
  makespan: number
  reserveAt: number
  triggerAt: number
  remainingAfterTrigger: number
  waitReserveToTrigger: number
  remainingFromReserve: number
  onlineStopTotal: number
  delayVsOriginal: number
  adjustments: number
  completedByEvent: number
  resumedTasks: number
}

export interface RecoveryPlan {
  entries: ScheduleEntry[]
  metrics: RecoveryMetrics
  validation: ValidationResult
}

export interface SimEventRecord {
  id: string
  event: { type: SimEventType; target: string; at: number; duration?: number; to?: number; policy?: string; redo?: boolean }
  signature: string
  timing?: { reserveAt: number; triggerAt: number; snapshotAt: number; basis: string }
  reserveAt?: number
  triggerAt?: number
  snapshotAt?: number
  sharedSnapshotId?: string
  eventTime: number
  applicable: boolean
  snapshot: {
    at: number
    doneCount: number
    running: { id: string; start: number; end: number; assigneeId: string; assigneeName: string }[]
    activeOrder: string | null
    lockProtected: string
    quality: { order: string; faiStatus: string; released: boolean }[]
    personnelAvailability: { id: string; name: string; skill: string; unavailable: string[] }[]
    resourceAvailability: { id: string; name: string; blocked: string[] }[]
  }
  assumptions: { person?: string; resource?: string; order?: string; window: string; policy: string; note: string }[]
  frozen: ScheduleEntry[]
  baseMakespan: number
  R0: RecoveryPlan
  R1: RecoveryPlan
  chosen: string
  infeasible: boolean
  infeasibleReason: string | null
  createdAt: string
}

export interface SimCandidates {
  deliveries: { id: string; order: string; start: number; end: number; assignee: string }[]
  persons: { id: string; name: string; skill: string }[]
  resources: { id: string; name: string }[]
  orders: { order: string; releasedEnd: number | null }[]
}

export interface SimSession {
  sessionId: string
  modelVersion: string
  currentModelVersion?: string
  stale?: boolean
  staleReason?: string | null
  seed: number
  inputDigest?: string | null
  createdAt?: string
  orderIds: string[]
  orders: OrderDetail[]
  tasks: any[]
  personnel: any[]
  exclusive: any[]
  basePlan: { mode: string; modeName: string; description: string; entries: ScheduleEntry[]; metrics: ScheduleMetrics }
  actualEntries: ScheduleEntry[]
  events: SimEventRecord[]
  candidates: SimCandidates
  updatedAt: string
}

export interface SimEventResult {
  applied: boolean
  applicable?: boolean
  duplicate?: boolean
  infeasible?: boolean
  reason?: string
  eventRecord?: SimEventRecord
  session?: SimSession
}
