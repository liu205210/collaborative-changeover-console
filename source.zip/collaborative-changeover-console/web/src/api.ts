import type { Assumptions, DatasetMeta, OrderDetail, OrderSummary, Plan, SimEventResult, SimSession } from './types'

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...init
  })
  if (!res.ok) {
    let msg = `请求失败 (${res.status})`
    try {
      const body = await res.json()
      if (body && body.error) msg = body.error
    } catch {
      /* ignore */
    }
    throw new Error(msg)
  }
  return (await res.json()) as T
}

export const api = {
  health: () => request<{ ok: boolean; orders: number }>('/api/health'),
  dataset: () => request<{ meta: DatasetMeta; orders: OrderSummary[]; sourceFiles: string[] }>('/api/dataset'),
  order: (id: string) => request<OrderDetail>(`/api/orders/${encodeURIComponent(id)}`),
  assumptions: () => request<Assumptions>('/api/assumptions'),
  createPlan: (orders: string[], faiFailures: string[] = []) =>
    request<Plan>('/api/plans', { method: 'POST', body: JSON.stringify({ orders, faiFailures }) }),
  lastPlan: () => request<Plan>('/api/plans/last'),
  reimport: () => request<{ ok: boolean; orderCount: number }>('/api/import', { method: 'POST' }),
  simReset: (orders: string[], seed?: number) =>
    request<SimSession>('/api/simulate/reset', { method: 'POST', body: JSON.stringify({ orders, seed }) }),
  simEvent: (event: any) => request<SimEventResult>('/api/simulate/event', { method: 'POST', body: JSON.stringify(event) }),
  simGet: () => request<SimSession>('/api/simulate'),
  simData: () => request<any>('/api/simdata'),
  evalCatalog: () => request<any>('/api/eval/catalog'),
  evalRun: (body: { sets?: string[]; categories?: string[]; seed?: number; note?: string }) =>
    request<any>('/api/eval/run', { method: 'POST', body: JSON.stringify(body) }),
  evalResults: () => request<any>('/api/eval/results'),
  labStatus: () => request<any>('/api/lab/status'),
  labAnalyze: () => request<any>('/api/lab/analyze', { method: 'POST' }),
  labExperiment: () => request<any>('/api/lab/experiment', { method: 'POST' }),
  labValidate: () => request<any>('/api/lab/validate', { method: 'POST' }),
  labActivate: () => request<any>('/api/lab/activate', { method: 'POST' }),
  labRollback: () => request<any>('/api/lab/rollback', { method: 'POST' }),
  labReset: () => request<any>('/api/lab/reset', { method: 'POST' }),
  collabStatus: () => request<any>('/api/collab/status'),
  collabConsole: (source: string, opts?: { at?: number; eventIndex?: number }) => {
    const q = new URLSearchParams({ source })
    if (opts?.at != null) q.set('at', String(opts.at))
    if (opts?.eventIndex != null) q.set('eventIndex', String(opts.eventIndex))
    return request<any>(`/api/collab/console?${q.toString()}`)
  },
  collabAssistant: (body: { question?: string; intent?: string; source: string; at?: number; eventIndex?: number; allowModel?: boolean }) =>
    request<any>('/api/collab/assistant', { method: 'POST', body: JSON.stringify(body) })
}
