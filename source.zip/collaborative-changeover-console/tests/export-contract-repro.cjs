'use strict';
// Runs original registered handlers in a VM with isolated storage. No browser,
// real HTTP listener or model service. One explicit dev fixture; no reserved solve.
const fs=require('fs'),path=require('path'),vm=require('vm'),{createRequire}=require('module');
const root=path.resolve(process.argv[2]),out=process.argv[3]||path.join(__dirname,'export-contract-output.json');
const req=createRequire(path.join(root,'package.json')),loader=req('./server/dataLoader'),data=loader.importWorkbook(loader.DEFAULT_XLSX);
const evalModule=req('./server/evaluation'),recovery=req('./server/recovery'),catalog=evalModule.buildCaseCatalog(data.orders);
const entry=catalog.find(c=>c.kind==='static'&&c.set==='dev'&&c.orders.length===1);
const key=ids=>ids.slice().sort().join('+');
if(catalog.some(c=>c.set==='reserved'&&key(c.orders)===key(entry.orders)))throw new Error('Reserved fixture rejected');
const baseline=recovery.createSession({orders:entry.orders.map(id=>data.orders.find(o=>o.order===id))});
const eventResult=recovery.applyEvent(baseline,{type:'equipment_failure',target:'LINE-01',at:12,duration:5});
if(!eventResult.result.applied)throw new Error('Fixture event did not apply');
const session=eventResult.bundle;
const clone=x=>JSON.parse(JSON.stringify(x)),mem=new Map([['dataset.json',data],['simulation.json',session]]),routes=new Map();
const store={readJSON:(n,f=null)=>mem.has(n)?clone(mem.get(n)):f,writeJSON:(n,v)=>{mem.set(n,clone(v));return n;}};
const app={use(){},get(p,f){routes.set('GET '+p,f)},post(p,f){routes.set('POST '+p,f)},listen(){}};
const express=()=>app;express.json=()=>()=>{};express.static=()=>()=>{};
const index=path.join(root,'server/index.js'),local=createRequire(index);
const context={module:{exports:{}},require:n=>n==='express'?express:n==='cors'||n==='compression'?()=>()=>{}:n==='./store'?store:n==='./dataLoader'?{...loader,ensureDirs:()=>{}}:local(n),__dirname:path.dirname(index),console:{log(){},error(){}},process,performance,Date};
vm.runInNewContext(fs.readFileSync(index,'utf8'),context,{filename:index});
function get(url){const u=new URL(url,'http://audit.local'),answer={status:200,body:null};const res={status(n){answer.status=n;return this},json(x){answer.body=clone(x);return this},send(x){answer.body=typeof x==='string'?JSON.parse(x):clone(x);return this},setHeader(){}};routes.get('GET '+u.pathname)({query:Object.fromEntries(u.searchParams)},res);if(answer.status!==200)throw new Error(JSON.stringify(answer));return answer.body;}
const source=fs.readFileSync(path.join(root,'web/src/pages/Agents.tsx'),'utf8');
const match=source.match(/href=\{(`\/api\/collab\/export[^\n]+?)\} target/);
if(!match)throw new Error('Export control changed; inspect new UI URL construction instead of guessing.');
const exportHref=vm.runInNewContext(match[1],{source:'execution',at:10,eventIndex:0});
const view=get('/api/collab/console?source=execution&at=10'),exported=get(exportHref),explicit=get('/api/collab/export?source=execution&at=10');
evalModule.setUsageSink(null);
const checks=[
 {name:'Export control preserves the displayed observation time and snapshot',pass:view.snapshot.snapshotId===exported.snapshot.snapshotId&&view.snapshot.observationTime===exported.snapshot.observationTime},
 {name:'Backend export with matching parameters returns the same snapshot',pass:view.snapshot.snapshotId===explicit.snapshot.snapshotId&&view.snapshot.observationTime===explicit.snapshot.observationTime}
];
const report={scope:'Original frontend export URL expression and original backend handlers. VM storage isolation; no browser claim; no model call; no original source edits.',fixture:{caseId:entry.id,orders:entry.orders,sessionCalls:1,eventCalls:1,reservedSolves:0},exportHref,display:{snapshotId:view.snapshot.snapshotId,at:view.snapshot.observationTime},export:{snapshotId:exported.snapshot.snapshotId,at:exported.snapshot.observationTime},explicitParameters:{snapshotId:explicit.snapshot.snapshotId,at:explicit.snapshot.observationTime},checks,passed:checks.filter(x=>x.pass).length,failed:checks.filter(x=>!x.pass).length};
fs.writeFileSync(out,JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));if(report.failed)process.exitCode=1;
