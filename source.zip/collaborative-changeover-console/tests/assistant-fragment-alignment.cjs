'use strict'
// Minimal in-memory split-task fixtures; no solver, network or store access.
const fs = require('fs'), path = require('path')
const root = path.resolve(process.argv[2])
const assistant = require(path.join(root, 'server/assistant'))
const collab = require(path.join(root, 'server/collaboration'))
const order = '4003111034'
const task = (key, start, end, extra = {}) => ({ id: `${order}::${key}`, order, key, name: collab.KEY_LABEL[key], start, end, duration: end-start, deps: [], kind: 'recovery', ...extra })
const original = task('fai_inspect', 20, 21, { id: `${order}::fai_inspect::seg@21`, originId: `${order}::fai_inspect`, kind: 'actual', status: 'paused' })
const tasks = [task('line_clear',19,20), original, task('fai_inspect',25,27,{ result: 'fail' }), task('rework',27,28), task('recheck',28,30), task('quality_release',30,31), task('resume',31,32)]
const snapshot = (at) => ({ snapshotId: `fixture-${at}`, collaborationVersion: collab.COLLAB_VERSION, observationTime: at, kind: 'execution', timeBasis: 'explicit in-memory fragment fixture', tasks: structuredClone(tasks), orders: [{order}], quality: collab.qualityChain(tasks,[order],at), lineLocks:collab.lineLocks(tasks), knownEvents:[] })
const results=[]
function check(id, pass, evidence) { results.push({id,pass,evidence});console.log(`${pass?'PASS':'FAIL'} ${id}`) }
const ongoing=snapshot(26), ongoingRelease=assistant.answerRelease(ongoing,`订单 ${order} 能否放行？`)
const inspectionRef=ongoingRelease.evidenceRefs.find(e=>e.key==='fai_inspect')
check('RELEASE_CITES_WHOLE_CONTINUATION_NOT_HISTORICAL_FRAGMENT',inspectionRef&&inspectionRef.id===`${order}::fai_inspect`&&inspectionRef.end===27,{quality:ongoing.quality,answer:ongoingRelease})
const ongoingBlocking=assistant.answerBlocking(ongoing)
check('ACTIVE_INSPECTION_DOES_NOT_BECOME_HISTORICAL_FRAGMENT_OR_FUTURE_FAILURE',ongoingBlocking.evidenceRefs.some(e=>e.id===`${order}::fai_inspect`)&&!ongoingBlocking.evidenceRefs.some(e=>e.id===original.id)&&!ongoingBlocking.conclusion.includes('不合格'),{roles:collab.buildRoleStates(ongoing).map(r=>({id:r.id,status:r.status})),answer:ongoingBlocking})
const complete=snapshot(40), doneBlocking=assistant.answerBlocking(complete)
check('COMPLETED_CONTINUATIONS_DO_NOT_LEAVE_ASSISTANT_BLOCKER',collab.buildRoleStates(complete).every(r=>r.status==='已完成'||r.taskCount===0)&&doneBlocking.evidenceRefs.length===0&&doneBlocking.conclusion.includes('未发现阻塞'),{roles:collab.buildRoleStates(complete).map(r=>({id:r.id,status:r.status,taskCount:r.taskCount})),answer:doneBlocking})
const rechecking=snapshot(29), recheckRelease=assistant.answerRelease(rechecking,`订单 ${order} 能否放行？`)
check('FAILED_INSPECTION_ANSWER_CITES_RECHECK_GATE',recheckRelease.evidenceRefs.some(e=>e.key==='recheck'&&e.end===30)&&recheckRelease.conclusion.includes('尚不能放行'),{quality:rechecking.quality,answer:recheckRelease})
const afterRecheck=snapshot(30), afterRelease=assistant.answerRelease(afterRecheck,`订单 ${order} 能否放行？`)
check('PASSED_RECHECK_DOES_NOT_REWRITE_HISTORICAL_FIRST_FAILURE_AS_PASS',afterRelease.conclusion.includes('复检')&&!afterRelease.conclusion.includes('首件合格'),{quality:afterRecheck.quality,answer:afterRelease})
const output={fixture:'explicit in-memory split-task structure; no solver/reserved/model call',passed:results.filter(r=>r.pass).length,failed:results.filter(r=>!r.pass).length,results}
fs.writeFileSync(process.argv[3]||path.join(__dirname,'assistant-fragment-alignment.json'),JSON.stringify(output,null,2))
console.log(`${output.passed} PASS / ${output.failed} FAIL`);process.exitCode=output.failed?1:0
