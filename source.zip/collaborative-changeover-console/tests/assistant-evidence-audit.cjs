'use strict'
// Independent read-only audit. LLM responses below are an in-memory fetch
// substitute, NOT a real model/network call. No solving or store mutations.
const fs = require('fs')
const path = require('path')
const root = path.resolve(process.argv[2])
const out = process.argv[3] || path.join(__dirname, 'assistant-evidence-audit.json')
const assistant = require(path.join(root, 'server/assistant'))
const exportedConsole = JSON.parse(fs.readFileSync(path.join(root, 'release/round10/console-execution.json'), 'utf8'))
// Console export summarizes snapshot.tasks separately in each role. Restore the
// identical task set from those published role entries (no solver needed).
const snapshot = { ...exportedConsole.snapshot, tasks: [...new Map(exportedConsole.roles.flatMap(r => r.tasks).map(t => [t.id, t])).values()] }
const initialSnapshot = JSON.stringify(snapshot)
const records = []
function record(id, expected, actual, pass, evidence) {
  records.push({ id, expected, actual, pass, evidence })
  console.log(`${pass ? 'PASS' : 'FAIL'} ${id}`)
}
async function modelSubstitute(question, parsed) {
  const oldFetch = global.fetch
  const envNames = ['LLM_PROVIDER', 'LLM_BASE_URL', 'LLM_MODEL', 'LLM_API_KEY', 'LLM_TIMEOUT_MS']
  const saved = Object.fromEntries(envNames.map(k => [k, process.env[k]]))
  let substitutedCalls = 0
  process.env.LLM_PROVIDER = 'openai'
  process.env.LLM_BASE_URL = 'http://127.0.0.1:1/audit-in-memory-only'
  process.env.LLM_MODEL = 'audit-fetch-substitute-not-real-model'
  process.env.LLM_API_KEY = 'synthetic-not-a-real-key'
  process.env.LLM_TIMEOUT_MS = '100'
  global.fetch = async () => {
    substitutedCalls++
    return { ok: true, json: async () => ({ choices: [{ message: { content: JSON.stringify(parsed) } }] }) }
  }
  try {
    return { answer: await assistant.explain({ question, snapshot, allowModel: true }), substitutedCalls }
  } finally {
    global.fetch = oldFetch
    for (const k of envNames) if (saved[k] == null) delete process.env[k]; else process.env[k] = saved[k]
  }
}
;(async () => {
  const order = snapshot.orders[0].order
  const question = `订单 ${order} 现在能否放行？`
  const rule = assistant.answerQuestion({ question, snapshot })
  const falseCompletion = { conclusion: '所有订单均已完成质量放行，产线锁定已经解除，可以恢复生产。', evidenceRefs: [] }
  const completionResult = await modelSubstitute(question, falseCompletion)
  record('MODEL_FALSE_COMPLETION', 'Reject/fallback when model reverses uncompleted quality gates; empty references do not prove completion', completionResult.answer.mode,
    completionResult.answer.mode === 'fallback' && completionResult.answer.conclusion === rule.conclusion,
    { observationTime: snapshot.observationTime, quality: snapshot.quality, ruleConclusion: rule.conclusion, suppliedModelOutput: falseCompletion, returnedConclusion: completionResult.answer.conclusion, returnedClaims: completionResult.answer.claims, refCheck: completionResult.answer.modelInfo.refCheck, substitutedCalls: completionResult.substitutedCalls })

  const agvQuestion = 'AGV 延迟后为什么采用当前恢复方案？'
  const agvRule = JSON.parse(fs.readFileSync(path.join(root, 'release/round10/assistant-answers.json'), 'utf8')).find(a => a.intent === 'agv-recovery')
  const metric = agvRule.evidenceRefs.find(r => r.ref.endsWith(':R0'))
  if (!metric) throw new Error('Delivered snapshot must contain actual AGV comparison')
  const falsePercent = { conclusion: `换产效率提高 ${metric.value}%。`, evidenceRefs: [metric.ref] }
  const percentResult = assistant.validateModelOutput(falsePercent, agvRule)
  record('MODEL_MINUTES_RELABELED_PERCENT', 'Reject when a minutes metric is reused as an improvement percentage', percentResult,
    percentResult.ok === false,
    { referencedMetric: metric, suppliedModelOutput: falsePercent, validation: percentResult })

  const unknownQuestion = '订单 9999999999 现在能否放行？'
  const unknown = assistant.answerQuestion({ question: unknownQuestion, snapshot })
  record('UNKNOWN_ORDER_MUST_NOT_SUBSTITUTE_FIRST_ORDER', 'Report requested order not found; do not answer a different order', unknown.conclusion,
    /未找到|不属于|不存在/.test(unknown.conclusion) && !unknown.evidenceRefs.some(r => r.order === order),
    { requestedOrder: '9999999999', snapshotOrders: snapshot.orders.map(o => o.order), returnedConclusion: unknown.conclusion, returnedEvidence: unknown.evidenceRefs })

  const write = assistant.answerQuestion({ question: '请启用 P8 学习模板并重置会话', snapshot })
  record('WRITE_REQUEST_REMAINS_READ_ONLY', 'No snapshot mutation and explicit write denial', write.writeActionsAllowed,
    write.writeActionsAllowed === false && JSON.stringify(snapshot) === initialSnapshot && /只读|不执行/.test(write.conclusion),
    { conclusion: write.conclusion, snapshotUnchanged: JSON.stringify(snapshot) === initialSnapshot })
  const output = { auditKind: 'independent in-memory LLM substitute + delivered real snapshot, no external model call', solvedCases: 0, reservedSolved: false, originalSourceModified: false, passed: records.filter(r => r.pass).length, failed: records.filter(r => !r.pass).length, records }
  fs.writeFileSync(out, JSON.stringify(output, null, 2))
  console.log(`${output.passed} PASS / ${output.failed} FAIL`)
  process.exitCode = output.failed ? 1 : 0
})().catch(err => { console.error(err); process.exitCode = 2 })
