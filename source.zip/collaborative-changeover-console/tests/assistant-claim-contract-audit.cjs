'use strict'
// Uses delivered v6.1 snapshots and an in-memory fetch substitute only.
// No actual LLM/network call, solver call, reserved case, or store modification.
const fs = require('fs')
const path = require('path')
const root = path.resolve(process.argv[2])
const out = process.argv[3] || path.join(__dirname, 'assistant-claim-contract-audit.json')
const assistant = require(path.join(root, 'server/assistant'))
const consoleExport = JSON.parse(fs.readFileSync(path.join(root, 'release/round11/console-execution.json'), 'utf8'))
const snapshot = { ...consoleExport.snapshot, tasks: [...new Map(consoleExport.roles.flatMap(r => r.tasks).map(t => [t.id, t])).values()] }
const before = JSON.stringify(snapshot)
const records = []
function check(id, expected, pass, evidence) {
  records.push({ id, expected, pass, evidence })
  console.log(`${pass ? 'PASS' : 'FAIL'} ${id}`)
}
async function substitute(question, parsed) {
  const oldFetch = global.fetch
  const keys = ['LLM_PROVIDER', 'LLM_BASE_URL', 'LLM_MODEL', 'LLM_API_KEY', 'LLM_TIMEOUT_MS']
  const saved = Object.fromEntries(keys.map(k => [k, process.env[k]]))
  process.env.LLM_PROVIDER = 'openai'
  process.env.LLM_BASE_URL = 'http://127.0.0.1:1/in-memory-substitute-only'
  process.env.LLM_MODEL = 'audit-not-a-real-model'
  process.env.LLM_API_KEY = 'synthetic-not-a-real-key'
  process.env.LLM_TIMEOUT_MS = '100'
  let calls = 0
  global.fetch = async () => { calls++; return { ok: true, json: async () => ({ choices: [{ message: { content: JSON.stringify(parsed) } }] }) } }
  try { return { calls, answer: await assistant.explain({ question, snapshot, allowModel: true }) } }
  finally {
    global.fetch = oldFetch
    for (const k of keys) if (saved[k] === undefined) delete process.env[k]; else process.env[k] = saved[k]
  }
}
;(async () => {
  const question = `订单 ${snapshot.orders[0].order} 现在能否放行？`
  const rule = assistant.answerQuestion({ question, snapshot })
  const falseText = '全部订单已完成质量放行，产线锁定已解除，可以立即恢复生产。'
  const payload = { claimIds: rule.claims.map(c => c.id), evidenceRefs: rule.evidenceRefs.map(r => r.ref), explanation: falseText }
  const result = await substitute(question, payload)
  check('LEGAL_CLAIM_DOES_NOT_LICENSE_OPPOSITE_GATE_EXPLANATION', 'Never display contradictory completed quality gates with verified model mode', !result.answer.conclusion.includes(falseText),
    { actualQuality: snapshot.quality, observationTime: snapshot.observationTime, ruleConclusion: rule.conclusion, payload, answer: result.answer })

  const agvRule = JSON.parse(fs.readFileSync(path.join(root, 'release/round11/assistant-answers.json'), 'utf8')).find(x => x.intent === 'agv-recovery')
  const metric = agvRule.evidenceRefs.find(r => r.ref.endsWith(':R0'))
  for (const [id, explanation] of [
    ['MINUTES_CANNOT_BECOME_HOURS', `恢复总历时为 ${metric.value} 小时。`],
    ['MINUTES_CANNOT_BECOME_CHINESE_PERCENT', `换产效率提高百分之${metric.value}。`]
  ]) {
    const p = { claimIds: agvRule.claims.map(c => c.id), evidenceRefs: [metric.ref], explanation }
    const validated = assistant.validateModelOutput(p, agvRule)
    check(id, 'Reject unit/metric substitutions even when number and claim IDs are genuine', validated.ok === false, { metric, payload: p, validated })
  }

  const unknown = assistant.answerQuestion({ question: '订单 9999999999 现在能否放行？', snapshot })
  check('EXPLICIT_UNKNOWN_ORDER_REJECTED', 'Unknown requested order must not substitute another order', /未找到订单 9999999999/.test(unknown.conclusion) && unknown.evidenceRefs.length === 0, { conclusion: unknown.conclusion, evidenceRefs: unknown.evidenceRefs })

  const good = { claimIds: rule.claims.map(c => c.id), evidenceRefs: rule.evidenceRefs.map(r => r.ref), explanation: '' }
  const positive = await substitute(question, good)
  check('VALID_CLAIM_SELECTION_PRESERVES_RULE', 'A legitimate model claim selection keeps the exact rule conclusion', positive.answer.mode === 'model' && positive.answer.conclusion === rule.conclusion, { mode: positive.answer.mode, conclusion: positive.answer.conclusion, refCheck: positive.answer.modelInfo.refCheck })
  check('READ_ONLY', 'All checks leave input unchanged', JSON.stringify(snapshot) === before, { noSolverCalls: true, noStoreWrites: true })
  const output = { auditKind: 'v6.1 legal claimIds/explanation contract; in-memory fetch substitute, NOT a real model call', reservedSolved: false, realModelCalled: false, sourceModified: false, passed: records.filter(r => r.pass).length, failed: records.filter(r => !r.pass).length, records }
  fs.writeFileSync(out, JSON.stringify(output, null, 2))
  console.log(`${output.passed} PASS / ${output.failed} FAIL`)
  process.exitCode = output.failed ? 1 : 0
})().catch(e => { console.error(e); process.exitCode = 2 })
