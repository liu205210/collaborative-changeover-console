'use strict';
// Real dev/validation solves; isolated storage, no reserved solving. Source unchanged.
const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]);
const output=path.resolve(process.argv[3]||path.join(__dirname,'lab-usage-closure-output.json'));
const req=n=>require(path.join(root,'server',n));
const store=req('store.js'),evaluation=req('evaluation.js'),sched=req('scheduler.js'),lab=req('lab.js');
const loader=req('dataLoader.js'),{orders}=loader.importWorkbook(loader.DEFAULT_XLSX);
const clone=x=>JSON.parse(JSON.stringify(x)),capture=fn=>{try{fn();return null;}catch(e){return e;}};
const memoryBackup={STORE_DIR:store.STORE_DIR,readJSON:store.readJSON,writeJSON:store.writeJSON};
const originals={C:sched.buildStrategyC,L:sched.buildStrategyCLearned};
const catalog=evaluation.buildCaseCatalog(orders),key=ids=>ids.slice().sort().join('+');
const allowed=new Set(catalog.filter(c=>c.kind==='static'&&['dev','validation'].includes(c.set)).map(c=>key(c.orders)));
let calls=0,sequence=0;
for(const [name,original] of [['buildStrategyC',originals.C],['buildStrategyCLearned',originals.L]])sched[name]=function(...args){assert.ok(allowed.has(key(args[1])),'AUDIT: forbidden solver input');calls++;return original.apply(this,args);};
const tmp=fs.mkdtempSync(path.join(path.dirname(output),'usage-closure-state-'));
function storage(source){const dir=path.join(tmp,String(++sequence));fs.mkdirSync(dir);if(source)fs.cpSync(source,dir,{recursive:true});store.STORE_DIR=dir;store.readJSON=(n,f=null)=>fs.existsSync(path.join(dir,n))?JSON.parse(fs.readFileSync(path.join(dir,n),'utf8')):f;store.writeJSON=(n,v)=>{fs.writeFileSync(path.join(dir,n),JSON.stringify(v));return n;};return dir;}
const results=[];function check(name,fn){try{const details=fn();results.push({name,passed:true,details});console.log('PASS '+name);}catch(e){results.push({name,passed:false,error:e.message});console.log('FAIL '+name+': '+e.message);}}
let setupError=null;
try{
  storage();evaluation.setUsageSink(()=>{throw new Error('AUDIT_HISTORY_LEDGER_FAILURE');});
  const historyBefore=calls,error=capture(()=>lab.analyzeDevHistory({orders}));
  const pendingHistory=store.readJSON('lab-pending.json');
  check('history failure truthfully reports executed work and preserves it before publication',()=>{
    assert.equal(calls-historyBefore,11);assert.ok(error);assert.equal(error.executed,true);
    assert.ok(error.runId&&error.usedFingerprints.length===11);assert.equal(store.readJSON('lab-dev-history.json'),null);
    assert.equal(pendingHistory.kind,'history');assert.equal(pendingHistory.runId,error.runId);
    return {actualSolverCalls:11,executed:error.executed,runId:error.runId};
  });
  const historyLedger=[];evaluation.setUsageSink(rec=>historyLedger.push(clone(rec)));
  const retryBefore=calls,history=lab.analyzeDevHistory({orders});
  check('history retry records the original run without solving again',()=>{
    assert.equal(calls,retryBefore);assert.ok(history.recovered);assert.equal(historyLedger.length,1);
    assert.equal(historyLedger[0].runId,error.runId);assert.equal(history.runId,error.runId);
    assert.equal(store.readJSON('lab-pending.json'),null);return {extraSolverCalls:calls-retryBefore,ledgerRecords:1};
  });
  lab.runExperiment({orders});
  // Execute the HTTP sink function verbatim, with isolated load/save and an injected second-write error.
  const indexSource=fs.readFileSync(path.join(root,'server/index.js'),'utf8');
  const start=indexSource.indexOf('function recordUsage(rec) {'),end=indexSource.indexOf('// 真实求解入口统一记账',start);
  assert.ok(start>=0&&end>start);
  let ledger={fingerprints:[],runs:[]},failSecond=true;
  const context={loadUsage:()=>clone(ledger),saveUsage:u=>{if(failSecond&&u.runs.length===2)throw new Error('AUDIT_SECOND_LEDGER_WRITE');ledger=clone(u);}};
  vm.createContext(context);vm.runInContext(indexSource.slice(start,end),context);
  evaluation.setUsageSink(rec=>context.recordUsage(rec));
  const validationError=capture(()=>lab.runValidation({orders}));
  assert.ok(validationError&&validationError.executed,'fixture requires a post-solve validation ledger failure');
  const pending=store.readJSON('lab-pending.json');assert.equal(pending.kind,'validation');
  const pendingDir=store.STORE_DIR,partialLedger=clone(ledger);
  for(const action of ['reset','newRound','otherStage'])check(`${action} cannot erase or overwrite unrecorded execution`,()=>{
    storage(pendingDir);const before=clone(store.readJSON('lab-pending.json')),protocol=clone(store.readJSON('lab-protocol.json')),count=calls;
    const err=capture(()=>action==='reset'?lab.reset({orders}):action==='newRound'?lab.runExperiment({orders,newRound:true}):lab.analyzeDevHistory({orders}));
    assert.ok(err,'must block until pending usage is recovered');assert.equal(calls,count);
    assert.deepEqual(store.readJSON('lab-pending.json'),before);assert.deepEqual(store.readJSON('lab-protocol.json'),protocol);
    return {pendingPreserved:true,extraSolverCalls:calls-count};
  });
  check('result persistence failure retains pending evidence for retry',()=>{
    storage(pendingDir);ledger=clone(partialLedger);failSecond=false;
    const originalWrite=store.writeJSON;
    store.writeJSON=(name,value)=>{if(name==='lab-validation.json')throw new Error('AUDIT_RESULT_PUBLISH_FAILURE');return originalWrite(name,value);};
    let err;try{err=capture(()=>lab.runValidation({orders}));}finally{store.writeJSON=originalWrite;}
    assert.ok(err);assert.equal(store.readJSON('lab-pending.json')?.runId,pending.runId);
    return {pendingPreserved:true};
  });
  check('HTTP partial ledger retry is idempotent by run ID and needs no re-solve',()=>{
    storage(pendingDir);ledger=clone(partialLedger);failSecond=false;const count=calls;
    const result=lab.runValidation({orders});
    assert.ok(result.recovered);assert.equal(calls,count);assert.equal(ledger.runs.length,2);
    assert.equal(new Set(ledger.runs.map(r=>r.runId)).size,2);
    assert.equal(store.readJSON('lab-pending.json'),null);
    assert.equal(store.readJSON('lab-validation.json').runId,pending.runId);
    return {extraSolverCalls:calls-count,uniqueLedgerRecords:ledger.runs.length};
  });
}catch(e){setupError=e.stack;console.log('SETUP ERROR '+e.stack);}finally{Object.assign(store,memoryBackup);sched.buildStrategyC=originals.C;sched.buildStrategyCLearned=originals.L;evaluation.setUsageSink(null);}
const report={applicationRoot:root,scope:'Pending usage lifecycle only. Dev/validation solver guard enforced; no reserved solving; input source unchanged.',setupError,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length,actualSolverCalls:calls,results};
fs.writeFileSync(output,JSON.stringify(report,null,2));console.log(`RESULT passed=${report.passed} failed=${report.failed} total=${results.length}`);if(setupError||report.failed)process.exitCode=1;
