'use strict';

// Audit-only acceptance tests. Usage: node acceptance-regressions.cjs [application-root]
const assert = require('node:assert/strict');
const path = require('node:path');
const appRoot = path.resolve(process.argv[2] || path.join(__dirname, '../v4.1/workspace'));
const recovery = require(path.join(appRoot, 'server/recovery.js'));
const scheduler = require(path.join(appRoot, 'server/scheduler.js'));
const orders = [1, 2, 3].map(i => ({
  order: `O${i}`, product: `P${i}`, qty: 100,
  bomLines: 10, materialTypes: 5, faces: ['A']
}));
const make = (n = 1) => recovery.createSession({ orders: orders.slice(0, n) });
let passed = 0, failed = 0;

function check(name, fn) {
  try { fn(); passed++; console.log(`PASS ${name}`); }
  catch (error) { failed++; console.log(`FAIL ${name}\n  ${error.message}`); }
}
function validationFixture() {
  const session = make();
  const event = { type: 'person_absence', target: 'MAT-02', at: 0, duration: 1 };
  const input = recovery.buildRecoveryInput(session, event, recovery.snapshotAt(session, 0));
  return { session, event, input };
}
function expectRejected(transform) {
  const { session, event, input } = validationFixture();
  const entries = transform(session.actualEntries.map(e => ({ ...e })));
  assert.equal(recovery.validateRecovery(session, input, entries, event).ok, false,
    'independent validator must reject this invalid recovery candidate');
}

console.log(`Application root: ${appRoot}`);
console.log('Synthetic fixture: one or three orders; qty=100, BOM lines=10, material types=5, faces=[A].');

check('empty recovery candidate is rejected while eleven tasks remain', () => {
  expectRejected(() => []);
});
check('nonexistent assignees are rejected', () => {
  expectRejected(entries => entries.map((e, i) => ({ ...e, assigneeId: `UNKNOWN-${i}` })));
});
check('real worker with wrong skill is rejected', () => {
  expectRejected(entries => entries.map(e => e.key === 'material_pick' ? { ...e, assigneeId: 'EQP-02' } : e));
});
check('silently shortened task durations are rejected', () => {
  expectRejected(entries => entries.map(e => ({ ...e, end: e.start + 0.01, duration: 0.01 })));
});
check('in-progress AGV delay recovers and a fifteen-minute delay is counted once', () => {
  const session = make();
  const originalDelivery = session.actualEntries.find(e => e.key === 'material_deliver');
  const at = Number((originalDelivery.start + 0.5).toFixed(2));
  const result = recovery.applyEvent(session, {
    type: 'agv_delay', target: originalDelivery.id, at, duration: 15
  });
  assert.equal(result.result.applied, true, result.result.reason);
  const record = result.result.eventRecord;
  assert.equal(record.R1.validation.ok, true);
  const delivery = result.bundle.actualEntries.find(e => e.id === originalDelivery.id);
  assert.ok(delivery, 'remaining delivery must be retained');
  assert.ok(Math.abs(delivery.end - (originalDelivery.end + 15)) < 0.011,
    `delivery should finish at ${originalDelivery.end + 15}, got ${delivery.end}`);
  assert.ok(Math.abs(record.R1.metrics.makespan - (session.basePlan.metrics.makespan + 15)) < 0.011,
    'single-order completion should move by exactly fifteen minutes');
  const fragment = result.bundle.actualEntries.find(e =>
    e.key === 'material_deliver' && e.id !== originalDelivery.id &&
    Math.abs(e.start - originalDelivery.start) < 0.011 && Math.abs(e.end - at) < 0.011);
  assert.ok(fragment, 'delivery execution before the event must remain recorded');
});
check('unrelated CAL failure during reinspection preserves and completes reinspection', () => {
  const initial = recovery.applyEvent(make(), { type: 'fai_fail', target: 'O1', at: 0 });
  assert.equal(initial.result.applied, true, initial.result.reason);
  const rework = initial.bundle.actualEntries.find(e => e.key === 'rework');
  const recheck = initial.bundle.actualEntries.find(e => e.key === 'recheck');
  const at = Number((rework.end + 0.5).toFixed(2));
  assert.ok(at > recheck.start && at < recheck.end, 'fixture must target running reinspection');
  const result = recovery.applyEvent(initial.bundle, {
    type: 'equipment_failure', target: 'CAL-01', at, duration: 1
  });
  assert.equal(result.result.applied, true, result.result.reason);
  assert.equal(result.result.eventRecord.R1.validation.ok, true);
  const after = result.bundle.actualEntries;
  const continuation = after.find(e => e.id === recheck.id);
  assert.ok(continuation, 'unfinished reinspection must not be dropped');
  const fragments = after.filter(e => e.key === 'recheck' && e.id !== recheck.id);
  assert.ok(fragments.some(e => Math.abs(e.start - recheck.start) < 0.011 && Math.abs(e.end - at) < 0.011),
    'completed reinspection fragment must be preserved');
  const workMinutes = after.filter(e => e.key === 'recheck').reduce((sum, e) => sum + e.end - e.start, 0);
  assert.ok(Math.abs(workMinutes - recheck.duration) < 0.011, 'all required reinspection work must remain');
  const release = after.find(e => e.id === 'O1::quality_release');
  assert.ok(release.start >= continuation.end - 0.011, 'release must follow completed reinspection');
});
check('positive regression: a later event retains an earlier ongoing LINE outage', () => {
  const first = recovery.applyEvent(make(3), { type: 'equipment_failure', target: 'LINE-01', at: 1, duration: 100 });
  assert.equal(first.result.applied, true, first.result.reason);
  const second = recovery.applyEvent(first.bundle, { type: 'equipment_failure', target: 'CAL-01', at: 2, duration: 1 });
  assert.equal(second.result.applied, true, second.result.reason);
  assert.equal(second.result.eventRecord.R1.validation.ok, true);
  assert.equal(second.bundle.actualEntries.filter(e => e.exclusive === 'LINE-01' && e.start < 101 && e.end > 1).length, 0);
});
check('positive regression: material-worker absence beyond all eligible shifts is infeasible', () => {
  const result = recovery.applyEvent(make(), { type: 'person_absence', targets: ['MAT-01', 'MAT-02'], at: 0, to: 721 });
  assert.equal(result.result.applied, false);
  assert.equal(result.result.infeasible, true);
  assert.ok(result.result.reason);
});

console.log(`\nRESULT passed=${passed} failed=${failed} total=${passed + failed}`);
process.exitCode = failed ? 1 : 0;
