'use strict';
// Independent acceptance: node lab-acceptance-addendum.cjs APP_ROOT [OUTPUT_JSON]
// Uses isolated real file storage and dev/validation only. Business source is not edited.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const root=path.resolve(process.argv[2]||path.join(__dirname,'../v5/application'));
const output=path.resolve(process.argv[3]||path.join(__dirname,'lab-acceptance-addendum-output.json'));
const req=name=>require(path.join(root,'server',name));
const store=req('store.js'),evaluation=req('evaluation.js'),scheduler=req('scheduler.js'),sim=req('simulation.js');
const {orders}=req('dataLoader.js').importWorkbook(req('dataLoader.js').DEFAULT_XLSX);
const lab=req('lab.js'),clone=x=>JSON.parse(JSON.stringify(x));
const catalog=evaluation.buildCaseCatalog(orders);
const allowed=catalog.filter(c=>['dev','validation'].includes(c.set)&&c.kind==='static');
const key=ids=>ids.slice().sort().join('+');
const allowedOrders=new Set(allowed.map(c=>key(c.orders)));
const backup={STORE_DIR:store.STORE_DIR,readJSON:store.readJSON,writeJSON:store.writeJSON};
const originals={C:scheduler.buildStrategyC,L:scheduler.buildStrategyCLearned};
let solverCalls=0,serial=0;
const work=fs.mkdtempSync(path.join(__dirname,'lab-acceptance-state-'));
for(const [method,original] of [['buildStrategyC',originals.C],['buildStrategyCLearned',originals.L]]) {
  scheduler[method]=function(...args){
    assert.ok(allowedOrders.has(key(args[1])),'AUDIT GUARD: only dev/validation order groups can be solved');
    solverCalls++;
    return original.apply(this,args);
  };
}
function storage(copyFrom){
  const dir=path.join(work,String(++serial));fs.mkdirSync(dir);
  if(copyFrom)fs.cpSync(copyFrom,dir,{recursive:true});
  store.STORE_DIR=dir;
  store.readJSON=(name,fallback=null)=>{const f=path.join(dir,name);return fs.existsSync(f)?JSON.parse(fs.readFileSync(f,'utf8')):fallback;};
  store.writeJSON=(name,value)=>{const f=path.join(dir,name);fs.mkdirSync(path.dirname(f),{recursive:true});fs.writeFileSync(f+'.tmp',JSON.stringify(value));fs.renameSync(f+'.tmp',f);return f;};
  return dir;
}
let ledger=[];
function workingLedger(){ledger=[];evaluation.setUsageSink(rec=>ledger.push(clone(rec)));}
const results=[];
function check(name,fn){try{const details=fn();results.push({name,passed:true,details});console.log('PASS '+name);}catch(e){results.push({name,passed:false,error:e.message});console.log('FAIL '+name+'\n  '+e.message);}}
function capture(fn){try{fn();return null;}catch(e){return e;}}
let setupError=null;
try{
  const baseline=storage();workingLedger();
  lab.analyzeDevHistory({orders});lab.runExperiment({orders});lab.runValidation({orders});
  check('changed physical data invalidates the learned template and active override',()=>{
    storage(baseline);workingLedger();lab.activate({orders});
    const changed=clone(orders),id=allowed.find(c=>c.set==='dev').orders[0];
    const item=changed.find(o=>o.order===id);
    item.qty+=10000;item.materialTypes+=500;item.bomLines+=500;item.faces=['BOT','TOP'];
    const a=sim.buildTaskSet([orders.find(o=>o.order===id)]).tasks,b=sim.buildTaskSet([item]).tasks;
    assert.ok(a.some((t,i)=>t.duration!==b[i].duration),'fixture must change the physical contract');
    const applicable=lab.computeApplicability(changed),override=lab.getActiveOverride(changed);
    assert.equal(applicable.applicable,false,'changed task durations still share the old valid digest');
    assert.equal(override,null,'old learned weights remained active on changed physical inputs');
    return {changedOrder:id,applicable:applicable.applicable};
  });
  check('a locked experiment cannot overwrite selection and validation in the same protocol',()=>{
    storage(baseline);workingLedger();
    const selection=store.readJSON('lab-selection.json'),validation=store.readJSON('lab-validation.json'),protocol=store.readJSON('lab-protocol.json');
    const before=solverCalls;
    capture(()=>lab.runExperiment({orders})); // Explicit refusal or read-only reuse are both acceptable.
    assert.equal(store.readJSON('lab-protocol.json').protocolId,protocol.protocolId);
    assert.equal(store.readJSON('lab-selection.json').selectionId,selection.selectionId,'locked selection was replaced without an explicit new experiment');
    assert.deepEqual(store.readJSON('lab-validation.json'),validation,'completed validation was overwritten or invalidated by an ordinary rerun');
    assert.equal(solverCalls,before,'same locked experiment performed another candidate search');
    return {protocolId:protocol.protocolId,extraSolverCalls:solverCalls-before};
  });
  let retryState=null;
  check('post-solve ledger failure reports actual execution and recovery fingerprints',()=>{
    const dir=storage(baseline);store.writeJSON('lab-validation.json',null);
    evaluation.setUsageSink(()=>{throw new Error('AUDIT_USAGE_WRITE_FAILURE');});
    const before=solverCalls,error=capture(()=>lab.runValidation({orders}));
    assert.ok(error,'ledger failure must not report success');
    retryState={dir,error,ran:solverCalls-before};
    if(retryState.ran>0){
      assert.equal(error.executed,true,'solvers already ran, but the error incorrectly says not executed');
      assert.ok(error.runId&&error.usedFingerprints&&error.usedFingerprints.length,'executed work needs a recoverable run ID and fingerprints');
    }else assert.equal(error.executed,false,'preflight rejection must truthfully say no execution');
    return {solverCalls:retryState.ran,executed:error.executed};
  });
  check('retry after ledger repair records the work before returning a usable validation',()=>{
    assert.ok(retryState,'previous test must have captured the failure');
    // The previous failure may deliberately be an assertion failure; its isolated state is retained.
    workingLedger();
    const before=solverCalls,result=lab.runValidation({orders});
    assert.ok(result&&result.caseCount>0,'retry must produce or recover the validation');
    assert.ok(ledger.length>0,'retry returned cached success while permanently skipping the missing usage record');
    const actual=new Set(ledger.flatMap(r=>r.caseFingerprints||r.fingerprints||[]));
    assert.ok(result.caseFingerprints.every(fp=>actual.has(fp)),'the recovered ledger omits validation fingerprints');
    return {ledgerCalls:ledger.length,extraSolverCalls:solverCalls-before};
  });
  check('all-failed scheduling preserves real attempt count and a business failure reason',()=>{
    workingLedger();
    const entry=allowed.find(c=>c.set==='dev'&&c.orders.length===1),selected=entry.orders.map(id=>orders.find(o=>o.order===id));
    const built=sim.buildTaskSet(selected);built.personnel=built.personnel.filter(p=>p.skill!=='quality');
    const error=capture(()=>scheduler.buildStrategyC(built.tasks,entry.orders,built.personnel,built.exclusive,built.equipment,20261021));
    assert.ok(error,'missing quality personnel must be infeasible');
    const attempts=error.candidateAttempts??error.attempts;
    assert.equal(attempts,42,'42 actual failed candidates lost their attempt count');
    assert.ok(!/Cannot read properties of null/.test(error.message),'infeasibility must retain its business cause');
    return {attempts,reason:error.message};
  });
}catch(e){setupError=e.stack;console.log('SETUP ERROR '+e.message);}finally{
  Object.assign(store,backup);scheduler.buildStrategyC=originals.C;scheduler.buildStrategyCLearned=originals.L;evaluation.setUsageSink(null);
}
const report={applicationRoot:root,note:'Isolated storage; real dev/validation solving only; no reserved solving or source edits.',setupError,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length,results};
fs.writeFileSync(output,JSON.stringify(report,null,2));console.log(`RESULT passed=${report.passed} failed=${report.failed} total=${results.length}`);
if(setupError||report.failed)process.exitCode=1;
