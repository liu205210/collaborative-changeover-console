'use strict'
// Read-only independent v6 probes; create only dev-style demo sessions, never evaluate reserved.
const path = require('path'); const fs = require('fs');
const root = path.resolve(process.argv[2]);
const collab = require(path.join(root, 'server/collaboration'));
const recovery = require(path.join(root, 'server/recovery'));
const loader = require(path.join(root, 'server/dataLoader'));
const evaluation = require(path.join(root, 'server/evaluation'));
const {orders} = loader.importWorkbook(loader.DEFAULT_XLSX);
// Read-only fixture guard: catalog construction does not call a solver or usage sink.
// Require this exact demo order combination to be both non-reserved and already used.
const usagePath=path.join(root,'release/round10/usage-record.json');
const usage=JSON.parse(fs.readFileSync(usagePath,'utf8'));
const usedFingerprints=new Set(usage.fingerprints||[]);
const catalog=evaluation.buildCaseCatalog(orders,Array.from(usedFingerprints));
const demoOrders=orders.slice(0,3);
const orderKey=ids=>ids.slice().sort().join('+');
const demoKey=orderKey(demoOrders.map(o=>o.order));
const matching=catalog.filter(c=>orderKey(c.orders)===demoKey);
if(matching.some(c=>c.set==='reserved')) throw Error('Refusing reserved order combination: '+demoKey);
const alreadyUsed=matching.filter(c=>c.set!=='reserved'&&usedFingerprints.has(c.fingerprint));
if(!alreadyUsed.length) throw Error('Demo combination is not evidenced as previously used: '+demoKey);
evaluation.runEvaluation=()=>{throw Error('This read-only audit must not run evaluation');};
const fixtureGuard={orderKey:demoKey,matchingUsedCases:alreadyUsed.map(c=>({id:c.id,set:c.set,fingerprint:c.fingerprint})),reservedOverlap:0,catalogOnly:true,usageEvidence:'release/round10/usage-record.json'};
const base = recovery.createSession({orders: demoOrders});
const untouchedBase=JSON.stringify(base);
const simple = t => ({id:t.id,key:t.key,start:t.start,end:t.end,result:t.result,kind:t.kind});
const changes = (a,b) => a.flatMap(t=>{const u=b.find(x=>x.id===t.id); return !u||JSON.stringify(simple(t))!==JSON.stringify(simple(u))?[{before:simple(t),after:u?simple(u):null}]:[]});
const fail = recovery.applyEvent(base,{type:'fai_fail',target:base.orderIds[0],at:0});
if(!fail.result.applied) throw Error(JSON.stringify(fail.result));
const fai = base.actualEntries.find(t=>t.order===base.orderIds[0]&&t.key==='fai_inspect');
const before = collab.snapshotFromSession(fail.bundle,{at:0});
const during = collab.snapshotFromSession(fail.bundle,{at:collab.r2((fai.start+fai.end)/2)});
// Pure in-memory state fixture: explicitly move its clock to all task completion.
// Do not interpret a requested at beyond the true session clock as executed history.
const completedStateFixture=structuredClone(fail.bundle);
completedStateFixture.clock=collab.r2(Math.max(...completedStateFixture.actualEntries.map(t=>t.end)));
const after = collab.snapshotFromSession(completedStateFixture,{});
const roleView=s=>{const q=collab.buildRoleStates(s).find(x=>x.id==='quality');return {knownEvents:s.knownEvents.length,observationTime:s.observationTime,quality:s.quality.find(x=>x.order===base.orderIds[0]),roleStatus:q.status,roleObservation:q.observation,request:q.request,failedTasks:q.tasks.filter(t=>t.result==='fail').map(t=>({...simple(t),status:t.status})),messages:collab.buildMessages(s).filter(m=>/异常|拦截|不合格|返工/.test(m.text)).map(m=>({time:m.time,reasonCode:m.reasonCode,text:m.text}))};};
const first = recovery.applyEvent(base,{type:'equipment_failure',target:'LINE-01',at:30,duration:10});
if(!first.result.applied) throw Error(JSON.stringify(first.result));
const second = recovery.applyEvent(first.bundle,{type:'equipment_failure',target:'LINE-01',at:31,duration:20});
if(!second.result.applied) throw Error(JSON.stringify(second.result));
const historicalFirst=collab.snapshotFromSession(first.bundle,{at:30});
const historicalAfterSecond=collab.snapshotFromSession(second.bundle,{at:30});
const explicitFirst=collab.snapshotFromSession(second.bundle,{eventIndex:1});
const out={
  fixtureGuard,
  completedStateFixture:{pureInMemory:true,originalClock:fail.bundle.clock,clock:completedStateFixture.clock,observationTime:after.observationTime,defaultCurrentSnapshot:true,persisted:false},
  failureLeak:{eventTrigger:fail.bundle.events[0].triggerAt,firstInspection:simple(fai),before:roleView(before),during:roleView(during),afterRecovery:roleView(after)},
  continuousHistory:{events:second.bundle.events.map(e=>({id:e.id,at:e.triggerAt,chosen:e.chosen,makespan:e.R1.metrics.makespan})),knownEventIdsAt30:historicalAfterSecond.knownEvents.map(e=>e.id),beforeSecondTaskCount:historicalFirst.tasks.length,afterSecondTaskCount:historicalAfterSecond.tasks.length,changes:changes(historicalFirst.tasks,historicalAfterSecond.tasks),explicitReplayDifferences:changes(explicitFirst.tasks,historicalAfterSecond.tasks)},
  originalBaseSessionUnchanged:JSON.stringify(base)===untouchedBase,
};
const sameAt = recovery.applyEvent(first.bundle,{type:'equipment_failure',target:'LINE-01',at:30,duration:20});
if(!sameAt.result.applied) throw Error(JSON.stringify(sameAt.result));
const a=collab.snapshotFromSession(first.bundle,{}),b=collab.snapshotFromSession(sameAt.bundle,{});
out.sameTimeDifferentContent={sameSnapshotId:a.snapshotId===b.snapshotId,sameDigest:a.contractDigest===b.contractDigest,actualFactsChanged:JSON.stringify(a.tasks)!==JSON.stringify(b.tasks),beforeEventCount:a.knownEvents.length,afterEventCount:b.knownEvents.length,firstMakespan:first.bundle.events[0].R1.metrics.makespan,secondMakespan:sameAt.bundle.events[1].R1.metrics.makespan,snapshotId:a.snapshotId,contractDigest:a.contractDigest};
const checks=[
 {name:'No future first-article failure at t=0',pass:!out.failureLeak.before.failedTasks.length&&out.failureLeak.before.quality.faiStatus!=='不合格'},
 {name:'No failure while first inspection is still in progress',pass:out.failureLeak.during.quality.faiStatus!=='不合格'},
 {name:'Earlier time uses corresponding saved schedule after a later event',pass:out.continuousHistory.changes.length===0},
 {name:'Same-time content mutation changes snapshot identity or digest',pass:!(out.sameTimeDifferentContent.sameSnapshotId&&out.sameTimeDifferentContent.sameDigest)},
 {name:'Recovered quality role is no longer actively blocked',pass:out.failureLeak.afterRecovery.roleStatus!=='异常'&&!/已拦截放行/.test(out.failureLeak.afterRecovery.request)}
];
out.checks=checks;out.passed=checks.filter(c=>c.pass).length;out.failed=checks.length-out.passed;
const target=process.argv[3]?path.resolve(process.argv[3]):path.join(__dirname,'time-semantics-output.json');fs.writeFileSync(target,JSON.stringify(out,null,2));
console.log(JSON.stringify({passed:out.passed,failed:out.failed,checks,output:target,fixtureGuard,completedStateFixture:out.completedStateFixture,leak:{trigger:out.failureLeak.eventTrigger,before:out.failureLeak.before.quality,during:out.failureLeak.during.quality},historicalChanges:out.continuousHistory.changes,sameTimeDifferentContent:out.sameTimeDifferentContent},null,2));
process.exitCode=out.failed?1:0;
