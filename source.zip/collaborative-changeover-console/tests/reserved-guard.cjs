'use strict';
// Preload guard only: original verification assertions remain unchanged.
const path = require('node:path');
const evaluation = require(path.join(process.cwd(),'server/evaluation.js'));
const original = evaluation.runEvaluation;
let calls = 0;
evaluation.runEvaluation = function(args) {
  if (Array.isArray(args.sets) && args.sets.includes('reserved')) {
    throw new Error('AUDIT GUARD: actual reserved solving is forbidden');
  }
  calls++;
  return original(args);
};
process.on('exit',()=>console.log(`AUDIT GUARD: actual runEvaluation calls=${calls}; no reserved-solving call permitted.`));
