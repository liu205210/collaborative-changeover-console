# 检查脚本的使用范围

本目录保留历史验收源脚本，并加入 `verify-playback.cjs`。仓库整理时没有重新运行全部历史验收，历史 PASS 数量不代表当前环境已经复验。

## 无原始工作簿的前端检查

安装 `web/` 依赖后，在仓库根目录运行：

```bash
node tests/verify-playback.cjs
```

检查使用脚本内的虚拟任务，读取并编译 `web/src/components/playback.ts`，不调用 API、求解器或网络，不写运行期存储。包括开始/结束边界、产线交接、人员去重、未知前序与输入不可变等 19 项断言。可选首参数为另一份应用根目录。

## 业务与历史验收

下列脚本是历史复现入口，必须先审阅其数据和输出路径，并在独立副本运行。需要传应用根目录的脚本可使用 `node tests/脚本名.cjs .`；部分脚本还接收第二个输出文件参数。未统一修改历史脚本的旧默认目录，不能直接假定省略参数可运行。

- `server/verify.js`、`server/lab-regressions.js`、`server/collab-regressions.js` 读取原赛题工作簿；部分断言绑定特定订单、数量和历史数据。`npm run verify` 不能在缺少原数据时视为可复验的完整检查。
- `drill-usage-acceptance.cjs`、`drill-publication-acceptance.cjs` 依赖原工作簿；发布检查复用同目录的演练记账检查。
- `assistant-evidence-audit.cjs`、`time-semantics-audit.cjs` 依赖 `release/round10/` 的历史协作或使用记录。
- `assistant-claim-contract-audit.cjs`、`assistant-selection-check.cjs`、`fragment-state-audit.cjs` 依赖 `release/round11/` 的历史协作、问答或使用记录。
- 其他脚本也可能生成临时目录、执行有限求解或写测试输出，运行前检查文件顶部的说明及参数。

原始工作簿与上述历史夹具没有随公开仓库发布；缺少它们时，请报告「依赖缺失」，不要改为跳过断言后声称全部通过。新的 reserved 保留集不得用于开发或参数调试。原项目历史账本、会话、待补记文件不可作为测试输出目录。
