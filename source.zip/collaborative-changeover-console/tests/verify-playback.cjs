// Frontend-only assertions. Fixtures below are test data, not evaluation results.
const fs = require('fs');
const path = require('path');
const assert = require('assert/strict');
const root = path.resolve(process.argv[2] || path.join(__dirname, '..'));
const ts = require(path.join(root, 'web/node_modules/typescript'));
const source = fs.readFileSync(path.join(root, 'web/src/components/playback.ts'), 'utf8');
const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 }}).outputText;
const mod = { exports: {} }; new Function('module', 'exports', js)(mod, mod.exports);
const p = mod.exports;
const entries = [
 {id:'a',start:0,end:2,assigneeId:'P1',assigneeName:'甲',deps:[],exclusive:'CAL',equipment:'EQ'},
 {id:'b',start:0,end:4,assigneeId:'P2',assigneeName:'乙',deps:[]},
 {id:'c',start:5,end:6,assigneeId:'P1',assigneeName:'甲',deps:['a','b']}
];
const windows = [{order:'A',onlineStart:2,onlineEnd:6},{order:'B',onlineStart:6,onlineEnd:8}];
let passes = 0;
function test(name, check) { check(); console.log(`PASS ${++passes}: ${name}`); }
test('t=0 counts actual starts, no premature completion', () => { const s=p.derivePlayback(entries,windows,0); assert.deepEqual([s.done.length,s.running.length,s.pending.length],[0,2,1]); });
test('completion boundary is end-exclusive', () => assert.equal(p.playbackTaskState(entries[0],2),'done'));
test('start boundary is inclusive', () => assert.equal(p.playbackTaskState(entries[2],5),'running'));
test('zero-duration entry completes at its boundary', () => assert.equal(p.playbackTaskState({start:1,end:1},1),'done'));
test('line stays locked in gap with no machining', () => { const s=p.derivePlayback(entries,windows,4.5); assert.equal(s.running.length,0); assert.equal(s.locked[0].order,'A'); });
test('line handover has only the new order', () => assert.deepEqual(p.activeLineWindows(windows,6).map(w=>w.order),['B']));
test('line unlocks after last window', () => assert.equal(p.activeLineWindows(windows,8).length,0));
test('current personnel are deduplicated by ID', () => assert.equal(p.derivePlayback([entries[0],{...entries[1],assigneeId:'P1'}],windows,1).assignees.size,1));
test('missing predecessor is not assumed complete', () => assert.equal(p.pendingPlaybackReason({deps:['missing']},new Map(),0),'前序记录未提供'));
test('unfinished predecessor remains blocked', () => assert.equal(p.pendingPlaybackReason(entries[2],new Map(entries.map(e=>[e.id,e])),3),'前序未完成'));
test('ready task does not invent a resource blockage', () => assert.equal(p.pendingPlaybackReason(entries[2],new Map(entries.map(e=>[e.id,e])),4),'按计划等待开始'));
test('invalid/reversed times are filtered', () => { assert.equal(p.isValidPlaybackEntry({start:NaN,end:5}),false); assert.equal(p.isValidPlaybackEntry({start:5,end:4}),false); });
test('time bounded to start/end', () => { assert.equal(p.clampPlaybackTime(-2,6),0); assert.equal(p.clampPlaybackTime(9,6),6); });
test('displayed clock never rounds into future completion', () => { const at=p.displayedPlaybackTime(1.996,6); assert.equal(at,1.99); assert.equal(p.playbackTaskState(entries[0],at),'running'); });
test('decimal boundary is displayed and evaluated consistently', () => { const at=p.displayedPlaybackTime(21.73,49.51); assert.equal(at,21.73); assert.equal(p.playbackTaskState({start:0,end:21.73},at),'done'); });
test('next/previous boundary includes line handover', () => { const b=p.playbackBoundaries(entries,windows,8); assert.equal(p.adjacentPlaybackBoundary(b,5,1),6); assert.equal(p.adjacentPlaybackBoundary(b,6,-1),5); });
test('only specified resources are displayed', () => assert.deepEqual(p.playbackEntryResources(entries[0]),['CAL','EQ']));
test('empty plan remains empty and bounded', () => { assert.equal(p.playbackDuration([],0),0); assert.equal(p.derivePlayback([],[],0).done.length,0); });
test('derived states do not mutate saved entries', () => { const before=JSON.stringify(entries); p.derivePlayback(entries,windows,3); assert.equal(JSON.stringify(entries),before); });
console.log(`${passes} PASS / 0 FAIL; no API or solver called.`);

