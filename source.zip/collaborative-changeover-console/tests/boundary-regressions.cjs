'use strict';

// Independent audit: node boundary-regressions.cjs [application-root]
const assert = require('node:assert/strict');
const path = require('node:path');
const appRoot = path.resolve(process.argv[2] || path.join(__dirname, '../v4.2.1/patch-candidate'));
const recovery = require(path.join(appRoot, 'server/recovery.js'));
const order = { order: 'O1', product: 'P1', qty: 100, bomLines: 10, materialTypes: 5, faces: ['A'] };
const close = (actual, expected, message) => assert.ok(Math.abs(actual - expected) < 1e-8,
  `${message}: expected ${expected}, got ${actual}`);
let passed = 0, failed = 0;
console.log(`Application root: ${appRoot}`);
console.log('Synthetic fixture: O1/P1, qty=100, BOM lines=10, material types=5, faces=[A].');

for (const at of [19.55, 19.64]) {
  const name = `CAL event at ${at} preserves exact remaining reinspection and execution fragments`;
  try {
    const session = recovery.createSession({ orders: [order] });
    const initial = recovery.applyEvent(session, { type: 'fai_fail', target: 'O1', at: 0 });
    assert.equal(initial.result.applied, true, initial.result.reason);
    const bundle = initial.bundle;
    const unchanged = JSON.stringify(bundle);
    const original = bundle.actualEntries.find(e => e.id === 'O1::recheck');
    assert.ok(original, 'fixture must contain reinspection');
    close(original.start, 16.65, 'fixture reinspection start');
    close(original.end, 19.65, 'fixture reinspection end');
    const event = { type: 'equipment_failure', target: 'CAL-01', at, duration: 1 };
    const input = recovery.buildRecoveryInput(bundle, event, recovery.snapshotAt(bundle, at));
    const remaining = Math.round((original.end - at) * 100) / 100;
    const unit = input.units.find(e => e.id === original.id);
    close(unit.duration, remaining, 'contract must preserve real remaining work');
    close(unit.remainingFrom, remaining, 'remaining fields must use consistent precision');
    const result = recovery.applyEvent(bundle, event);
    assert.equal(result.result.applied, true, result.result.reason);
    assert.equal(result.result.eventRecord.R0.validation.ok, true);
    assert.equal(result.result.eventRecord.R1.validation.ok, true);
    assert.equal(JSON.stringify(bundle), unchanged, 'input execution history must remain immutable');
    const records = result.bundle.actualEntries;
    const continuation = records.find(e => e.id === original.id);
    const fragments = records.filter(e => e.originId === original.id);
    assert.equal(fragments.length, 1, 'one actual reinspection fragment must be preserved');
    close(fragments[0].start, original.start, 'fragment actual start');
    close(fragments[0].end, at, 'fragment actual end');
    assert.equal(fragments[0].assigneeId, original.assigneeId, 'fragment actual assignee');
    close(continuation.start, at, 'unaffected reinspection resumes immediately');
    close(continuation.end, original.end, 'unrelated outage does not extend reinspection');
    close(continuation.end - continuation.start, remaining, 'continuation execution duration');
    close(fragments[0].end - fragments[0].start + continuation.end - continuation.start,
      original.duration, 'executed fragment plus continuation conserves total work');
    const release = records.find(e => e.id === 'O1::quality_release');
    assert.ok(release.start >= continuation.end - 1e-8, 'quality release must wait for reinspection');
    console.log(`PASS ${name} (remaining=${remaining}, fragment+continuation=${original.duration})`);
    passed++;
  } catch (error) {
    console.log(`FAIL ${name}\n  ${error.message}`);
    failed++;
  }
}
console.log(`RESULT passed=${passed} failed=${failed} total=${passed + failed}`);
process.exitCode = failed ? 1 : 0;
