'use strict'
const fs = require('fs')
const path = require('path')
const root = path.resolve(process.argv[2])
const assistant = require(path.join(root, 'server/assistant'))
const result = []
const rule = { conclusion: 'Server conclusion', claims: [{ id: 'a', text: 'Server claim A', evidenceRefs: ['metric:a'] }, { id: 'b', text: 'Server claim B', evidenceRefs: ['metric:b'] }], evidenceRefs: [{ ref: 'metric:a', value: 10, unit: '分钟' }, { ref: 'metric:b', value: 20, unit: '分钟' }] }
function check(id, ok, evidence) { result.push({ id, pass: ok, evidence }); console.log(`${ok ? 'PASS' : 'FAIL'} ${id}`) }
const ordered = assistant.validateModelOutput({ claimIds: ['b', 'a', 'b'], evidenceRefs: ['metric:b', 'metric:a'], explanation: '' }, rule)
check('SERVER_CLAIMS_SELECTED_IN_REQUESTED_ORDER', ordered.ok && ordered.selectedClaims.map(c => c.id).join(',') === 'b,a', ordered)
const bound = assistant.validateModelOutput({ claimIds: ['a'], evidenceRefs: ['metric:b'], explanation: '' }, rule)
check('UNRELATED_VALID_REFERENCE_IS_REJECTED', !bound.ok, bound)
const echo = assistant.validateModelOutput({ claimIds: ['a'], evidenceRefs: ['metric:a'], explanation: 'Server claim A' }, rule)
check('EXACT_SERVER_CLAIM_ECHO_IS_ALLOWED', echo.ok, echo)
;(async () => {
  const e = JSON.parse(fs.readFileSync(path.join(root, 'release/round11/console-execution.json'), 'utf8'))
  const snapshot = { ...e.snapshot, tasks: [...new Map(e.roles.flatMap(r => r.tasks).map(t => [t.id, t])).values()] }
  const priorProvider = process.env.LLM_PROVIDER
  process.env.LLM_PROVIDER = 'stub'
  try {
    const question = `订单 ${snapshot.orders[0].order} 现在能否放行？`
    const expected = assistant.answerQuestion({ question, snapshot })
    const answer = await assistant.explain({ question, snapshot, allowModel: true })
    check('STUB_RETAINS_RULE_AND_IS_NOT_REAL_MODEL', answer.mode === 'stub' && answer.conclusion === expected.conclusion && answer.modelInfo.realCallVerified === false, { mode: answer.mode, conclusion: answer.conclusion, modelInfo: answer.modelInfo })
  } finally { if (priorProvider === undefined) delete process.env.LLM_PROVIDER; else process.env.LLM_PROVIDER = priorProvider }
  const output = { source: 'independent post-patch bounded contract checks', realModelCalled: false, reservedSolved: false, passed: result.filter(x => x.pass).length, failed: result.filter(x => !x.pass).length, records: result }
  fs.writeFileSync(process.argv[3] || path.join(__dirname, 'assistant-selection-check.json'), JSON.stringify(output, null, 2))
  process.exitCode = output.failed ? 1 : 0
})().catch(e => { console.error(e); process.exitCode = 2 })
