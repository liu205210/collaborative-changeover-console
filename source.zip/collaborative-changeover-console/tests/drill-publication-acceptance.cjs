'use strict'
// node drill-publication-acceptance.cjs APP_ROOT [OUTPUT_JSON]
// Uses the unchanged prior acceptance harness; colocate it when packaging this test.
const fs=require('fs'),path=require('path'),assert=require('assert/strict')
const colocated=path.join(__dirname,'drill-usage-acceptance.cjs')
const harnessFile=fs.existsSync(colocated)?colocated:path.resolve(__dirname,'../audit-v6/drill-usage-acceptance.cjs')
let src=fs.readFileSync(harnessFile,'utf8').split('const results=[]')[0]
src=src.replace('function harness(){','function harness(seedMemory){')
src=src.replace("const memory=new Map([['dataset.json',clone(data)]])","const memory=seedMemory||new Map([['dataset.json',clone(data)]])")
src=src.replace('let failLedger=false','let failLedger=false,failPublication=false,failRecovery=false')
src=src.replace("writeJSON:(n,v)=>{if(n==='eval-usage.json'", "writeJSON:(n,v)=>{if(n==='simulation.json'&&failPublication)throw new Error('AUDIT_SIMULATION_PUBLICATION_FAILURE');if(n==='eval-usage.json'")
src=src.replace('eventExecutions:0','eventExecutions:0,scheduleRecovery:0')
src=src.replace('console:{log(){},error(...a)', '__auditSchedule:()=>{counts.scheduleRecovery++},__auditAfterSchedule:()=>{if(failRecovery)throw new Error("AUDIT_POST_SCHEDULE_FAILURE")},console:{log(){},error(...a)')
src=src.replace("vm.runInNewContext(fs.readFileSync(file,'utf8'),context,{filename:file})", "vm.runInNewContext(fs.readFileSync(file,'utf8')+(path.basename(file)==='recovery.js'?'\\nconst __auditOriginalSchedule=scheduleRecovery; scheduleRecovery=(...args)=>{__auditSchedule();const result=__auditOriginalSchedule(...args);__auditAfterSchedule();return result};':''),context,{filename:file})")
src=src.replace('setFault(v){failLedger=v}', 'setFault(v){failLedger=v},setPublicationFault(v){failPublication=v},setRecoveryFault(v){failRecovery=v}')
const owned={exports:{}}
new Function('require','module','__dirname',src+'\nmodule.exports={harness,dev,metadata,preservedEvidence};')(require,owned,path.dirname(harnessFile))
const{harness,dev,metadata,preservedEvidence}=owned.exports
const resetInput={orders:dev.orders},ids=h=>h.ledger().runs.map(r=>r.runId)
const output=path.resolve(process.argv[3]||path.join(__dirname,'drill-publication-acceptance-output.json'))
const results=[]
function check(name,fn){try{const details=fn();results.push({name,passed:true,details});console.log('PASS '+name)}catch(e){results.push({name,passed:false,error:e.message});console.log('FAIL '+name+' — '+e.message)}}
function failedPublished(h,r){assert.ok(r.status>=400);const m=metadata(r);assert.equal(m.executed,true);assert.ok(m.runId&&m.fingerprints.length);assert.ok(preservedEvidence(h,m),'Published failure must retain the original complete recovery record');assert.ok(ids(h).includes(m.runId),'Ledger should already contain this run');return m}
function recovered(h,r,m){assert.equal(r.status,200);assert.equal(r.body.runId,m.runId);assert.ok(r.body.recovered);assert.equal(new Set(ids(h)).size,ids(h).length);assert.ok(ids(h).includes(m.runId));return{runId:m.runId,createSession:h.counts.createSession,applyEvent:h.counts.applyEvent}}
;(async()=>{
 let setupError=null
 try{
  const r=harness();r.setPublicationFault(true)
  const rFail=await r.call('POST','/api/simulate/reset',resetInput),rInfo=metadata(rFail)
  check('reset publication failure keeps executed evidence and does not expose an unpublished session',()=>{const info=failedPublished(r,rFail);assert.equal(r.memory.has('simulation.json'),false);return{...info,ledger:ids(r)}})
  const rr=harness(r.memory),rrResult=await rr.call('POST','/api/simulate/reset',resetInput)
  check('reset restart retry publishes the original run without solving again',()=>{assert.equal(rr.counts.createSession,0);return recovered(rr,rrResult,rInfo)})
  const e=harness(),init=await e.call('POST','/api/simulate/reset',resetInput),delivery=init.body.actualEntries.find(t=>t.key==='material_deliver')
  const event={type:'agv_delay',target:delivery.id,at:delivery.start,delay:10}
  e.setPublicationFault(true)
  const eFail=await e.call('POST','/api/simulate/event',event),eInfo=metadata(eFail),visible=await e.call('GET','/api/simulate')
  check('event publication failure retains evidence while stored and visible session stay unchanged',()=>{const info=failedPublished(e,eFail);assert.equal(e.memory.get('simulation.json').events.length,0);assert.equal(visible.body.events.length,0);return{...info,storedEvents:0}})
  const er=harness(e.memory),erResult=await er.call('POST','/api/simulate/event',event)
  check('event restart retry publishes the original result without duplicate solving or ledger entry',()=>{assert.equal(er.counts.applyEvent,0);assert.equal(erResult.body.session.events.length,1);return recovered(er,erResult,eInfo)})
  const p=harness();p.setFault(true)
  const pFailure=await p.call('POST','/api/simulate/reset',resetInput),pInfo=metadata(pFailure)
  p.setFault(false);p.setPublicationFault(true)
  const pSecond=await p.call('POST','/api/simulate/reset',resetInput)
  const retained=preservedEvidence(p,pInfo),pRestart=harness(p.memory),pRetry=await pRestart.call('POST','/api/simulate/reset',resetInput)
  check('recovery publication failure retains the same pending run through restart',()=>{assert.equal(metadata(pSecond).executed,true);assert.equal(metadata(pSecond).runId,pInfo.runId);assert.ok(retained);assert.equal(pRestart.counts.createSession,0);return recovered(pRestart,pRetry,pInfo)})
  const cr=harness();cr.setFault(true)
  const crFail=await cr.call('POST','/api/simulate/reset',resetInput),crInfo=metadata(crFail),crBefore=JSON.stringify([...cr.memory])
  cr.setFault(false)
  const crOther=await cr.call('POST','/api/simulate/reset',{...resetInput,seed:20261006})
  check('different reset input returns conflict without consuming or overwriting pending work',()=>{assert.equal(crOther.status,409);assert.equal(metadata(crOther).runId,crInfo.runId);assert.equal(JSON.stringify([...cr.memory]),crBefore);assert.equal(cr.counts.createSession,1);return{status:crOther.status,runId:crInfo.runId}})
  const ce=harness();await ce.call('POST','/api/simulate/reset',resetInput);ce.setFault(true)
  const ceFail=await ce.call('POST','/api/simulate/event',event),ceInfo=metadata(ceFail),ceBefore=JSON.stringify([...ce.memory]),calls=ce.counts.applyEvent
  ce.setFault(false)
  const ceOther=await ce.call('POST','/api/simulate/event',{...event,delay:20})
  check('different event input returns conflict without consuming or overwriting pending work',()=>{assert.equal(ceOther.status,409);assert.equal(metadata(ceOther).runId,ceInfo.runId);assert.equal(JSON.stringify([...ce.memory]),ceBefore);assert.equal(ce.counts.applyEvent,calls);return{status:ceOther.status,runId:ceInfo.runId}})
  const f=harness();await f.call('POST','/api/simulate/reset',resetInput);f.setRecoveryFault(true);f.setFault(true)
  const failureEvent={type:'equipment_failure',target:'LINE-01',at:1,duration:10},fFail=await f.call('POST','/api/simulate/event',failureEvent),fInfo=metadata(fFail),callsBefore=f.counts.scheduleRecovery
  f.setFault(false);f.setRecoveryFault(false)
  const fRetry=await f.call('POST','/api/simulate/event',failureEvent)
  check('a failed real recovery attempt is recorded and retried without re-solving or losing its rejection',()=>{assert.equal(fFail.status,500);assert.equal(fInfo.executed,true);assert.equal(callsBefore,1);assert.equal(f.counts.scheduleRecovery,callsBefore);assert.equal(fRetry.body.applied,false);assert.equal(fRetry.body.infeasible,true);assert.match(fRetry.body.reason,/AUDIT_POST_SCHEDULE_FAILURE/);return recovered(f,fRetry,fInfo)})
 }catch(error){setupError=error.stack||error.message}
 const out={applicationRoot:path.resolve(process.argv[2]),scope:'Drill publication durability, same/different request recovery and failed-attempt bookkeeping only. Real single-order dev scheduling, isolated storage, no reserved/model calls. Failed attempt uses a controlled exception after real scheduleRecovery.',setupError,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length,results}
 fs.writeFileSync(output,JSON.stringify(out,null,2));console.log(`RESULT passed=${out.passed} failed=${out.failed} total=${results.length}`);if(setupError)console.error(setupError);if(out.failed||setupError)process.exitCode=1
})()
