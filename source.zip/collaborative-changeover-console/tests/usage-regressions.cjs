'use strict'
// Usage: node usage-regressions.cjs APP_ROOT [OUTPUT_JSON]
// Runs only dev single-order cases. All ledgers live in an isolated audit directory.
const fs = require('fs')
const path = require('path')
const vm = require('vm')
const assert = require('assert')
const { createRequire } = require('module')
const root = path.resolve(process.argv[2] || '')
const output = path.resolve(process.argv[3] || path.join(__dirname, 'usage-regressions-output.json'))
const filename = path.join(root, 'server/evaluation.js')
const localRequire = createRequire(filename)
const loader = localRequire('./dataLoader')
const { orders } = loader.importWorkbook(loader.DEFAULT_XLSX)
const scheduler = localRequire('./scheduler')
const originalBuild = scheduler.buildSchedules
let solverCalls = 0
scheduler.buildSchedules = (...args) => { solverCalls++; return originalBuild(...args) }
const args = { orders, sets: ['dev'], categories: ['静态-单订单'] }
const auditDir = fs.mkdtempSync(path.join(__dirname, 'usage-ledger-'))
let serial = 0
function fresh() {
  const directory = path.join(auditDir, String(++serial))
  fs.mkdirSync(directory)
  const state = { writes: 0, failWrite: null }
  const store = {
    STORE_DIR: directory,
    writeJSON(name, value) {
      state.writes++
      if (state.failWrite && state.failWrite(state.writes)) throw new Error('AUDIT_STORAGE_UNAVAILABLE')
      const target = path.join(directory, name)
      fs.writeFileSync(target + '.tmp', JSON.stringify(value), 'utf8')
      fs.renameSync(target + '.tmp', target)
    }
  }
  const context = {
    module: { exports: {} },
    require(name) { return name === './store' ? store : localRequire(name) },
    process, performance, console, Date
  }
  vm.runInNewContext(fs.readFileSync(filename, 'utf8'), context, { filename })
  return { evaluation: context.module.exports, directory, state, ledger: () => JSON.parse(fs.readFileSync(path.join(directory, 'eval-usage.json'), 'utf8')) }
}
const results = []
function check(name, run) {
  try { const detail = run(); results.push({ name, passed: true, detail: detail || null }) }
  catch (error) { results.push({ name, passed: false, error: error.message }) }
}
function capture(fn) { try { fn(); return null } catch (error) { return error } }
try {
  check('Default CLI ledger persists actual dev fingerprints and historical 10 idempotently', () => {
    const t = fresh()
    const first = t.evaluation.runEvaluation(args)
    const initial = t.ledger()
    assert(first.caseCount > 0)
    assert.strictEqual(first.sets.reserved, 0)
    assert(first.usedFingerprints.every(fp => initial.fingerprints.includes(fp)))
    assert(t.evaluation.HISTORICAL_RESERVED_USED_FP.every(fp => initial.fingerprints.includes(fp)))
    assert.strictEqual(initial.history.length, 10)
    assert(initial.runs.some(r => r.runId === first.runId))
    t.evaluation.runEvaluation(args)
    const second = t.ledger()
    assert.strictEqual(second.history.length, 10)
    assert.strictEqual(new Set(second.fingerprints).size, second.fingerprints.length)
    return { devCases: first.caseCount, historicalCount: second.history.length, reservedSolved: 0 }
  })
  check('Unavailable default storage rejects before any solver call', () => {
    const t = fresh(); t.state.failWrite = () => true
    const before = solverCalls
    const error = capture(() => t.evaluation.runEvaluation(args))
    assert(error, 'Expected explicit preflight error')
    assert.strictEqual(solverCalls, before)
    assert.strictEqual(error.code, 'EVALUATION_USAGE_UNAVAILABLE')
    assert.strictEqual(error.executed, false)
    assert.strictEqual(error.usedFingerprints.length, 0)
    return { solverCalls: solverCalls - before, code: error.code, executed: error.executed }
  })
  check('Malformed existing ledger is not treated as an unused empty ledger', () => {
    const t = fresh(); const bad = '{broken'
    fs.writeFileSync(path.join(t.directory, 'eval-usage.json'), bad)
    const before = solverCalls
    const error = capture(() => t.evaluation.runEvaluation(args))
    assert(error, 'Expected corrupt-ledger error')
    assert.strictEqual(solverCalls, before)
    assert.strictEqual(error.executed, false)
    assert.strictEqual(fs.readFileSync(path.join(t.directory, 'eval-usage.json'), 'utf8'), bad)
    return { solverCalls: 0, ledgerPreserved: true }
  })
  check('Post-solve default write failure includes runId, used fingerprints and report', () => {
    const t = fresh(); t.state.failWrite = count => count === 2
    const before = solverCalls
    const error = capture(() => t.evaluation.runEvaluation(args))
    assert(error, 'Expected explicit post-solve error')
    assert(solverCalls > before)
    assert.strictEqual(error.executed, true)
    assert(error.runId && error.usedFingerprints.length > 0 && error.report)
    assert.strictEqual(error.runId, error.report.runId)
    assert(error.message.includes(error.runId) && error.message.includes(error.usedFingerprints[0]))
    assert.strictEqual(error.report.sets.reserved, 0)
    return { code: error.code, executed: true, devCases: error.report.caseCount, fingerprintCount: error.usedFingerprints.length }
  })
  check('Custom synchronous sink remains compatible; null restores default persistence', () => {
    const t = fresh(); const recorded = []
    t.evaluation.setUsageSink(record => recorded.push(record))
    const report = t.evaluation.runEvaluation(args)
    assert.strictEqual(recorded.length, 1)
    assert.strictEqual(JSON.stringify(recorded[0].fingerprints), JSON.stringify(report.usedFingerprints))
    t.evaluation.setUsageSink(null)
    const fallback = t.evaluation.runEvaluation(args)
    assert(t.ledger().runs.some(r => r.runId === fallback.runId))
    return { customCalls: recorded.length, restoredDefault: true }
  })
  check('Custom sink failure is explicit after actual dev evaluation, with recovery evidence', () => {
    const t = fresh()
    t.evaluation.setUsageSink(() => { throw new Error('AUDIT_CUSTOM_SINK_FAILURE') })
    const error = capture(() => t.evaluation.runEvaluation(args))
    assert(error, 'Custom sink failure was swallowed')
    assert.strictEqual(error.executed, true)
    assert(error.runId && error.usedFingerprints.length === error.report.caseCount)
    assert(error.message.includes('AUDIT_CUSTOM_SINK_FAILURE'))
    assert.strictEqual(error.report.sets.reserved, 0)
    return { code: error.code, devCases: error.report.caseCount, usedFingerprints: error.usedFingerprints.length }
  })
  check('Pure reserved selection does not solve, write a ledger or call the sink', () => {
    const t = fresh(); let sinkCalls = 0
    t.evaluation.setUsageSink(() => { sinkCalls++ })
    const before = solverCalls
    const selection = t.evaluation.selectCases(t.evaluation.buildCaseCatalog(orders), { sets: ['reserved'] })
    assert(selection.selected.length > 0)
    assert.strictEqual(solverCalls, before)
    assert.strictEqual(t.state.writes, 0)
    assert.strictEqual(sinkCalls, 0)
    return { selectedOnly: selection.selected.length, solved: 0, writes: 0, sinkCalls: 0 }
  })
} finally { scheduler.buildSchedules = originalBuild }
const report = { applicationRoot: root, note: 'No reserved solver execution; only dev single-order cases were solved. Business source unchanged by this script.', ledgerDirectory: auditDir, passed: results.filter(r => r.passed).length, failed: results.filter(r => !r.passed).length, results }
fs.writeFileSync(output, JSON.stringify(report, null, 2)); console.log(JSON.stringify(report, null, 2))
if (report.failed) process.exitCode = 1
