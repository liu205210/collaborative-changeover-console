'use strict';
// Narrow follow-up to v6 time fixes: completed fragments vs current whole-task status.
// No business-source writes, no runtime-store writes, no reserved evaluation.
const fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve(process.argv[2]);
const collab=require(path.join(root,'server/collaboration'));
const recovery=require(path.join(root,'server/recovery'));
const evaluation=require(path.join(root,'server/evaluation'));
const loader=require(path.join(root,'server/dataLoader'));
const {orders}=loader.importWorkbook(loader.DEFAULT_XLSX);
const usage=JSON.parse(fs.readFileSync(path.join(root,'release/round11/usage-record.json'),'utf8'));
const used=new Set(usage.fingerprints||[]),demo=orders.slice(0,3);
const key=xs=>xs.slice().sort().join('+'),demoKey=key(demo.map(o=>o.order));
const matching=evaluation.buildCaseCatalog(orders,[...used]).filter(c=>key(c.orders)===demoKey);
assert(!matching.some(c=>c.set==='reserved'),'Refusing reserved order combination');
assert(matching.some(c=>c.set!=='reserved'&&used.has(c.fingerprint)),'Demo lacks used-case evidence');
evaluation.runEvaluation=()=>{throw Error('Evaluation is forbidden in this read-only audit');};
const base=recovery.createSession({orders:demo});
const fault=recovery.applyEvent(base,{type:'equipment_failure',target:'LINE-01',at:30,duration:10});
assert(fault.result.applied,'Fault must apply');
const inspect=base.actualEntries.find(t=>t.key==='fai_inspect'&&t.start<30&&t.end>30);
assert(inspect,'Fixture inspection must span t=30');
const owner=inspect.order;
const view=s=>({at:s.observationTime,quality:s.quality.find(q=>q.order===owner),inspectionParts:s.tasks.filter(t=>t.order===owner&&t.key==='fai_inspect').map(t=>({id:t.id,originId:t.originId,kind:t.kind,status:t.status,result:t.result,start:t.start,end:t.end})),roles:collab.buildRoleStates(s).filter(r=>r.blocked.length).map(r=>({id:r.id,status:r.status,observation:r.observation,request:r.request,blocked:r.blocked})),gateMessages:collab.buildMessages(s).filter(m=>['GATE_PASS','GATE_FAIL','GATE_HISTORICAL'].includes(m.reasonCode)&&m.text.includes(owner)).map(m=>({time:m.time,reasonCode:m.reasonCode,text:m.text}))});
const trigger=collab.snapshotFromSession(fault.bundle,{});
// Completed clock is a pure in-memory state fixture, never a speculative future at request.
const done=structuredClone(fault.bundle);done.clock=Math.max(...done.actualEntries.map(t=>t.end));
const completed=collab.snapshotFromSession(done,{});
const fail=recovery.applyEvent(fault.bundle,{type:'fai_fail',target:owner,at:32.9});
assert(fail.result.applied,'Second first-article failure must apply');
const failed=collab.snapshotFromSession(fail.bundle,{});
const evidence={fixtureGuard:{orderKey:demoKey,cases:matching.filter(c=>used.has(c.fingerprint)).map(c=>({id:c.id,set:c.set})),reservedOverlap:0},originalInspection:{id:inspect.id,start:inspect.start,end:inspect.end},afterFault:view(trigger),completedFixture:{pureInMemory:true,originalClock:fault.bundle.clock,clock:done.clock,...view(completed)},afterFailure:view(failed)};
const checks=[
 {name:'Frozen first-inspection fragment does not satisfy full inspection or issue pass',pass:!evidence.afterFault.quality.faiComplete&&evidence.afterFault.quality.faiStatus!=='合格'&&!evidence.afterFault.gateMessages.some(m=>m.reasonCode==='GATE_PASS')},
 {name:'Whole first-inspection failure remains visible after an earlier split',pass:evidence.afterFailure.quality.faiStatus==='不合格'&&!evidence.afterFailure.gateMessages.some(m=>m.reasonCode==='GATE_PASS')},
 {name:'All completed continuations resolve historical paused-fragment blockers',pass:evidence.completedFixture.roles.length===0}
];
const out={...evidence,checks,passed:checks.filter(c=>c.pass).length,failed:checks.filter(c=>!c.pass).length};
const outputPath=process.argv[3]?path.resolve(process.argv[3]):path.join(__dirname,'fragment-state-output.json');
fs.writeFileSync(outputPath,JSON.stringify(out,null,2));
console.log(JSON.stringify(out,null,2));process.exitCode=out.failed?1:0;
