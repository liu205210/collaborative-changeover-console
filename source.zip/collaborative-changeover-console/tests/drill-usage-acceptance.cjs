'use strict'
// Usage: node drill-usage-acceptance.cjs APP_ROOT [OUTPUT_JSON]
// Isolated registered HTTP handlers + real dev-only recovery. No server/model/reserved calls.
// Behavior assertions allow either rejection before solving or durable recovery after solving.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert/strict'),{createRequire}=require('module')
const root=path.resolve(process.argv[2]||path.join(__dirname,'../v6/application'))
const output=path.resolve(process.argv[3]||path.join(__dirname,'drill-usage-acceptance-output.json'))
const native=createRequire(path.join(root,'package.json')),loaderFile=path.join(root,'server/dataLoader.js')
const loader={module:{exports:{}},require:createRequire(loaderFile),__dirname:path.dirname(loaderFile),console}
vm.runInNewContext(fs.readFileSync(loaderFile,'utf8')+'\nensureDirs=()=>{};',loader,{filename:loaderFile})
const data=loader.module.exports.importWorkbook(path.join(root,'data/upload/赛道数据包.xlsx'))
const catalog=native('./server/evaluation').buildCaseCatalog(data.orders)
const dev=catalog.find(c=>c.kind==='static'&&c.set==='dev'&&c.orders.length===1)
assert.ok(dev,'A one-order dev case is required')
assert.ok(!catalog.filter(c=>c.set==='reserved').some(c=>c.orders.slice().sort().join('+')===dev.orders.slice().sort().join('+')))
const clone=x=>JSON.parse(JSON.stringify(x))
function harness(){
 const memory=new Map([['dataset.json',clone(data)]]),routes=new Map(),cache=new Map(),errors=[]
 const counts={createSession:0,applyEvent:0,eventExecutions:0}
 let failLedger=false
 const store={STORE_DIR:path.join(__dirname,'virtual-store-unused'),readJSON:(n,f=null)=>memory.has(n)?clone(memory.get(n)):f,writeJSON:(n,v)=>{if(n==='eval-usage.json'&&failLedger)throw new Error('AUDIT_DRILL_LEDGER_UNAVAILABLE');memory.set(n,clone(v));return n}}
 const app={use(){},get(p,f){routes.set('GET '+p,f)},post(p,f){routes.set('POST '+p,f)},listen(){}}
 const express=()=>app;express.json=()=>()=>{};express.static=()=>()=>{}
 function load(file){
  if(cache.has(file))return cache.get(file).exports
  const mod={exports:{}};cache.set(file,mod)
  const local=createRequire(file)
  const localRequire=n=>{
   if(n==='express')return express
   if(n==='cors'||n==='compression')return()=>()=>{}
   if(n==='./store')return store
   if(n==='./dataLoader')return{...loader.module.exports,ensureDirs:()=>{}}
   const resolved=local.resolve(n)
   if(resolved.startsWith(path.join(root,'server')+path.sep)&&resolved.endsWith('.js'))return load(resolved)
   return local(n)
  }
  const context={module:mod,exports:mod.exports,require:localRequire,__dirname:path.dirname(file),__filename:file,console:{log(){},error(...a){errors.push(a.map(String).join(' '))}},process,performance,Date,Buffer,URL,URLSearchParams,setTimeout,clearTimeout,AbortController,fetch:()=>Promise.reject(new Error('AUDIT: external model/network calls forbidden'))}
  vm.runInNewContext(fs.readFileSync(file,'utf8'),context,{filename:file})
  if(path.basename(file)==='recovery.js'){
   const create=mod.exports.createSession,apply=mod.exports.applyEvent
   mod.exports.createSession=args=>{assert.equal(args.orders.map(o=>o.order).sort().join('+'),dev.orders.slice().sort().join('+'),'AUDIT: only dev group may solve');counts.createSession++;return create(args)}
   mod.exports.applyEvent=(bundle,ev)=>{assert.equal(bundle.orderIds.slice().sort().join('+'),dev.orders.slice().sort().join('+'),'AUDIT: only dev group may solve');counts.applyEvent++;const result=apply(bundle,ev);if(!result.result.duplicate&&!result.result.late&&result.result.applicable!==false)counts.eventExecutions++;return result}
  }
  return mod.exports
 }
 load(path.join(root,'server/index.js'))
 const call=async(method,url,body={})=>{const result={status:200,body:null},res={status(n){result.status=n;return this},json(v){result.body=clone(v);return this},send(v){result.body=v;return this},setHeader(){}};await routes.get(method+' '+url)({body,query:{}},res);return result}
 const ledger=()=>memory.get('eval-usage.json')||{runs:[],fingerprints:[]}
 return{memory,counts,errors,call,ledger,setFault(v){failLedger=v}}
}
function metadata(response){
 const nodes=[]
 function walk(v){if(!v||typeof v!=='object')return;nodes.push(v);for(const x of Object.values(v))walk(x)}
 walk(response.body)
 // A recovery record embedded in a human-readable error also carries usable evidence.
 for(const message of nodes.flatMap(n=>Object.values(n)).filter(x=>typeof x==='string')){
  for(const part of message.match(/\{[^{}]*\"runId\"[^{}]*\}/g)||[])try{walk(JSON.parse(part))}catch{}
 }
 const runId=nodes.find(n=>typeof n.runId==='string'&&n.runId)?.runId||null
 const fingerprints=nodes.flatMap(n=>['usedFingerprints','fingerprints','caseFingerprints'].flatMap(k=>Array.isArray(n[k])?n[k].filter(x=>typeof x==='string'):[]))
 let executed=nodes.find(n=>typeof n.executed==='boolean')?.executed
 if(executed===undefined){const message=JSON.stringify(response.body);if(/已执行|已求解/.test(message))executed=true;else if(/未执行|未求解/.test(message))executed=false}
 return{executed,runId,fingerprints:[...new Set(fingerprints)]}
}
function preservedEvidence(h,info){
 // No pending filename or error code is prescribed. A durable non-ledger record must
 // preserve this runId and its fingerprints; the subsequent retry proves usability.
 return [...h.memory].filter(([n])=>n!=='eval-usage.json'&&n!=='dataset.json').some(([,v])=>{const t=JSON.stringify(v);return info.runId&&t.includes(info.runId)&&info.fingerprints.every(f=>t.includes(f))})
}
function failureCheck(h,response,executions){
 assert.ok(response.status>=400,'Ledger failure must be explicit in the HTTP response')
 const info=metadata(response)
 assert.equal(info.executed,executions>0,'Reported executed state must match actual solving')
 if(executions>0){assert.ok(info.runId,'Executed failure needs its real runId');assert.ok(info.fingerprints.length,'Executed failure needs recovery fingerprints');assert.ok(info.fingerprints.some(f=>dev.orders.every(id=>f.includes(id))),'Fingerprint must identify the executed dev input');assert.ok(preservedEvidence(h,info),'Executed work must remain durably recoverable before a success is published')}
 return{executions,...info,preserved:executions>0?preservedEvidence(h,info):null}
}
function retryCheck(h,first,retry,beforeExecutions,afterExecutions,baselineRunIds){
 assert.ok(retry.status>=200&&retry.status<300,'Retry after ledger repair must succeed')
 const info=metadata(first),alreadyExecuted=beforeExecutions>0
 assert.equal(afterExecutions-beforeExecutions,alreadyExecuted?0:1,'Retry must recover executed work; only a pre-solve rejection may solve for the first time')
 const added=h.ledger().runs.filter(r=>!baselineRunIds.has(r.runId)&&r.stage==='drill')
 assert.ok(added.length,'Retry must fill the missing drill usage record')
 assert.equal(new Set(h.ledger().runs.map(r=>r.runId)).size,h.ledger().runs.length,'Retry must not duplicate run IDs')
 if(alreadyExecuted){assert.ok(info.runId,'Original executed error must expose runId');assert.ok(added.some(r=>r.runId===info.runId),'Retry must record the original runId');const recorded=new Set(added.flatMap(r=>r.caseFingerprints||r.fingerprints||[]));assert.ok(info.fingerprints.length&&info.fingerprints.every(f=>recorded.has(f)),'Retry must record the original fingerprints')}
 return{initialExecuted:alreadyExecuted,extraExecutions:afterExecutions-beforeExecutions,addedRunIds:added.map(r=>r.runId)}
}
const results=[]
function check(name,fn){try{const details=fn();results.push({name,passed:true,details});console.log('PASS '+name)}catch(e){results.push({name,passed:false,error:e.message});console.log('FAIL '+name+' — '+e.message)}}
;(async()=>{
 let setupError=null
 try{
  const reset=harness(),resetBase=new Set(reset.ledger().runs.map(r=>r.runId))
  reset.setFault(true)
  const resetFailure=await reset.call('POST','/api/simulate/reset',{orders:dev.orders}),resetBefore=reset.counts.createSession
  check('reset ledger failure is explicit and either refuses solving or preserves executed work',()=>failureCheck(reset,resetFailure,resetBefore))
  reset.setFault(false)
  const resetRetry=await reset.call('POST','/api/simulate/reset',{orders:dev.orders})
  check('reset retry records the original work without solving twice',()=>retryCheck(reset,resetFailure,resetRetry,resetBefore,reset.counts.createSession,resetBase))
  const event=harness()
  const initialized=await event.call('POST','/api/simulate/reset',{orders:dev.orders})
  assert.equal(initialized.status,200,'Event setup must initialize a dev session')
  const delivery=initialized.body.actualEntries.find(e=>e.key==='material_deliver')
  const input={type:'agv_delay',target:delivery.id,at:delivery.start,delay:10},eventBase=new Set(event.ledger().runs.map(r=>r.runId))
  event.setFault(true)
  const eventFailure=await event.call('POST','/api/simulate/event',input),eventBefore=event.counts.eventExecutions
  check('event ledger failure is explicit and either refuses solving or preserves executed work',()=>failureCheck(event,eventFailure,eventBefore))
  event.setFault(false)
  const eventRetry=await event.call('POST','/api/simulate/event',input)
  check('event retry fills usage rather than permanently skipping it as a duplicate',()=>retryCheck(event,eventFailure,eventRetry,eventBefore,event.counts.eventExecutions,eventBase))
  const readOnly=harness();await readOnly.call('POST','/api/simulate/reset',{orders:dev.orders})
  const before={counts:clone(readOnly.counts),ledger:JSON.stringify(readOnly.ledger())},consoleResult=await readOnly.call('GET','/api/collab/console')
  check('read-only collaboration console neither solves nor writes usage',()=>{assert.equal(consoleResult.status,200);assert.deepEqual(readOnly.counts,before.counts);assert.equal(JSON.stringify(readOnly.ledger()),before.ledger);return{counts:readOnly.counts}})
 }catch(e){setupError=e.stack||e.message}
 const out={applicationRoot:root,scope:'Only drill usage failure/retry and read-only console. Original handlers, isolated storage, real dev-only recovery; no reserved/model calls. Supports pre-solve rejection or durable post-solve recovery without prescribing pending filename/error code.',setupError,passed:results.filter(r=>r.passed).length,failed:results.filter(r=>!r.passed).length,results}
 fs.writeFileSync(output,JSON.stringify(out,null,2));console.log(`RESULT passed=${out.passed} failed=${out.failed} total=${results.length}`);if(setupError)console.log(setupError);if(setupError||out.failed)process.exitCode=1
})()
