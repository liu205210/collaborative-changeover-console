'use strict';
// Audit-only negative candidates. Does not execute any reserved evaluation cases.
// Usage: node acceptance-addendum.cjs <application-root>
const assert = require('node:assert/strict');
const path = require('node:path');
const app = path.resolve(process.argv[2] || path.join(__dirname, '../v4.2/application'));
const r = require(path.join(app, 'server/recovery.js'));
const s = require(path.join(app, 'server/scheduler.js'));
const orders = [{order:'O1',product:'P1',qty:100,bomLines:10,materialTypes:5,faces:['A']}];
let passed = 0, failed = 0;
function check(name, fn) {
  try { fn(); passed++; console.log(`PASS ${name}`); }
  catch (error) { failed++; console.log(`FAIL ${name}\n  ${error.message}`); }
}

check('quality release before required reinspection is rejected', () => {
  const session = r.createSession({orders});
  const at = session.actualEntries.find(e => e.key === 'fai_inspect').end;
  const event = {type:'fai_fail',target:'O1',at};
  const input = r.buildRecoveryInput(session,event,r.snapshotAt(session,at));
  const plan = r.scheduleRecovery(session,input,session.orderIds,s.templateRank(session.orderIds),at);
  assert.equal(r.validateRecovery(session,input,plan.entries,event).ok,true,'valid reference recovery must pass');
  assert.ok(input.units.find(e => e.key === 'quality_release').deps.includes('O1::recheck'));
  const bad = plan.entries.map(e => e.key === 'quality_release'
    ? {...e,start:at,end:at+e.duration,assigneeId:'QC-02',assigneeName:'test QC-02'} : {...e});
  assert.ok(bad.find(e => e.key === 'quality_release').end < bad.find(e => e.key === 'recheck').end);
  const result = r.validateRecovery(session,input,bad,event);
  console.log(JSON.stringify({case:'early_quality_release',trigger:at,release:bad.find(e=>e.key==='quality_release'),recheck:bad.find(e=>e.key==='recheck'),validation:result.ok,violations:result.violations}));
  assert.equal(result.ok,false,'independent validator accepted quality release before reinspection completed');
});

check('shortening every task by half a minute is rejected', () => {
  const session = r.createSession({orders});
  const event = {type:'person_absence',target:'MAT-02',at:0,duration:1};
  const input = r.buildRecoveryInput(session,event,r.snapshotAt(session,0));
  assert.equal(r.validateRecovery(session,input,session.actualEntries,event).ok,true,'valid reference schedule must pass');
  assert.ok(session.actualEntries.every(e=>e.duration>0.5),'fixture tasks must remain positive');
  const bad = session.actualEntries.map(e=>({...e,end:e.end-0.5,duration:e.duration-0.5}));
  const result = r.validateRecovery(session,input,bad,event);
  console.log(JSON.stringify({case:'half_minute_each',originalWork:session.actualEntries.reduce((a,e)=>a+e.duration,0),alteredWork:bad.reduce((a,e)=>a+e.duration,0),validation:result.ok,violations:result.violations}));
  assert.equal(result.ok,false,'independent validator accepted a total 5.5-minute reduction in required work');
});

console.log(`RESULT passed=${passed} failed=${failed} total=${passed+failed}`);
process.exitCode = failed ? 1 : 0;
