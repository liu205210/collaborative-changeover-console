#!/bin/bash
set -e
cd "$(dirname "$0")"

# 安装依赖（首次运行）
if [ ! -d node_modules ]; then
  npm install
fi

# 生产构建前端（单端口由 Express 托管，避免 dev 模式内存峰值）
if [ ! -d web/dist ]; then
  npm run build:web
fi

# 启动服务：API 与前端静态资源统一监听 3001 端口
node server/index.js
