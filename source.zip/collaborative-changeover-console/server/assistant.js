'use strict'

/**
 * 第六阶段 · 换产助手（可核验问答 + 可选大模型解释）
 * -------------------------------------------------------------------------
 * 四类问题：阻塞溯源 / AGV 恢复取舍 / 订单放行 / 学习模板启用。
 * 结论、引用、建议、限制均绑定同一事实快照；数值来自服务端事实字段。
 * 大模型只参与受限的意图识别、解释组织与建议；不改数据、不调用写接口。
 * 无凭据/超时/结构不合法/引用不存在/含未验证数字时回退规则模式。
 */

const collab = require('./collaboration')

const ASSISTANT_VERSION = 'v6-assistant-1.0'
const REQUIRED_DISCLAIMER = '结论为仿真结果，不代表工厂实测；OEE 待验证。'

function envConfig() {
  return {
    provider: (process.env.LLM_PROVIDER || 'none').toLowerCase(),
    baseUrl: process.env.LLM_BASE_URL || '',
    model: process.env.LLM_MODEL || '',
    apiKey: process.env.LLM_API_KEY || '',
    timeoutMs: Number(process.env.LLM_TIMEOUT_MS || 8000)
  }
}

function modelStatus() {
  const c = envConfig()
  const keyPresent = !!c.apiKey
  const providerUsable = ['openai', 'stub'].includes(c.provider)
  const configured = providerUsable && (c.provider === 'stub' || (keyPresent && !!c.baseUrl && !!c.model))
  return {
    configured,
    provider: c.provider,
    model: c.model || null,
    baseUrl: c.baseUrl ? c.baseUrl.replace(/\/\/[^@]*@/, '//***@') : null,
    keyPresent,
    mode: configured ? c.provider : 'rule',
    realCallVerified: false,
    note: configured
      ? (c.provider === 'stub' ? '当前为测试替身（stub），不代表真实模型调用。' : '已配置提供方；本轮是否发生真实调用以响应中的 modelInfo 为准。')
      : '未配置可用模型凭据，保持规则模式；真实模型调用未验证。',
    keyNeverExposed: true
  }
}

// ---------------------------------------------------------------------------
// 规则问答
// ---------------------------------------------------------------------------

function detectIntent(question, explicit) {
  if (explicit) return explicit
  const q = String(question || '')
  if (/AGV|配送|延迟|恢复方案|R0|R1|取舍/i.test(q)) return 'agv-recovery'
  if (/放行|release|恢复生产|能否|可不可以/i.test(q)) return 'release'
  if (/P8|学习模板|可供启用|学习参数|模板/i.test(q)) return 'learned-template'
  if (/阻塞|卡住|瓶颈|等待|挡住|影响换产/i.test(q)) return 'blocking'
  return 'unknown'
}

function findOrderInText(question, orders) {
  const q = String(question || '')
  const known = orders.map((o) => o.order)
  // 显式给出的订单号：若不在快照中，返回 requested 而不回落到第一单
  const tokens = q.match(/\d{6,}/g) || []
  for (const t of tokens) if (known.includes(t)) return { order: t, explicit: true, requested: t }
  if (tokens.length) return { order: null, explicit: true, requested: tokens[0] }
  return { order: known[0] || null, explicit: false, requested: null }
}

function taskBlockedReasons(snapshot, task) {
  const atVal = snapshot.observationTime == null ? 0 : snapshot.observationTime
  const doneIds = new Set(snapshot.tasks.filter((t) => t.end <= atVal + 1e-9).map((t) => t.id))
  const reasons = []
  const refs = []
  const q = snapshot.quality.find((x) => x.order === task.order)
  if (task.kind === 'actual-fragment' && task.end > atVal + 1e-9) {
    reasons.push('在制任务因异常暂停，已保留事件前已完成片段，剩余部分待重排续作')
  }
  if (task.result === 'fail' && task.end <= atVal + 1e-9 && !(q && q.recheckComplete)) {
    reasons.push('首件检验不合格，触发返工与复检，复检合格前禁止放行')
  }
  const missing = (task.deps || []).filter((d) => !doneIds.has(d))
  if (missing.length) {
    reasons.push(`前序任务未完成：${missing.join('、')}`)
    for (const m of missing) {
      const t = snapshot.tasks.find((x) => x.id === m)
      if (t) refs.push(collab.taskEvidence(t, snapshot.timeBasis))
    }
  }
  if (task.delayedByResource && task.start > atVal + 1e-9) {
    reasons.push(`资源等待 ${collab.r2(task.resourceWait)} 分钟（占用 ${task.exclusive || task.skill}）`)
    refs.push(collab.metricEvidence(`metric:task:${task.id}:wait`, `${task.name} 资源等待`, collab.r2(task.resourceWait), '分钟', snapshot.timeBasis))
  }
  if (q && q.faiStatus === '不合格' && !q.recheckComplete && (task.key === 'quality_release' || task.key === 'resume' || task.key === 'rework' || task.key === 'recheck')) {
    reasons.push('质量门禁：首件不合格，复检合格前禁止放行/恢复生产')
  }
  return { reasons, refs }
}

function answerBlocking(snapshot) {
  const atVal = snapshot.observationTime == null ? 0 : snapshot.observationTime
  // 与六角色控制台共用当前状态：历史暂停片段、已复检的失败不再充当活动阻塞。
  const currentTasks = collab.buildRoleStates(snapshot).flatMap((role) => role.tasks)
  const notDone = currentTasks.filter((t) => t.status !== '已完成')
  const abnormal = notDone.find((t) => t.status === '异常')
  const active = notDone.find((t) => t.status === '进行中')
  const delayed = notDone.filter((t) => t.status === '等待' && t.delayedByResource).sort((a, b) => a.start - b.start)[0]
  const waiting = notDone.filter((t) => t.status === '等待' || t.status === '待开始').sort((a, b) => a.start - b.start)
  const target = abnormal || active || delayed || waiting[0] || null
  if (!target) {
    return {
      conclusion: '当前快照没有未完成的关键任务，未发现阻塞换产的任务。',
      claims: [],
      evidenceRefs: [],
      nextSteps: ['如处于计划模式，请切换到当前仿真执行或历史回放以查看实际阻塞。'],
      limitations: [snapshot.timeBasis, REQUIRED_DISCLAIMER]
    }
  }
  const { reasons, refs } = taskBlockedReasons(snapshot, target)
  const eventRefs = []
  if (snapshot.knownEvents.length && (target.kind === 'actual-fragment' || reasons.length)) {
    for (const rec of snapshot.knownEvents) eventRefs.push(collab.eventEvidence(rec, snapshot.timeBasis))
  }
  const claimText = reasons.length
    ? `${target.name}（订单 ${target.order}）是当前阻塞点，原因：${reasons.join('；')}`
    : `${target.name}（订单 ${target.order}）为下一待执行关键任务，当前无显式资源/门禁阻塞。`
  const nextRole = collab.ROLE_OF_KEY[target.key] || 'scheduler'
  return {
    conclusion: claimText,
    claims: [{ text: claimText, evidenceRefs: [collab.taskEvidence(target, snapshot.timeBasis), ...eventRefs, ...refs].map((r) => r.ref) }],
    evidenceRefs: [collab.taskEvidence(target, snapshot.timeBasis), ...eventRefs, ...refs],
    nextSteps: [`由${(collab.ROLES.find((r) => r.id === nextRole) || {}).name || '调度智能体'}按快照继续处理；如需变更请通过既有异常注入/排程入口。`],
    limitations: [snapshot.timeBasis, '阻塞判定基于该快照的任务/资源/门禁事实。', REQUIRED_DISCLAIMER]
  }
}

function answerAgv(snapshot) {
  const rec = snapshot.knownEvents.find((e) => e.event.type === 'agv_delay')
  if (!rec) {
    return {
      conclusion: '当前快照中没有已发生的 AGV 配送延迟事件，无法核验恢复取舍。',
      claims: [],
      evidenceRefs: [],
      nextSteps: ['请在异常演练中注入一次 AGV 延迟后重新提问。'],
      limitations: [snapshot.timeBasis, '未发生的事件不进入当前已知事实。', REQUIRED_DISCLAIMER]
    }
  }
  const d = collab.r2(rec.R0.metrics.makespan - rec.R1.metrics.makespan)
  const tie = Math.abs(d) <= 0.05
  const text = `采用 ${rec.chosen}：R0（固定顺序）恢复总历时 ${rec.R0.metrics.makespan} 分钟，R1（动态）${rec.R1.metrics.makespan} 分钟，差值 ${d} 分钟${tie ? '（持平）' : d > 0 ? '（R1 更短）' : '（R1 更长）'}；R0 验证${rec.R0.validation.ok ? '通过' : '未通过'}，R1 验证${rec.R1.validation.ok ? '通过' : '未通过'}。${rec.chosenFromR0 ? 'R1 未通过或未改善，故回退 R0。' : ''}`
  return {
    conclusion: text,
    claims: [{ text, evidenceRefs: [`event:${rec.id}`, `metric:${rec.id}:R0`, `metric:${rec.id}:R1`, `validation:${rec.id}:R1`] }],
    evidenceRefs: [
      collab.eventEvidence(rec, snapshot.timeBasis),
      collab.metricEvidence(`metric:${rec.id}:R0`, 'R0 恢复总历时', rec.R0.metrics.makespan, '分钟', snapshot.timeBasis),
      collab.metricEvidence(`metric:${rec.id}:R1`, 'R1 恢复总历时', rec.R1.metrics.makespan, '分钟', snapshot.timeBasis),
      collab.metricEvidence(`metric:${rec.id}:remaining`, '触发后剩余时间（R1）', rec.R1.metrics.remainingAfterTrigger, '分钟', snapshot.timeBasis),
      { ref: `validation:${rec.id}:R1`, type: 'validation', label: 'R1 独立验证', value: rec.R1.validation.ok ? '通过' : '未通过', timeBasis: snapshot.timeBasis, checks: rec.R1.validation.checks.map((c) => `${c.name}:${c.status}`) }
    ],
    nextSteps: [rec.chosen === 'R1' ? '保持当前恢复方案；如需对比可切换查看 R0。' : '当前采用 R0；可查看 R1 未采用原因。'],
    limitations: [snapshot.timeBasis, '恢复方案为仿真重排结果，按算法实际计算如实展示，持平/变差同样保留。', REQUIRED_DISCLAIMER]
  }
}

function answerRelease(snapshot, question) {
  const found = findOrderInText(question, snapshot.orders)
  if (!found.order) {
    const list = snapshot.orders.map((o) => o.order).join('、')
    if (found.explicit) {
      return { conclusion: `未找到订单 ${found.requested}，该订单不属于当前快照。当前快照订单：${list}。`, claims: [], evidenceRefs: [], nextSteps: [`请从当前快照订单中选择：${list}。`], limitations: ['显式指定的订单不在快照中，不作默认替换。', REQUIRED_DISCLAIMER] }
    }
    return { conclusion: `未指定订单。当前快照包含订单：${list}，请选择其一后再判断放行。`, claims: [], evidenceRefs: [], nextSteps: [`请指定订单：${list}。`], limitations: ['未指定对象时不猜测。', REQUIRED_DISCLAIMER] }
  }
  const order = found.order
  const q = snapshot.quality.find((x) => x.order === order)
  if (!q) {
    return { conclusion: `未找到订单 ${order} 的质量链事实，无法判断放行。`, claims: [], evidenceRefs: [], nextSteps: [`当前快照订单：${snapshot.orders.map((o) => o.order).join('、')}。`], limitations: [snapshot.timeBasis, REQUIRED_DISCLAIMER] }
  }
  if (!q.known) {
    return { conclusion: `订单 ${order} 的首件检验尚未进入当前快照（可能尚未开始或处于计划阶段），无法判断放行。`, claims: [], evidenceRefs: [{ ref: `order:${order}`, type: 'order', label: `订单 ${order}`, timeBasis: snapshot.timeBasis }], nextSteps: ['推进到该订单首件检验开始时刻后再查询。'], limitations: ['未采集到检验事实，不猜测数值。', REQUIRED_DISCLAIMER] }
  }
  // 与 qualityChain 的整项任务选择一致；历史片段不能代表检验/放行完成时刻。
  const whole = (key) => snapshot.tasks.find((t) => t.order === order && t.key === key && t.kind !== 'actual-fragment' && !String(t.id || '').includes('::seg@') && !(t.originId && t.originId !== t.id))
  const insp = whole('fai_inspect')
  const rel = whole('quality_release')
  const rs = whole('resume')
  const recheck = whole('recheck')
  const refs = [insp, recheck, rel, rs].filter(Boolean).map((t) => collab.taskEvidence(t, snapshot.timeBasis))
  let conclusion
  let next = '质量智能体'
  if (!q.faiComplete) { conclusion = `订单 ${order} 尚不能放行：首件检验未完成（当前状态 ${q.faiStatus}）。`; next = '质量智能体' }
  else if (q.faiStatus === '不合格' && !q.recheckComplete) { conclusion = `订单 ${order} 尚不能放行：首件不合格，返工/复检未完成，复检合格前禁止放行与恢复生产。`; next = '质量智能体（复检）与人员调度智能体（返工）' }
  else if (!q.releaseComplete) { conclusion = `订单 ${order} ${q.faiStatus === '不合格' ? '首件曾不合格，返工复检已完成' : '首件合格'}，尚待质量放行复核（放行未完成）。`; next = '质量智能体' }
  else if (!q.resumeComplete) { conclusion = `订单 ${order} 已质量放行，尚待恢复生产并解除产线锁定。`; next = '调度智能体/人员调度智能体' }
  else { conclusion = `订单 ${order} 已完成质量放行与恢复生产，产线锁定已解除。`; next = '无需处理' }
  return {
    conclusion,
    claims: [{ text: conclusion, evidenceRefs: refs.map((r) => r.ref) }],
    evidenceRefs: refs,
    nextSteps: [`下一步处理角色：${next}。`],
    limitations: [snapshot.timeBasis, '检验完成、质量放行、恢复生产、产线锁定解除为四个不同时刻。', REQUIRED_DISCLAIMER]
  }
}

function answerLearned(snapshot, lab) {
  if (!lab || !lab.selection) {
    return { conclusion: '当前没有锁定的学习模板记录，无法解释启用理由。', claims: [], evidenceRefs: [], nextSteps: ['请先在自优化实验室完成参数实验与验证。'], limitations: [REQUIRED_DISCLAIMER] }
  }
  const v = lab.validation
  const sel = lab.selection
  const im = v ? v.improvement : null
  const refs = [
    { ref: `template:${sel.templateId}`, type: 'template', label: `学习模板 ${sel.templateId}`, value: sel.name, timeBasis: '离线学习（dev/validation）' },
    { ref: 'metric:learned:devMakespan', type: 'metric', label: '开发集总历时之和', value: sel.devSumMakespan, unit: '分钟', timeBasis: '离线学习（dev）' }
  ]
  if (v) {
    refs.push({ ref: 'metric:learned:sumBaseline', type: 'metric', label: '验证集总历时合计（原 C）', value: v.makespan.sumBaseline, unit: '分钟', timeBasis: '验证（validation）' })
    refs.push({ ref: 'metric:learned:sumLearned', type: 'metric', label: '验证集总历时合计（C-learned）', value: v.makespan.sumLearned, unit: '分钟', timeBasis: '验证（validation）' })
    refs.push({ ref: 'metric:learned:sumOnlineBaseline', type: 'metric', label: '验证集在线停线合计（原 C）', value: v.onlineStop.sumBaseline, unit: '分钟', timeBasis: '验证（validation）' })
    refs.push({ ref: 'metric:learned:sumOnlineLearned', type: 'metric', label: '验证集在线停线合计（C-learned）', value: v.onlineStop.sumLearned, unit: '分钟', timeBasis: '验证（validation）' })
    refs.push({ ref: `validation:${v.runId}`, type: 'validation', label: '验证启用判定', value: v.eligibleForActivation ? '可供启用' : '未通过', timeBasis: '验证（validation）' })
  }
  let text
  if (v) {
    const improvedMakespan = v.makespan.sumLearned < v.makespan.sumBaseline - 1e-6
    const improvedOnline = v.onlineStop.sumLearned < v.onlineStop.sumBaseline - 1e-6
    text = `模板 ${sel.templateId}（${sel.name}）${v.eligibleForActivation ? '可供启用' : '未通过启用条件'}：验证集改善 ${im.improved}/持平 ${im.tie}/变差 ${im.worse}；总历时 ${v.makespan.sumBaseline}→${v.makespan.sumLearned} 分钟${improvedMakespan ? '（有改善）' : '（无改善/持平）'}，在线停线合计 ${v.onlineStop.sumBaseline}→${v.onlineStop.sumLearned} 分钟${improvedOnline ? '（有下降）' : '（无下降/持平）'}。${v.eligibleForActivation ? '' : '原因：' + v.reasons.join('；')}`
  } else {
    text = `模板 ${sel.templateId}（${sel.name}）已锁定，但尚无验证记录，不能据此判断可供启用。`
  }
  return {
    conclusion: text,
    claims: [{ text, evidenceRefs: refs.map((r) => r.ref) }],
    evidenceRefs: refs,
    nextSteps: ['如需应用，可在自优化实验室启用候选模板；也可一键回滚到原策略 C。'],
    limitations: ['学习参数只影响离线准备任务优先级，不影响工时/资源/门禁。', '总历时与在线停线为不同口径，分别展示。', REQUIRED_DISCLAIMER]
  }
}

function answerQuestion({ question, intent, snapshot, lab }) {
  const it = detectIntent(question, intent)
  let body
  if (it === 'blocking') body = answerBlocking(snapshot)
  else if (it === 'agv-recovery') body = answerAgv(snapshot)
  else if (it === 'release') body = answerRelease(snapshot, question)
  else if (it === 'learned-template') body = answerLearned(snapshot, lab)
  else body = {
    conclusion: '该问题不在当前支持的范围内（阻塞溯源 / AGV 恢复取舍 / 订单放行 / 学习模板启用）。',
    claims: [],
    evidenceRefs: [],
    nextSteps: ['请使用快捷问题，或改写为上述四类之一。'],
    limitations: ['未知问题不猜测数值。', REQUIRED_DISCLAIMER]
  }
  const answerId = `ans-${snapshot.snapshotId}-${it}-${hashShort(question || it)}`
  const writeIntent = detectWriteIntent(question)
  const conclusion = writeIntent
    ? `${body.conclusion}\n（说明：换产助手只读，不执行启用/回滚/重置/放行等写操作，请通过对应页面按钮操作。）`
    : body.conclusion
  const limitations = writeIntent ? [...(body.limitations || []), '助手不拥有写权限，未执行任何状态变更。'] : body.limitations || []
  const claims = (body.claims || []).map((c, i) => ({ id: `${answerId}#c${i + 1}`, text: c.text, evidenceRefs: c.evidenceRefs || [] }))
  return {
    answerId,
    assistantVersion: ASSISTANT_VERSION,
    snapshotId: snapshot.snapshotId,
    collaborationVersion: snapshot.collaborationVersion,
    intent: it,
    question: question || null,
    mode: 'rule',
    conclusion,
    claims,
    evidenceRefs: body.evidenceRefs || [],
    nextSteps: body.nextSteps || [],
    limitations,
    generatedAt: new Date().toISOString(),
    modelInfo: null,
    writeActionsAllowed: false
  }
}

function detectWriteIntent(question) {
  const q = String(question || '')
  const hasWriteWord = /启用|回滚|重置|删除|写入|修改|注入|执行排程/.test(q)
  const isQuestion = /为什么|为何|能否|可不可以|是否|能不能|如何/.test(q)
  return hasWriteWord && !isQuestion
}

function hashShort(str) {
  let h = 0
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0
  return Math.abs(h).toString(36).slice(0, 8)
}

// ---------------------------------------------------------------------------
// 受限大模型解释
// ---------------------------------------------------------------------------

const NUM_RE = /(?<![A-Za-z0-9_-])-?\d+(?:\.\d+)?(?![A-Za-z0-9_:-])/g

function factNumbers(rule) {
  const nums = new Set()
  const add = (v) => { if (v != null && Number.isFinite(Number(v))) nums.add(String(Number(v))) }
  // 收集证据与规则结论/claim 中的数值，以及引用/标签/订单号里的数字（避免把订单号/设备编号误判为编造数字）
  const scan = (text) => { const re = new RegExp(NUM_RE.source, 'g'); let m; while ((m = re.exec(String(text || ''))) !== null) nums.add(String(Number(m[0]))) }
  for (const e of rule.evidenceRefs || []) {
    add(e.value)
    scan(e.ref)
    scan(e.label)
    scan(e.order)
    scan(e.id)
  }
  scan(rule.conclusion)
  for (const c of rule.claims || []) scan(c.text)
  add(rule.evidenceRefs ? rule.evidenceRefs.length : 0)
  return nums
}

function extractNumbers(text) {
  const out = []
  const re = new RegExp(NUM_RE.source, 'g')
  let m
  while ((m = re.exec(String(text || ''))) !== null) out.push(String(Number(m[0])))
  return out
}

// 模型只选择/排序服务端 claim，引用绑定所选 claim；不发布模型生成的自由事实。
// 兼容 explanation 字段时，只接受空串或逐字回显所选服务端 claim 文本。
function validateModelOutput(parsed, rule) {
  if (!parsed || typeof parsed !== 'object') return { ok: false, reason: 'MODEL_STRUCTURE_INVALID' }
  const claims = rule.claims || []
  const claimIds = parsed.claimIds
  if (!Array.isArray(claimIds) || !claimIds.length) return { ok: false, reason: 'MODEL_CLAIM_MISSING' }
  const validIds = new Set(claims.map((c) => c.id))
  const badClaim = claimIds.filter((id) => !validIds.has(id))
  if (badClaim.length) return { ok: false, reason: `MODEL_CLAIM_NOT_FOUND:${badClaim.join(',')}` }
  const selectedIds = [...new Set(claimIds)]
  const selectedClaims = selectedIds.map((id) => claims.find((c) => c.id === id))
  const refs = parsed.evidenceRefs || []
  if (!Array.isArray(refs)) return { ok: false, reason: 'MODEL_REFS_INVALID' }
  const allowedRefs = new Set((rule.evidenceRefs || []).map((r) => r.ref))
  const badRef = refs.filter((r) => !allowedRefs.has(r))
  if (badRef.length) return { ok: false, reason: `MODEL_REF_NOT_FOUND:${badRef.join(',')}` }
  const boundRefs = new Set(selectedClaims.flatMap((c) => c.evidenceRefs || []))
  const unboundRefs = refs.filter((r) => !boundRefs.has(r))
  if (unboundRefs.length) return { ok: false, reason: `MODEL_REF_NOT_BOUND_TO_CLAIM:${unboundRefs.join(',')}` }
  if (parsed.explanation != null && typeof parsed.explanation !== 'string') return { ok: false, reason: 'MODEL_EXPLANATION_INVALID' }
  const explanation = (parsed.explanation || '').trim()
  const serverTexts = new Set(selectedClaims.map((c) => c.text))
  serverTexts.add(selectedClaims.map((c) => c.text).join('\n'))
  if (explanation && !serverTexts.has(explanation)) return { ok: false, reason: 'MODEL_FREE_EXPLANATION_NOT_VERIFIABLE' }
  return { ok: true, claimIds: selectedIds, selectedClaims, evidenceRefs: [...boundRefs] }
}

function buildModelPrompt(rule, snapshot) {
  const facts = (rule.evidenceRefs || []).map((e) => ({ ref: e.ref, label: e.label, value: e.value, unit: e.unit || null, timeBasis: e.timeBasis }))
  const claims = (rule.claims || []).map((c) => ({ id: c.id, text: c.text, evidenceRefs: c.evidenceRefs }))
  const system = '你是换产指挥台的证据选择助手。只能选择并排序给定 claims 的 id，引用必须属于所选 claim 的 evidenceRefs。所有展示结论由服务端原文生成，不接受自由解释，不得调用任何写操作。只输出 JSON {"claimIds":string[],"evidenceRefs":string[]}。'
  const user = JSON.stringify({ question: rule.question, intent: rule.intent, ruleConclusion: rule.conclusion, claims, facts, snapshotId: rule.snapshotId, timeBasis: snapshot.timeBasis })
  return { system, user }
}

async function callOpenAI({ system, user, config }) {
  const ctrl = new AbortController()
  const timer = setTimeout(() => ctrl.abort(), config.timeoutMs)
  try {
    const res = await fetch(`${config.baseUrl.replace(/\/$/, '')}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${config.apiKey}` },
      body: JSON.stringify({ model: config.model, temperature: 0, messages: [{ role: 'system', content: system }, { role: 'user', content: user }], response_format: { type: 'json_object' } }),
      signal: ctrl.signal
    })
    if (!res.ok) throw new Error(`MODEL_HTTP_${res.status}`)
    const data = await res.json()
    const content = data.choices && data.choices[0] && data.choices[0].message ? data.choices[0].message.content : ''
    return JSON.parse(content)
  } finally {
    clearTimeout(timer)
  }
}

function stubModel(rule) {
  // 测试替身：只选择既有 claims 与引用，不引入新数字
  return { claimIds: (rule.claims || []).map((c) => c.id), explanation: '', evidenceRefs: [...new Set((rule.claims || []).flatMap((c) => c.evidenceRefs || []))] }
}

async function explain({ question, intent, snapshot, lab, allowModel = true }) {
  const rule = answerQuestion({ question, intent, snapshot, lab })

  const status = modelStatus()
  if (!allowModel || !status.configured) {
    return { ...rule, mode: 'rule', modelInfo: { ...status, used: false, selectedMode: 'rule' } }
  }
  const config = envConfig()
  const reqAt = new Date().toISOString()
  const t0 = Date.now()

  try {
    let parsed
    if (config.provider === 'stub') {
      parsed = stubModel(rule)
    } else {
      const { system, user } = buildModelPrompt(rule, snapshot)
      parsed = await callOpenAI({ system, user, config })
    }
    const check = validateModelOutput(parsed, rule)
    if (!check.ok) {
      return { ...rule, mode: 'fallback', modelInfo: { ...status, used: true, selectedMode: 'fallback', fallbackReason: check.reason, requestAt: reqAt, latencyMs: Date.now() - t0, refCheck: 'fail' } }
    }
    const mode = config.provider === 'stub' ? 'stub' : 'model'
    // 业务结论始终为服务端规则原文；模型只影响 claim 展示顺序，不能追加事实。
    const conclusion = rule.conclusion
    return {
      ...rule,
      mode,
      conclusion,
      claims: check.selectedClaims.length ? check.selectedClaims : rule.claims,
      modelInfo: { ...status, used: true, selectedMode: mode, provider: config.provider, model: config.model || null, requestAt: reqAt, latencyMs: Date.now() - t0, refCheck: 'pass', realCallVerified: config.provider === 'openai', selectedClaimIds: check.claimIds }
    }
  } catch (err) {
    return { ...rule, mode: 'fallback', modelInfo: { ...status, used: true, selectedMode: 'fallback', fallbackReason: err.message, requestAt: reqAt, latencyMs: Date.now() - t0, refCheck: 'skipped' } }
  }
}

module.exports = { ASSISTANT_VERSION, modelStatus, answerQuestion, explain, detectIntent, validateModelOutput, answerBlocking, answerAgv, answerRelease, answerLearned }
