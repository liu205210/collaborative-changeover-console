'use strict'

/**
 * 六类智能体协同编排（规则决策模式，尚未接入大模型）
 * 所有输入状态、决策与执行结果均来自实际排程计算结果，不是静态介绍卡片。
 */

const AGENT_DEFS = [
  { id: 'scheduler', code: 'SCH', name: '调度智能体', role: '全局编排、产线状态锁定与冲突消解', keys: null },
  { id: 'equipment', code: 'EQP', name: '设备智能体', role: '参数方案离线准备、在线应用与校准', keys: ['param_prepare', 'param_apply'] },
  { id: 'material', code: 'MAT', name: '物料智能体', role: '物料需求、库存与配送调度', keys: ['material_pick', 'material_deliver'] },
  { id: 'tooling', code: 'TLG', name: '工装智能体', role: '离线工装准备与在线工装切换', keys: ['tooling_prep', 'tooling_switch'] },
  { id: 'quality', code: 'QC', name: '质量智能体', role: '首件检验触发与质量放行门禁', keys: ['fai_inspect', 'quality_release'] },
  { id: 'employee', code: 'EMP', name: '人员调度智能体', role: '作业状态跟踪与技能派工', keys: ['fai_produce', 'resume'] }
]

function r2(x) {
  return Math.round(x * 100) / 100
}

function buildAgentView({ orders, schedule, personnel, exclusive, mode, faiResults = {} }) {
  const entries = schedule.entries
  const byKey = (keys) => (keys ? entries.filter((e) => keys.includes(e.key)) : entries)

  const agents = AGENT_DEFS.map((def) => {
    const own = byKey(def.keys)
    const start = own.length ? Math.min(...own.map((e) => e.start)) : 0
    const end = own.length ? Math.max(...own.map((e) => e.end)) : 0
    const inputs = []
    const decisions = []
    const executions = own
      .slice()
      .sort((a, b) => a.start - b.start)
      .map((e) => ({
        task: e.name,
        order: e.order,
        window: `${e.start} → ${e.end} 分钟`,
        assignee: e.assigneeName,
        resource: e.exclusive || '常规',
        result: e.delayedByResource ? `资源等待 ${e.resourceWait} 分钟` : '按计划执行',
        resourceWait: e.resourceWait,
        mode: e.mode
      }))

    if (def.id === 'scheduler') {
      inputs.push({ label: '排程策略', value: schedule.modeName })
      inputs.push({ label: '订单数', value: `${orders.length} 个` })
      inputs.push({ label: '任务总数', value: `${schedule.metrics.taskCount} 个` })
      inputs.push({ label: '产线状态约束', value: '在线换产窗口互斥 + 在位工装/参数锁定至质量放行' })
      decisions.push(`采用「${schedule.modeName}」，多订单总历时 ${schedule.metrics.makespan} 分钟`)
      decisions.push(`各订单在线停线窗口合计 ${schedule.metrics.onlineStopTotal} 分钟（单产线串行，窗口互不交叠）`)
      decisions.push(`离线准备总工时 ${schedule.metrics.offlinePrepTotal} 分钟，可跨订单提前并行`)
      decisions.push(`识别 ${schedule.metrics.conflictEvents} 处资源等待事件，累计等待 ${schedule.metrics.resourceWaitTotal} 分钟`)
    } else if (def.id === 'material') {
      const types = orders.reduce((s, o) => s + o.materialTypes, 0)
      const lines = orders.reduce((s, o) => s + o.bomLines, 0)
      inputs.push({ label: '目标订单', value: orders.map((o) => o.order).join('、') })
      inputs.push({ label: '物料种类', value: `${types} 种` })
      inputs.push({ label: 'BOM 明细行', value: `${lines} 行` })
      inputs.push({ label: '配送资源', value: 'AGV-01（独占，离线）' })
      decisions.push('物料拣配与线边配送属可离线提前任务，后续订单可提前备料')
      decisions.push('物料编码按字符串处理保留前导零，按订单去重展开 BOM')
      decisions.push(`物料链路占用窗口 ${r2(start)} → ${r2(end)} 分钟`)
    } else if (def.id === 'tooling') {
      inputs.push({ label: '目标产品', value: orders.map((o) => `${o.product}(${o.faces.join('+')})`).join('、') })
      inputs.push({ label: '工装资源', value: '离线预装 + 产线在位切换' })
      decisions.push('依据赛题说明：物料未到线边时工装切换无意义，在线切换前校验离线工装准备与线边配送均完成')
      decisions.push('在线工装切换开始即锁定产线在位配置，直至本订单质量放行、恢复生产')
      decisions.push(`工装链路占用窗口 ${r2(start)} → ${r2(end)} 分钟`)
    } else if (def.id === 'equipment') {
      inputs.push({ label: '离线资源', value: 'CAL-01 离线参数校准台' })
      inputs.push({ label: '在线资源', value: 'LINE-01 产线参数应用与校准' })
      decisions.push('参数方案离线准备（校准台）与在线参数应用、校准（产线）严格区分')
      decisions.push('在线参数应用仅在本订单工装切换完成后执行；方案准备可提前并行')
      decisions.push(`设备链路占用窗口 ${r2(start)} → ${r2(end)} 分钟`)
    } else if (def.id === 'quality') {
      inputs.push({ label: '检验任务', value: '首件检验 + 质量放行' })
      inputs.push({ label: '质量门禁', value: '首件合格前禁止放行与恢复生产' })
      decisions.push(`为 ${orders.length} 个订单布防质量门禁：首件检验合格 → 质量放行 → 恢复生产`)
      decisions.push('首件检验期间产线保持锁定，不允许其他订单覆盖在位配置')
      decisions.push(`首件检验结果：${orders.map((o) => `${o.order}=${faiResults[o.order] === 'fail' ? '不合格' : '合格'}`).join('，')}`)
    } else if (def.id === 'employee') {
      inputs.push({ label: '可用人员', value: `${personnel.length} 人` })
      inputs.push({ label: '技能矩阵', value: '物料员 / 设备工程师 / 工装工程师 / 质检员 / 操作工' })
      const active = schedule.metrics.utilization.filter((u) => u.busy > 0)
      decisions.push(`为 ${own.length} 个产线作业任务派工，全部通过技能匹配校验`)
      decisions.push(`实际投入 ${active.length} 人，最高人员利用率 ${Math.max(0, ...schedule.metrics.utilization.map((u) => u.utilizationPct))}%`)
      decisions.push('相同人员在同一时刻不得承担冲突任务，由排程引擎保证时间互斥')
    }

    return {
      id: def.id,
      code: def.code,
      name: def.name,
      role: def.role,
      mode: '规则决策模式',
      status: executions.length ? '已完成' : '就绪',
      window: own.length ? `${r2(start)} → ${r2(end)} 分钟` : '—',
      inputs,
      decisions,
      executions,
      taskCount: own.length
    }
  })

  const log = buildCollaborationLog({ orders, schedule, faiResults })
  return { agents, log, mode: schedule.mode, modeName: schedule.modeName, ruleBased: true }
}

function buildCollaborationLog({ orders, schedule, faiResults }) {
  const entries = schedule.entries
  const events = []
  const agentOfTask = (key) => {
    if (key === 'param_prepare' || key === 'param_apply') return '设备智能体'
    if (key === 'material_pick' || key === 'material_deliver') return '物料智能体'
    if (key === 'tooling_prep' || key === 'tooling_switch') return '工装智能体'
    if (key === 'fai_inspect' || key === 'quality_release') return '质量智能体'
    if (key === 'fai_produce' || key === 'resume') return '人员调度智能体'
    return '调度智能体'
  }
  for (const o of orders) {
    events.push({ time: 0, from: '调度智能体', to: '物料智能体', type: '指令', message: `下达换产指令：订单 ${o.order}（${o.product}，数量 ${o.qty}），请求离线准备` })
  }
  const sorted = entries.slice().sort((a, b) => a.start - b.start || a.end - b.end)
  for (const e of sorted) {
    if (e.stage === 'prep') continue
    const agent = agentOfTask(e.key)
    const tag = e.stage === 'post' ? '（产线锁定中）' : ''
    events.push({
      time: r2(e.start),
      from: agent,
      to: '调度智能体',
      type: e.delayedByResource ? '偏差' : '执行反馈',
      message: `${e.name}${tag}（订单 ${e.order}）${e.delayedByResource ? `受资源约束等待 ${e.resourceWait} 分钟后` : ''}开始执行，执行人 ${e.assigneeName}，预计 ${r2(e.start)}→${r2(e.end)} 分钟`
    })
  }
  for (const o of orders) {
    const sw = entries.find((e) => e.order === o.order && e.key === 'tooling_switch')
    const fai = entries.find((e) => e.order === o.order && e.key === 'fai_inspect')
    if (sw) {
      events.push({ time: r2(sw.start), from: '调度智能体', to: '全部智能体', type: '指令', message: `订单 ${o.order} 进入在线换产，锁定产线在位工装与参数窗口` })
    }
    if (fai) {
      const pass = faiResults[o.order] !== 'fail'
      events.push({
        time: r2(fai.end),
        from: '质量智能体',
        to: '调度智能体',
        type: pass ? '质量放行' : '质量拦截',
        message: `订单 ${o.order} 首件检验${pass ? '合格，质量门禁放行，允许恢复生产并解除产线锁定' : '不合格，已拦截放行与恢复生产并触发返工决策'}`
      })
    }
  }
  events.push({
    time: schedule.metrics.makespan,
    from: '调度智能体',
    to: '全部智能体',
    type: '汇总',
    message: `本轮「${schedule.modeName}」完成，多订单总历时 ${schedule.metrics.makespan} 分钟，在线停线窗口合计 ${schedule.metrics.onlineStopTotal} 分钟`
  })
  return events.sort((a, b) => a.time - b.time)
}

module.exports = { buildAgentView, AGENT_DEFS }
