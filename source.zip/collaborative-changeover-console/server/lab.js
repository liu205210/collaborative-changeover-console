'use strict'

/**
 * 第五阶段 · 策略自优化实验室（离线参数自优化，规则搜索，不接大模型）
 * -------------------------------------------------------------------------
 * 闭环：开发集历史分析 → 可解释参数候选（≤9 组）→ 锁定参数 → 验证集一次对照 → 保存候选模板 / 回滚。
 *
 * 硬性边界：
 *  - 只学习静态方案 C 的“离线准备任务优先级参数”；A/B/C 与异常 R0/R1 基线不动。
 *  - 学习/选择只读 dev；验证只读 validation；绝不求解或读取 reserved，不通过传参/空集合/CLI 绕行。
 *  - 物理工时、依赖、产线锁定、技能班次、设备库存、质量门禁、数据生成规则、验证器标准均不变。
 *  - 所有真实求解（候选搜索、验证、失败、回退）经统一记账；纯筛选不记账。
 */

const crypto = require('crypto')
const sim = require('./simulation')
const sched = require('./scheduler')
const evaluation = require('./evaluation')
const prep = require('./prepPriority')
const store = require('./store')

const PROTOCOL_FILE = 'lab-protocol.json'
const HISTORY_FILE = 'lab-dev-history.json'
const EXPERIMENT_FILE = 'lab-experiment.json'
const SELECTION_FILE = 'lab-selection.json'
const VALIDATION_FILE = 'lab-validation.json'
const STATE_FILE = 'lab-state.json'
const PENDING_FILE = 'lab-pending.json'
const ARCHIVE_FILE = 'lab-archive.json'

const LEARN_SEED = 20261021 // 学习（dev）固定种子
const VALIDATION_SEED = 20261021 // 验证固定种子；原 C 与 C-learned 使用同一案例/合同/资源/初态/种子
const OBJECTIVE = '开发集上：原 C 可行的案例候选必须全部可行；再按开发案例总历时之和最小排序；并列按在线停线合计、再按参数序号。'
const ACTIVATION_RULE = '保守默认：原 C 可行的验证案例不得新增不可行；验证集总历时之和与在线停线合计均不劣于原 C，才标记“可供启用”；否则保留原策略并展示原因。'
const BUDGET_RULE = '原 C 与 C-learned 使用相同的候选排程尝试上限（订单顺序数 × 42），实际尝试次数分别计数；历史参数搜索成本单独列出。'

const TIGHT_PERSONNEL_IDS = ['MAT-01', 'EQP-01', 'TLG-01', 'QC-01', 'OPR-01']

function tightPersonnel() {
  return sim.DEFAULT_PERSONNEL.filter((p) => TIGHT_PERSONNEL_IDS.includes(p.id))
}

function nowISO() {
  return new Date().toISOString()
}

function readJSON(file, fallback = null) {
  return store.readJSON(file, fallback)
}
function writeJSON(file, value) {
  return store.writeJSON(file, value)
}

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex')
}

// 真实合同快照：覆盖订单/BOM、任务实际工时与依赖、人员技能/班次、设备库存/容量。
// 仅订单编号相同但内容变化时，摘要必须改变。
function contractSnapshot(orders, cases) {
  const byId = new Map(orders.map((o) => [o.order, o]))
  return cases.map((c) => {
    const sel = c.orders.map((id) => byId.get(id)).filter(Boolean)
    const personnel = c.resources === 'tight' ? tightPersonnel() : sim.DEFAULT_PERSONNEL
    const built = sim.buildTaskSet(sel, { personnel })
    return {
      caseId: c.id,
      caseSet: c.set,
      orders: sel.map((o) => ({ order: o.order, product: o.product, qty: o.qty, bomLines: o.bomLines, materialTypes: o.materialTypes, faces: o.faces })),
      tasks: built.tasks.map((t) => ({ id: t.id, key: t.key, duration: t.duration, deps: t.deps, skill: t.skill, exclusive: t.exclusive, equipment: t.equipment, alternatives: t.equipmentAlternatives, stage: t.stage })),
      personnel: built.personnel.map((p) => ({ id: p.id, skill: p.skill, efficiency: p.efficiency, shiftWindow: p.shiftWindow })),
      exclusive: (built.exclusive || []).map((e) => ({ id: e.id, capacity: e.capacity })),
      equipment: (built.equipment || []).map((e) => ({ id: e.id, type: e.type, capacity: e.capacity }))
    }
  })
}

function digestOf(orders, devCases, validationCases) {
  const payload = JSON.stringify({
    modelVersion: sim.MODEL_VERSION,
    featureVersion: prep.FEATURE_VERSION,
    paramVersion: prep.PARAM_VERSION,
    contract: contractSnapshot(orders, devCases.concat(validationCases))
  })
  return sha256(payload)
}

// 纯筛选：只取 dev/validation 的静态案例；出现 reserved 立即拒绝（防绕行）
function staticCasesFor(orders, set) {
  const catalog = evaluation.buildCaseCatalog(orders, evaluation.HISTORICAL_RESERVED_USED_FP)
  const cases = catalog.filter((c) => c.set === set && c.kind === 'static')
  if (cases.some((c) => c.set === 'reserved')) throw new Error('实验室禁止访问 reserved 保留集')
  return cases
}

function caseSetup(entry, ordersById) {
  const selOrders = entry.orders.map((id) => ordersById.get(id)).filter(Boolean)
  const personnel = entry.resources === 'tight' ? tightPersonnel() : sim.DEFAULT_PERSONNEL
  const built = sim.buildTaskSet(selOrders, { personnel })
  return { selOrders, tasks: built.tasks, personnel: built.personnel, exclusive: built.exclusive, equipment: built.equipment }
}

// 运行单个静态案例的方案 C（weights=null 表示原 C）
function runCaseC(entry, ordersById, weights, seed) {
  const { tasks, personnel, exclusive, equipment } = caseSetup(entry, ordersById)
  const t0 = performance.now()
  let strat
  try {
    strat = weights
      ? sched.buildStrategyCLearned(tasks, entry.orders, personnel, exclusive, equipment, weights)
      : sched.buildStrategyC(tasks, entry.orders, personnel, exclusive, equipment, seed)
  } catch (e) {
    return {
      id: entry.id,
      fingerprint: entry.fingerprint,
      orders: entry.orders,
      status: 'infeasible',
      feasible: false,
      reason: e.message,
      makespan: null,
      onlineStopTotal: null,
      attempts: e.candidateAttempts != null ? e.candidateAttempts : e.attempts != null ? e.attempts : null,
      maxCandidateAttempts: e.maxCandidateAttempts != null ? e.maxCandidateAttempts : null,
      computeTimeMs: Number((performance.now() - t0).toFixed(1))
    }
  }
  const metrics = sched.computeMetrics(strat.entries, personnel, exclusive, entry.orders, equipment)
  const validation = sched.validateSchedule(strat.entries, tasks, personnel, { equipment })
  return {
    id: entry.id,
    fingerprint: entry.fingerprint,
    orders: entry.orders,
    status: validation.ok ? 'ok' : 'invalid',
    feasible: validation.ok,
    reason: validation.ok ? null : validation.violations.slice(0, 3).map((v) => v.detail).join('；'),
    makespan: metrics.makespan,
    onlineStopTotal: metrics.onlineStopTotal,
    attempts: strat.candidateAttempts,
    maxCandidateAttempts: strat.maxCandidateAttempts,
    learned: !!strat.learned,
    computeTimeMs: Number((performance.now() - t0).toFixed(1))
  }
}

// ---------------------------------------------------------------------------
// 1. 开发集历史分析（真实运行原 C，汇总等待/占用/关键路径贡献）
// ---------------------------------------------------------------------------

function deepDepth(tasks) {
  const succ = new Map()
  for (const t of tasks) succ.set(t.id, [])
  for (const t of tasks) for (const d of t.deps) if (succ.has(d)) succ.get(d).push(t.id)
  const memo = new Map()
  const depth = (id) => {
    if (memo.has(id)) return memo.get(id)
    const t = tasks.find((x) => x.id === id)
    if (!t) return 0
    let m = 0
    for (const s of succ.get(id) || []) m = Math.max(m, depth(s))
    const v = t.duration + m
    memo.set(id, v)
    return v
  }
  return depth
}

function analyzeDevHistory({ orders }) {
  const pending = pendingFor('history')
  if (pending) return { ...completePending(pending), recovered: true }
  const devCases = staticCasesFor(orders, 'dev')
  const byId = new Map(orders.map((o) => [o.order, o]))
  const perKey = new Map()
  const perStage = new Map()
  const perPerson = new Map()
  const perExclusive = new Map()
  const perEquipment = new Map()
  const evidence = []
  const baseline = []
  let criticalTotal = 0

  for (const entry of devCases) {
    const { tasks, personnel, exclusive, equipment } = caseSetup(entry, byId)
    const strat = sched.buildStrategyC(tasks, entry.orders, personnel, exclusive, equipment, LEARN_SEED)
    const metrics = sched.computeMetrics(strat.entries, personnel, exclusive, entry.orders, equipment)
    const depth = deepDepth(tasks)
    const cpLen = strat.entries.reduce((m, e) => Math.max(m, depth(e.id)), 0)
    criticalTotal += cpLen
    baseline.push({
      id: entry.id,
      fingerprint: entry.fingerprint,
      orders: entry.orders,
      resources: entry.resources || 'normal',
      feasible: true,
      makespan: metrics.makespan,
      onlineStopTotal: metrics.onlineStopTotal,
      attempts: strat.candidateAttempts,
      maxCandidateAttempts: strat.maxCandidateAttempts,
      criticalPath: metrics.criticalPath
    })

    for (const e of strat.entries) {
      const k = perKey.get(e.key) || { key: e.key, name: e.name, phase: e.phase, count: 0, durationTotal: 0, waitTotal: 0, delayedCount: 0, criticalContribution: 0 }
      k.count++
      k.durationTotal += e.duration
      k.waitTotal += e.resourceWait
      if (e.delayedByResource) k.delayedCount++
      k.criticalContribution += depth(e.id)
      perKey.set(e.key, k)

      const s = perStage.get(e.phase) || { phase: e.phase, count: 0, durationTotal: 0, waitTotal: 0 }
      s.count++
      s.durationTotal += e.duration
      s.waitTotal += e.resourceWait
      perStage.set(e.phase, s)

      const pp = perPerson.get(e.assigneeId) || { id: e.assigneeId, name: e.assigneeName, busy: 0, wait: 0, tasks: 0 }
      pp.busy += e.duration
      pp.wait += e.resourceWait
      pp.tasks++
      perPerson.set(e.assigneeId, pp)

      if (e.exclusive && e.exclusive !== 'LINE-01') {
        const ex = perExclusive.get(e.exclusive) || { id: e.exclusive, busy: 0, wait: 0, tasks: 0 }
        ex.busy += e.duration
        ex.wait += e.resourceWait
        ex.tasks++
        perExclusive.set(e.exclusive, ex)
      }
      if (e.equipment) {
        const eq = perEquipment.get(e.equipment) || { id: e.equipment, busy: 0, wait: 0, tasks: 0 }
        eq.busy += e.duration
        eq.wait += e.resourceWait
        eq.tasks++
        perEquipment.set(e.equipment, eq)
      }
      if (e.stage === 'prep') {
        evidence.push({ caseId: entry.id, taskId: e.id, key: e.key, skill: e.skill, exclusive: e.exclusive || null, equipment: e.equipment || null, duration: e.duration, start: e.start, end: e.end, resourceWait: e.resourceWait, criticalRemaining: depth(e.id) })
      }
    }
  }

  const round2 = (x) => Math.round(x * 100) / 100
  const list = (m) => Array.from(m.values()).map((v) => ({ ...v, waitTotal: round2(v.waitTotal), durationTotal: round2(v.durationTotal), busy: v.busy != null ? round2(v.busy) : undefined, criticalContribution: v.criticalContribution != null ? round2(v.criticalContribution) : undefined }))
  const byKey = list(perKey).sort((a, b) => b.waitTotal - a.waitTotal || b.criticalContribution - a.criticalContribution)
  const bottlenecks = byKey.slice(0, 5).map((k, i) => ({ rank: i + 1, key: k.key, name: k.name, waitTotal: k.waitTotal, criticalContribution: k.criticalContribution, delayedCount: k.delayedCount, note: `开发集累计资源等待 ${k.waitTotal} 分钟、关键路径贡献 ${k.criticalContribution} 分钟` }))

  const summary = {
    runId: `lab-history-${crypto.randomUUID()}`,
    generatedAt: nowISO(),
    modelVersion: sim.MODEL_VERSION,
    featureVersion: prep.FEATURE_VERSION,
    paramVersion: prep.PARAM_VERSION,
    source: 'dev 集静态场景，使用原方案 C 真实排程执行记录（非字符串描述、非随机数）',
    seed: LEARN_SEED,
    caseCount: devCases.length,
    caseFingerprints: devCases.map((c) => c.fingerprint),
    criticalPathTotal: round2(criticalTotal),
    baseline,
    aggregate: {
      byKey,
      byStage: list(perStage).sort((a, b) => b.waitTotal - a.waitTotal),
      byPerson: list(perPerson).sort((a, b) => b.wait - a.wait),
      byExclusive: list(perExclusive).sort((a, b) => b.wait - a.wait),
      byEquipment: list(perEquipment).sort((a, b) => b.wait - a.wait)
    },
    bottlenecks,
    evidenceSample: evidence.sort((a, b) => b.resourceWait - a.resourceWait).slice(0, 60),
    declaration: '瓶颈计算基于开发集真实排程执行记录，仅使用决策时刻已知的任务图与资源特征，不使用未来异常信息。'
  }
  const usageRecords = [{
    runId: summary.runId,
    at: summary.generatedAt,
    effectiveSets: ['dev'],
    fingerprints: devCases.map((c) => c.fingerprint),
    reservedRun: false,
    stage: 'history',
    strategy: 'C',
    paramId: null,
    caseFingerprints: devCases.map((c) => c.fingerprint)
  }]
  return persistPending({ kind: 'history', usageRecords, runId: summary.runId, usedFingerprints: summary.caseFingerprints, evidence: summary, pendingAt: nowISO() })
}

// ---------------------------------------------------------------------------
// 2. 固定实验协议
// ---------------------------------------------------------------------------

function getProtocol() {
  return readJSON(PROTOCOL_FILE, null)
}

function ensureProtocol(orders, roundOverride) {
  const devCases = staticCasesFor(orders, 'dev')
  const validationCases = staticCasesFor(orders, 'validation')
  const digest = digestOf(orders, devCases, validationCases)
  const existing = getProtocol()
  if (existing && existing.digest === digest && !roundOverride) return { protocol: existing, devCases, validationCases, reused: true }
  const round = roundOverride || (existing ? existing.round || 1 : 1)
  const protocol = {
    protocolId: `proto-${Date.now().toString(36)}`,
    round,
    createdAt: nowISO(),
    modelVersion: sim.MODEL_VERSION,
    featureVersion: prep.FEATURE_VERSION,
    paramVersion: prep.PARAM_VERSION,
    digest,
    seed: LEARN_SEED,
    validationSeed: VALIDATION_SEED,
    candidates: prep.CANDIDATE_PARAMS.map((p) => ({ id: p.id, name: p.name, meaning: p.meaning, weights: p.weights })),
    devCases: devCases.map((c) => ({ id: c.id, set: c.set, category: c.category, orders: c.orders, fingerprint: c.fingerprint, resources: c.resources || 'normal' })),
    validationCases: validationCases.map((c) => ({ id: c.id, set: c.set, category: c.category, orders: c.orders, fingerprint: c.fingerprint, resources: c.resources || 'normal' })),
    objective: OBJECTIVE,
    activationRule: ACTIVATION_RULE,
    budgetRule: BUDGET_RULE,
    validationSetNote: '验证集此前已被使用，本轮标记为“已使用的固定验证集”，不作为全新盲测；本轮对其只运行一次正式对照。',
    reservedNote: '新的 12 个 reserved 保留案例本轮不得求解，也不读取其结果用于参数选择。',
    declaration: '本实验为基于仿真历史的离线参数自优化（有限、可解释参数搜索），不称为强化学习、工厂在线学习或大模型推理。'
  }
  writeJSON(PROTOCOL_FILE, protocol)
  return { protocol, devCases, validationCases, reused: false }
}

// 归档当前轮次（完整保存旧协议、选择、验证与启用状态），并开始新编号轮次。
function archiveCurrent(reason) {
  const protocol = readJSON(PROTOCOL_FILE, null)
  const selection = readJSON(SELECTION_FILE, null)
  const validation = readJSON(VALIDATION_FILE, null)
  const state = readJSON(STATE_FILE, null)
  if (!protocol && !selection && !validation) return null
  const archive = readJSON(ARCHIVE_FILE, []) || []
  const entry = { round: protocol ? protocol.round || null : null, protocolId: protocol ? protocol.protocolId : null, selectionId: selection ? selection.selectionId : null, archivedAt: nowISO(), reason, protocol, selection, validation, state }
  archive.push(entry)
  writeJSON(ARCHIVE_FILE, archive)
  return entry
}

function beginNewRound(reason, orders) {
  pendingFor(null)
  const existing = getProtocol()
  archiveCurrent(reason)
  const nextRound = ((existing && existing.round) || 0) + 1
  writeJSON(SELECTION_FILE, null)
  writeJSON(VALIDATION_FILE, null)
  writeJSON(PENDING_FILE, null)
  writeJSON(STATE_FILE, { modelVersion: sim.MODEL_VERSION, activeStrategy: 'C', activeTemplateId: null, rolledBackAt: nowISO(), reason: '开始新一轮实验，回退到原策略' })
  const { protocol } = ensureProtocol(orders, nextRound)
  return protocol
}

// ---------------------------------------------------------------------------
// 3. 候选搜索与锁定（仅 dev）
// ---------------------------------------------------------------------------

function currentRoundBinding() {
  const protocol = getProtocol()
  const selection = readJSON(SELECTION_FILE, null)
  const locked = !!(protocol && selection && selection.protocolId === protocol.protocolId && selection.protocolDigest === protocol.digest)
  return { protocol, selection, locked }
}

function emitPending(pending) {
  for (const rec of pending.usageRecords || []) {
    evaluation.emitUsage(rec, { runId: pending.runId, usedFingerprints: pending.usedFingerprints })
  }
}

// 已执行但尚未完成记账的运行必须先恢复；不能被另一入口或重置覆盖。
function pendingFor(kind) {
  const pending = readJSON(PENDING_FILE, null)
  if (pending && pending.kind !== kind) {
    const error = new Error(`运行 ${pending.runId}（${pending.kind}）待补记，请先重试该入口，再开始其他操作。`)
    error.code = 'LAB_USAGE_PENDING'
    error.executed = true
    error.runId = pending.runId
    error.usedFingerprints = pending.usedFingerprints.slice()
    throw error
  }
  return pending
}

function completePending(pending) {
  try {
    return publishPending(pending)
  } catch (error) {
    error.executed = true
    error.runId = pending.runId
    error.usedFingerprints = pending.usedFingerprints.slice()
    throw error
  }
}

function publishPending(pending) {
  emitPending(pending)
  let result
  if (pending.kind === 'history') {
    result = pending.evidence
    writeJSON(HISTORY_FILE, result)
  } else if (pending.kind === 'experiment') {
    result = pending.experiment
    writeJSON(SELECTION_FILE, pending.selection || null)
    writeJSON(EXPERIMENT_FILE, result)
  } else if (pending.kind === 'validation') {
    result = pending.evidence
    writeJSON(VALIDATION_FILE, result)
  } else {
    throw new Error(`未知待记账运行类型：${pending.kind}`)
  }
  // 结果发布也可能失败，成功前保留恢复记录；重试依靠 runId 幂等补记。
  writeJSON(PENDING_FILE, null)
  return result
}

function persistPending(pending) {
  try {
    writeJSON(PENDING_FILE, pending)
    return completePending(pending)
  } catch (error) {
    error.executed = true
    error.runId = pending.runId
    error.usedFingerprints = pending.usedFingerprints.slice()
    throw error
  }
}

function runExperiment({ orders, newRound = false }) {
  const pending = pendingFor('experiment')
  if (newRound) beginNewRound('显式开始新一轮参数实验', orders)
  if (pending) return { ...completePending(pending), recovered: true }
  const { protocol, devCases } = ensureProtocol(orders)
  const byId = new Map(orders.map((o) => [o.order, o]))
  const history = readJSON(HISTORY_FILE, null)
  if (!history) throw new Error('请先运行开发历史分析（/api/lab/analyze）')
  const devFps = devCases.map((c) => c.fingerprint)

  // 待记账运行恢复：先补记原运行，再返回恢复结果，不从缓存跳过记账
  // 同一已锁定轮次的普通重复请求：复用既有结果，不重新求解或覆盖
  const binding = currentRoundBinding()
  if (binding.locked) {
    const existing = readJSON(EXPERIMENT_FILE, null) || {}
    return {
      ...existing,
      reused: true,
      note: `第 ${protocol.round || 1} 轮已锁定选择 ${binding.selection.selectionId}；普通重复请求复用既有结果，如需重跑请显式开始新一轮（newRound）。`
    }
  }

  // 基线：原 C（开发集）；用于“原 C 可行则候选必须可行”的筛选，并单独计入成本与使用记录
  const baseline = {}
  for (const entry of devCases) baseline[entry.id] = runCaseC(entry, byId, null, LEARN_SEED)
  const baselineFeasibleIds = new Set(devCases.filter((e) => baseline[e.id].feasible).map((e) => e.id))
  const baselineAttempts = devCases.reduce((s, e) => s + (baseline[e.id].attempts || 0), 0)
  const baselineComputeMs = devCases.reduce((s, e) => s + (baseline[e.id].computeTimeMs || 0), 0)

  const candidates = protocol.candidates.map((c, idx) => {
    const perCase = devCases.map((entry) => runCaseC(entry, byId, c.weights, LEARN_SEED))
    const feasibleOnBaseline = devCases.every((entry) => !baselineFeasibleIds.has(entry.id) || perCase.find((r) => r.id === entry.id).feasible)
    const feasibleCount = perCase.filter((r) => r.feasible).length
    const feasibleCases = perCase.filter((r) => r.feasible)
    const sumMakespan = feasibleCases.length ? Number(feasibleCases.reduce((s, r) => s + r.makespan, 0).toFixed(2)) : null
    const sumOnlineStop = feasibleCases.length ? Number(feasibleCases.reduce((s, r) => s + r.onlineStopTotal, 0).toFixed(2)) : null
    const actualAttempts = perCase.reduce((s, r) => s + (r.attempts != null ? r.attempts : 0), 0)
    const unknownAttemptCases = perCase.filter((r) => r.attempts == null).length
    const failureReasons = perCase.filter((r) => !r.feasible).map((r) => `${r.id}: ${r.reason}`)
    return {
      index: idx,
      id: c.id,
      name: c.name,
      meaning: c.meaning,
      weights: c.weights,
      feasibleOnBaselineCases: feasibleOnBaseline,
      feasibleCount,
      caseCount: devCases.length,
      feasibleRate: devCases.length ? Number(((feasibleCount / devCases.length) * 100).toFixed(1)) : 0,
      sumMakespan,
      sumOnlineStop,
      actualAttempts,
      unknownAttemptCases,
      failureReasons,
      totalComputeMs: Number(perCase.reduce((s, r) => s + (r.computeTimeMs || 0), 0).toFixed(1)),
      perCase
    }
  })

  const sortKey = (c) => (c.sumMakespan == null ? Number.POSITIVE_INFINITY : c.sumMakespan)
  const eligible = candidates.filter((c) => c.feasibleOnBaselineCases)
  eligible.sort((a, b) => sortKey(a) - sortKey(b) || (a.sumOnlineStop == null ? Infinity : a.sumOnlineStop) - (b.sumOnlineStop == null ? Infinity : b.sumOnlineStop) || a.index - b.index)
  const selected = eligible[0] || null

  const experiment = {
    runId: `lab-experiment-${Date.now().toString(36)}`,
    generatedAt: nowISO(),
    round: protocol.round || 1,
    protocolId: protocol.protocolId,
    protocolDigest: protocol.digest,
    modelVersion: sim.MODEL_VERSION,
    featureVersion: prep.FEATURE_VERSION,
    paramVersion: prep.PARAM_VERSION,
    seed: LEARN_SEED,
    devCaseCount: devCases.length,
    devCaseFingerprints: devFps,
    baseline,
    baselineCost: { stage: 'baseline', strategy: 'C', paramId: null, caseCount: devCases.length, attempts: baselineAttempts, computeMs: Number(baselineComputeMs.toFixed(1)), note: '参数实验中重新计算的原 C 基线成本，单独计入使用记录。' },
    candidates,
    eligibleIds: eligible.map((c) => c.id),
    selectedId: selected ? selected.id : null,
    selectionBasis: selected
      ? `在 ${eligible.length} 组满足“原 C 可行案例全可行”的候选中，按开发案例总历时之和最小（${selected.sumMakespan} 分钟）、并列按在线停线合计（${selected.sumOnlineStop} 分钟）与参数序号，选定 ${selected.id}。`
      : '没有任何候选在原 C 可行的开发案例上全部可行。',
    budgetRule: BUDGET_RULE,
    historyCostNote: `历史参数搜索成本：${candidates.length} 组候选 × ${devCases.length} 个开发案例，实际候选排程尝试合计 ${candidates.reduce((s, c) => s + c.actualAttempts, 0)} 次；另叠加重新计算的原 C 基线 ${baselineAttempts} 次，均单独列出。`,
    objective: OBJECTIVE
  }

  let selection = null
  if (selected) {
    selection = {
      selectionId: `sel-${Date.now().toString(36)}`,
      lockedAt: nowISO(),
      round: protocol.round || 1,
      protocolId: protocol.protocolId,
      protocolDigest: protocol.digest,
      modelVersion: sim.MODEL_VERSION,
      featureVersion: prep.FEATURE_VERSION,
      paramVersion: prep.PARAM_VERSION,
      seed: LEARN_SEED,
      templateId: selected.id,
      name: selected.name,
      meaning: selected.meaning,
      weights: selected.weights,
      devCaseCount: devCases.length,
      devCaseFingerprints: devFps,
      devSumMakespan: selected.sumMakespan,
      devSumOnlineStop: selected.sumOnlineStop,
      selectionBasis: experiment.selectionBasis,
      immutable: true,
      candidateSummary: candidates.map((c) => ({ id: c.id, feasibleOnBaselineCases: c.feasibleOnBaselineCases, feasibleCount: c.feasibleCount, sumMakespan: c.sumMakespan, sumOnlineStop: c.sumOnlineStop, actualAttempts: c.actualAttempts, unknownAttemptCases: c.unknownAttemptCases, totalComputeMs: c.totalComputeMs }))
    }
    experiment.selectionId = selection.selectionId
  }

  const usageRecords = [
    {
      runId: `${experiment.runId}-baseline`,
      at: experiment.generatedAt,
      effectiveSets: ['dev'],
      fingerprints: devFps,
      reservedRun: false,
      stage: 'baseline',
      strategy: 'C',
      paramId: null,
      caseFingerprints: devFps,
      attempts: baselineAttempts
    },
    {
      runId: experiment.runId,
      at: experiment.generatedAt,
      effectiveSets: ['dev'],
      fingerprints: devFps,
      reservedRun: false,
      stage: 'candidate',
      strategy: 'C-learned',
      paramId: selected ? selected.id : null,
      caseFingerprints: devFps,
      attemptsByParam: candidates.map((c) => ({ paramId: c.id, attempts: c.actualAttempts, unknownAttemptCases: c.unknownAttemptCases })),
      baselineAttempts
    }
  ]

  return persistPending({ kind: 'experiment', usageRecords, runId: experiment.runId, usedFingerprints: devFps, experiment, selection, pendingAt: nowISO() })
}

// ---------------------------------------------------------------------------
// 4. 验证集一次对照（仅 validation）
// ---------------------------------------------------------------------------

function statOf(values) {
  const v = values.filter((x) => typeof x === 'number' && Number.isFinite(x)).sort((a, b) => a - b)
  if (!v.length) return { n: 0, mean: null, median: null, p95: null }
  const r2 = (x) => Math.round(x * 100) / 100
  const pctl = (p) => v[Math.min(v.length - 1, Math.ceil(p * v.length) - 1)]
  return { n: v.length, mean: r2(v.reduce((s, x) => s + x, 0) / v.length), median: r2(pctl(0.5)), p95: r2(pctl(0.95)) }
}

function runValidation({ orders }) {
  const pending = pendingFor('validation')
  if (pending) return { ...completePending(pending), recovered: true }
  const selection = readJSON(SELECTION_FILE, null)
  if (!selection) throw new Error('尚未锁定参数，无法验证')
  const protocol = getProtocol()
  if (protocol && selection.protocolId !== protocol.protocolId) throw new Error('选择与当前协议轮次不匹配，禁止跨轮验证')

  const existing = readJSON(VALIDATION_FILE, null)
  if (existing && !existing.invalidated) {
    return { ...existing, reused: true, note: '验证集本轮已运行一次正式对照，不重复调参；返回既有记录。' }
  }
  const validationCases = staticCasesFor(orders, 'validation')
  const byId = new Map(orders.map((o) => [o.order, o]))
  const weights = selection.weights

  const cases = validationCases.map((entry) => {
    const base = runCaseC(entry, byId, null, VALIDATION_SEED)
    const learned = runCaseC(entry, byId, weights, VALIDATION_SEED)
    let status = 'tie'
    if (!learned.feasible && base.feasible) status = 'newly_infeasible'
    else if (!learned.feasible) status = 'infeasible'
    else if (base.feasible) {
      const d = base.makespan - learned.makespan
      status = d > 0.05 ? 'improved' : d < -0.05 ? 'worse' : 'tie'
    }
    // 运行时回退：C-learned 不可行但原 C 可行则采用原 C；该次计算已计入预算
    const adopted = learned.feasible ? learned : base
    return {
      id: entry.id,
      fingerprint: entry.fingerprint,
      category: entry.category,
      orders: entry.orders,
      status,
      baseline: { feasible: base.feasible, makespan: base.makespan, onlineStopTotal: base.onlineStopTotal, attempts: base.attempts, maxCandidateAttempts: base.maxCandidateAttempts, computeTimeMs: base.computeTimeMs, reason: base.reason },
      learned: { feasible: learned.feasible, makespan: learned.makespan, onlineStopTotal: learned.onlineStopTotal, attempts: learned.attempts, maxCandidateAttempts: learned.maxCandidateAttempts, computeTimeMs: learned.computeTimeMs, reason: learned.reason },
      adopted: { source: learned.feasible ? 'C-learned' : 'original-C-fallback', feasible: adopted.feasible, makespan: adopted.makespan, onlineStopTotal: adopted.onlineStopTotal },
      usedFallback: !learned.feasible && base.feasible
    }
  })

  const baseFeasible = cases.filter((c) => c.baseline.feasible)
  const pairs = baseFeasible.filter((c) => c.learned.feasible)
  const newlyInfeasible = cases.filter((c) => c.status === 'newly_infeasible')
  const improved = pairs.filter((c) => c.status === 'improved').length
  const tie = pairs.filter((c) => c.status === 'tie').length
  const worse = pairs.filter((c) => c.status === 'worse').length

  const sumBaseMakespan = Number(baseFeasible.reduce((s, c) => s + c.baseline.makespan, 0).toFixed(2))
  const sumLearnMakespan = Number(pairs.reduce((s, c) => s + c.learned.makespan, 0).toFixed(2))
  const sumBaseOnline = Number(baseFeasible.reduce((s, c) => s + c.baseline.onlineStopTotal, 0).toFixed(2))
  const sumLearnOnline = Number(pairs.reduce((s, c) => s + c.learned.onlineStopTotal, 0).toFixed(2))

  const noNewInfeasible = newlyInfeasible.length === 0
  const makespanNotWorse = sumLearnMakespan <= sumBaseMakespan + 1e-6
  const onlineNotWorse = sumLearnOnline <= sumBaseOnline + 1e-6
  const eligible = noNewInfeasible && makespanNotWorse && onlineNotWorse

  const reasons = []
  if (!noNewInfeasible) reasons.push(`原 C 可行的验证案例中有 ${newlyInfeasible.length} 个在 C-learned 下不可行`)
  if (!makespanNotWorse) reasons.push(`验证集总历时之和劣于原 C（${sumLearnMakespan} > ${sumBaseMakespan}）`)
  if (!onlineNotWorse) reasons.push(`验证集在线停线合计劣于原 C（${sumLearnOnline} > ${sumBaseOnline}）`)

  const perCasePct = pairs.map((c) => (c.baseline.makespan ? ((c.baseline.makespan - c.learned.makespan) / c.baseline.makespan) * 100 : 0))
  const weightedPct = sumBaseMakespan ? Number((((sumBaseMakespan - sumLearnMakespan) / sumBaseMakespan) * 100).toFixed(2)) : null

  const record = {
    runId: `lab-validation-${Date.now().toString(36)}`,
    generatedAt: nowISO(),
    round: selection.round || (protocol ? protocol.round : null),
    protocolId: selection.protocolId,
    protocolDigest: selection.protocolDigest,
    selectionId: selection.selectionId,
    templateId: selection.templateId,
    modelVersion: sim.MODEL_VERSION,
    featureVersion: prep.FEATURE_VERSION,
    paramVersion: prep.PARAM_VERSION,
    seed: VALIDATION_SEED,
    validationSetNote: '验证集此前已被使用，标记为“已使用的固定验证集”；本轮仅运行一次正式对照。',
    caseCount: cases.length,
    caseFingerprints: cases.map((c) => c.fingerprint),
    newlyInfeasibleCount: newlyInfeasible.length,
    usedFallbackCount: cases.filter((c) => c.usedFallback).length,
    improvement: { n: pairs.length, denominator: baseFeasible.length, improved, tie, worse, weightedPct, perCaseMeanPct: perCasePct.length ? Number((perCasePct.reduce((s, x) => s + x, 0) / perCasePct.length).toFixed(2)) : null },
    makespan: { baseline: statOf(baseFeasible.map((c) => c.baseline.makespan)), learned: statOf(pairs.map((c) => c.learned.makespan)), sumBaseline: sumBaseMakespan, sumLearned: sumLearnMakespan },
    onlineStop: { baseline: statOf(baseFeasible.map((c) => c.baseline.onlineStopTotal)), learned: statOf(pairs.map((c) => c.learned.onlineStopTotal)), sumBaseline: sumBaseOnline, sumLearned: sumLearnOnline },
    budget: {
      rule: BUDGET_RULE,
      baselineAttempts: cases.reduce((s, c) => s + (c.baseline.attempts != null ? c.baseline.attempts : 0), 0),
      learnedAttempts: cases.reduce((s, c) => s + (c.learned.attempts != null ? c.learned.attempts : 0), 0),
      baselineMax: cases.reduce((s, c) => s + (c.baseline.maxCandidateAttempts || 0), 0),
      learnedMax: cases.reduce((s, c) => s + (c.learned.maxCandidateAttempts || 0), 0)
    },
    eligibleForActivation: eligible,
    reasons,
    conclusion: eligible
      ? '验证通过：C-learned 未新增不可行，且总历时之和与在线停线合计均不劣于原 C，可供启用。'
      : '验证未通过启用条件，保留原策略 C。可完成学习流程验收，但不宣称性能提高。',
    cases,
    rawVsAdopted: cases.map((c) => ({ id: c.id, raw: c.learned, adopted: c.adopted, usedFallback: c.usedFallback })),
    declaration: '验证结果均为仿真结果，不代表工厂实测；OEE 待验证。'
  }

  const usageRecords = [
    { runId: `${record.runId}-C`, at: record.generatedAt, effectiveSets: ['validation'], fingerprints: record.caseFingerprints, reservedRun: false, stage: 'validation', strategy: 'C', paramId: null, caseFingerprints: record.caseFingerprints },
    { runId: `${record.runId}-learned`, at: record.generatedAt, effectiveSets: ['validation'], fingerprints: record.caseFingerprints, reservedRun: false, stage: 'validation', strategy: 'C-learned', paramId: record.templateId, caseFingerprints: record.caseFingerprints }
  ]

  return persistPending({ kind: 'validation', usageRecords, runId: record.runId, usedFingerprints: record.caseFingerprints, evidence: record, pendingAt: nowISO() })
}

// ---------------------------------------------------------------------------
// 5. 启用 / 回滚 / 适用性
// ---------------------------------------------------------------------------

function getState() {
  return readJSON(STATE_FILE, { modelVersion: sim.MODEL_VERSION, activeStrategy: 'C', activeTemplateId: null })
}

// 纯函数：模板适用性判定（便于独立测试，不依赖文件）
function applicabilityOf(selection, currentDigest, currentModelVersion) {
  if (!selection) return { applicable: false, reason: '尚无锁定的候选模板' }
  if (selection.modelVersion !== currentModelVersion) return { applicable: false, reason: `模型版本不匹配（模板 ${selection.modelVersion} ≠ 当前 ${currentModelVersion}）` }
  if (selection.featureVersion !== prep.FEATURE_VERSION || selection.paramVersion !== prep.PARAM_VERSION) return { applicable: false, reason: `特征/参数版本不匹配（模板 ${selection.featureVersion}/${selection.paramVersion}）` }
  if (selection.protocolDigest !== currentDigest) return { applicable: false, reason: '任务合同或数据摘要已变化，旧模板不适用' }
  return { applicable: true, reason: null }
}

function computeApplicability(orders) {
  const selection = readJSON(SELECTION_FILE, null)
  if (!selection) return { applicable: false, reason: '尚无锁定的候选模板' }
  const protocol = getProtocol()
  if (protocol && selection.protocolId !== protocol.protocolId) return { applicable: false, reason: `选择与当前协议轮次不匹配（选择 ${selection.protocolId} ≠ 协议 ${protocol.protocolId}）` }
  const devCases = staticCasesFor(orders, 'dev')
  const validationCases = staticCasesFor(orders, 'validation')
  const currentDigest = digestOf(orders, devCases, validationCases)
  return applicabilityOf(selection, currentDigest, sim.MODEL_VERSION)
}

function getActiveOverride(orders) {
  const state = getState()
  if (state.activeStrategy !== 'C-learned') return null
  const selection = readJSON(SELECTION_FILE, null)
  if (!selection) return null
  if (state.selectionId && state.selectionId !== selection.selectionId) return null
  const app = computeApplicability(orders)
  if (!app.applicable) return null
  return { templateId: selection.templateId, weights: selection.weights, maxAttempts: null }
}

function activate({ orders }) {
  pendingFor(null)
  const selection = readJSON(SELECTION_FILE, null)
  if (!selection) throw new Error('尚未锁定参数模板')
  const protocol = getProtocol()
  if (protocol && selection.protocolId !== protocol.protocolId) throw new Error('选择与当前协议轮次不匹配，禁止启用')
  const validation = readJSON(VALIDATION_FILE, null)
  if (!validation || validation.invalidated) throw new Error('尚未完成一次有效验证，不能启用')
  if (validation.selectionId !== selection.selectionId || validation.protocolId !== selection.protocolId) throw new Error('验证记录与当前选择/轮次不匹配，禁止启用')
  if (!validation.eligibleForActivation) throw new Error(`验证未通过启用条件：${validation.reasons.join('；')}。保留原策略 C。`)
  const app = computeApplicability(orders)
  if (!app.applicable) throw new Error(`模板不适用：${app.reason}`)
  const state = { modelVersion: sim.MODEL_VERSION, activeStrategy: 'C-learned', activeTemplateId: selection.templateId, round: selection.round || (protocol ? protocol.round : null), protocolId: selection.protocolId, selectionId: selection.selectionId, activatedAt: nowISO(), reason: '验证通过且模板适用，已启用候选模板' }
  writeJSON(STATE_FILE, state)
  return state
}

function rollback({ reason }) {
  const state = { modelVersion: sim.MODEL_VERSION, activeStrategy: 'C', activeTemplateId: null, rolledBackAt: nowISO(), reason: reason || '手动回滚到 v4.2.2 原策略 C' }
  writeJSON(STATE_FILE, state)
  return state
}

function reset({ orders }) {
  const previous = { protocol: getProtocol(), selection: readJSON(SELECTION_FILE, null), validation: readJSON(VALIDATION_FILE, null) }
  const protocol = beginNewRound('显式重置，归档旧轮次并开始新一轮', orders)
  return { ok: true, resetAt: nowISO(), newProtocolId: protocol.protocolId, newRound: protocol.round, clearedSelection: !!previous.selection, archivedValidationRunId: previous.validation ? previous.validation.runId : null }
}

// ---------------------------------------------------------------------------
// 6. 状态汇总（只读，不求解）
// ---------------------------------------------------------------------------

function status({ orders }) {
  const history = readJSON(HISTORY_FILE, null)
  const protocol = getProtocol()
  const experiment = readJSON(EXPERIMENT_FILE, null)
  const selection = readJSON(SELECTION_FILE, null)
  const validationRaw = readJSON(VALIDATION_FILE, null)
  const validation = validationRaw && !validationRaw.invalidated ? validationRaw : null
  const pending = readJSON(PENDING_FILE, null)
  const archive = readJSON(ARCHIVE_FILE, []) || []
  const state = getState()
  const app = computeApplicability(orders)
  const effectiveStrategy = state.activeStrategy === 'C-learned' && app.applicable ? 'C-learned' : 'C'
  const catalog = evaluation.buildCaseCatalog(orders, evaluation.HISTORICAL_RESERVED_USED_FP)
  const reserved = catalog.filter((c) => c.set === 'reserved')
  const core = catalog.filter((c) => c.set !== 'reserved')
  return {
    modelVersion: sim.MODEL_VERSION,
    featureVersion: prep.FEATURE_VERSION,
    paramVersion: prep.PARAM_VERSION,
    round: protocol ? protocol.round || null : null,
    declaration: '基于仿真历史的离线参数自优化（有限、可解释参数搜索），不接大模型、不称为强化学习或工厂在线学习。所有结果为仿真结果。',
    protocol,
    history: history ? { generatedAt: history.generatedAt, caseCount: history.caseCount, source: history.source, criticalPathTotal: history.criticalPathTotal, bottlenecks: history.bottlenecks, aggregate: history.aggregate, evidenceSample: history.evidenceSample, baseline: history.baseline } : null,
    experiment: experiment ? { runId: experiment.runId, generatedAt: experiment.generatedAt, round: experiment.round, selectedId: experiment.selectedId, selectionBasis: experiment.selectionBasis, historyCostNote: experiment.historyCostNote, baselineCost: experiment.baselineCost, candidates: experiment.candidates.map((c) => ({ id: c.id, name: c.name, meaning: c.meaning, weights: c.weights, feasibleOnBaselineCases: c.feasibleOnBaselineCases, feasibleCount: c.feasibleCount, caseCount: c.caseCount, feasibleRate: c.feasibleRate, sumMakespan: c.sumMakespan, sumOnlineStop: c.sumOnlineStop, actualAttempts: c.actualAttempts, unknownAttemptCases: c.unknownAttemptCases, failureReasons: c.failureReasons, totalComputeMs: c.totalComputeMs })) } : null,
    selection,
    validation: validation ? { runId: validation.runId, round: validation.round, templateId: validation.templateId, eligibleForActivation: validation.eligibleForActivation, reasons: validation.reasons, conclusion: validation.conclusion, improvement: validation.improvement, makespan: validation.makespan, onlineStop: validation.onlineStop, budget: validation.budget, newlyInfeasibleCount: validation.newlyInfeasibleCount, usedFallbackCount: validation.usedFallbackCount, cases: validation.cases, rawVsAdopted: validation.rawVsAdopted, validationSetNote: validation.validationSetNote } : null,
    state,
    applicability: app,
    effectiveStrategy,
    pendingUsage: pending ? { kind: pending.kind, runId: pending.runId, pendingAt: pending.pendingAt, note: '存在待记账运行，重试将先补记再返回结果。' } : null,
    archive: { rounds: archive.length, entries: archive.map((a) => ({ round: a.round, protocolId: a.protocolId, selectionId: a.selectionId, archivedAt: a.archivedAt, reason: a.reason, validationRunId: a.validation ? a.validation.runId : null })) },
    reserved: { available: reserved.length, solved: false, historicalUsed: evaluation.HISTORICAL_RESERVED_USED.length, retiredUnused: evaluation.RETIRED_UNUSED_RESERVED, coreCaseCount: core.length, note: '本轮不求解任何 reserved 保留案例。' }
  }
}

module.exports = { analyzeDevHistory, runExperiment, runValidation, activate, rollback, reset, status, getActiveOverride, computeApplicability, applicabilityOf, ensureProtocol, staticCasesFor, digestOf, archiveCurrent, beginNewRound, currentRoundBinding, LEARN_SEED, VALIDATION_SEED }
