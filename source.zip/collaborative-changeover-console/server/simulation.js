'use strict'

/**
 * 补充仿真模型（Simulation Model） · v4
 * -------------------------------------------------------------------------
 * 数据来源说明：
 *   1) 订单、成品、BOM、用量、交期 均来自《赛道数据包.xlsx》，为真实导入数据，本轮不做修改。
 *   2) 设备、人员、工序依赖、工序耗时、仿真日历与扩大规模 均为本项目建立的【补充仿真假设】，
 *      用于验证多智能体协同、排程与批量评测，【不代表工厂实测数据】。
 *   3) 版本：v4 新增设备类型与设备约束、12 名人员及班次可用时间、仿真数据层；v3 基准记录保留。
 *   4) 本模型只模拟“换产任务”本身，不模拟换产后订单正式生产时长，不构成完整生产排程。
 */

const MODEL_VERSION = 'v4.2.2-audited'

const SKILL_LABELS = {
  material: '物料员',
  equipment: '设备工程师',
  tooling: '工装工程师',
  quality: '质检员',
  operator: '操作工'
}

// 5 类设备类型（不同类型；每类的多个编号不重复计类型）
const EQUIPMENT_TYPES = [
  { type: 'PRINTER', name: '锡膏印刷机', operations: '清线/钢网更换、刮刀与锡膏切换（离线准备 + 在线换装）' },
  { type: 'MOUNTER', name: '贴片机', operations: '供料器上料、吸嘴更换、贴片程序切换（在线）' },
  { type: 'REFLOW', name: '回流焊炉', operations: '温区曲线方案离线准备与在线应用校准' },
  { type: 'AOI', name: '自动光学检测设备', operations: '首件外观/尺寸检测（AOI 程序切换）' },
  { type: 'ICT', name: '在线测试设备', operations: '返工后复检与电性能测试（ICT 夹具/程序切换）' }
]

// 设备实例：7 台，属 5 类。MOUNTER/PRINTER 各 2 台可作为替代方案。
const EQUIPMENT = [
  { id: 'PRT-01', type: 'PRINTER', name: '印刷机 PRT-01', capacity: 1, availability: '白班', note: '钢网与锡膏切换' },
  { id: 'PRT-02', type: 'PRINTER', name: '印刷机 PRT-02', capacity: 1, availability: '白班', note: 'PRT-01 的替代' },
  { id: 'MNT-01', type: 'MOUNTER', name: '贴片机 MNT-01', capacity: 1, availability: '白班', note: '供料器与贴片程序' },
  { id: 'MNT-02', type: 'MOUNTER', name: '贴片机 MNT-02', capacity: 1, availability: '白班', note: 'MNT-01 的替代' },
  { id: 'RFL-01', type: 'REFLOW', name: '回流焊炉 RFL-01', capacity: 1, availability: '白班', note: '温区曲线' },
  { id: 'AOI-01', type: 'AOI', name: 'AOI 检测设备 AOI-01', capacity: 1, availability: '白班', note: '首件检验' },
  { id: 'ICT-01', type: 'ICT', name: 'ICT 测试设备 ICT-01', capacity: 1, availability: '白班', note: '返工后复检' }
]

// 12 名人员，含技能、班次与可用时间窗口（仿真假设）。班次窗口会实际约束派工。
const SHIFT_WINDOWS = {
  白班: [0, 720],
  中班: [360, 1080],
  夜班: [720, 1440]
}

const DEFAULT_PERSONNEL = [
  { id: 'MAT-01', name: '物料员 张伟', skill: 'material', efficiency: 1.0, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'MAT-02', name: '物料员 李娜', skill: 'material', efficiency: 0.9, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'EQP-01', name: '设备工程师 王强', skill: 'equipment', efficiency: 1.0, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'EQP-02', name: '设备工程师 赵敏', skill: 'equipment', efficiency: 0.95, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'EQP-03', name: '设备工程师 钱峰', skill: 'equipment', efficiency: 0.9, shift: '中班', shiftWindow: SHIFT_WINDOWS['中班'] },
  { id: 'TLG-01', name: '工装工程师 陈涛', skill: 'tooling', efficiency: 1.0, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'TLG-02', name: '工装工程师 周敏', skill: 'tooling', efficiency: 0.9, shift: '中班', shiftWindow: SHIFT_WINDOWS['中班'] },
  { id: 'QC-01', name: '质检员 刘洋', skill: 'quality', efficiency: 1.0, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'QC-02', name: '质检员 孙丽', skill: 'quality', efficiency: 0.95, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'QC-03', name: '质检员 郑爽', skill: 'quality', efficiency: 0.9, shift: '中班', shiftWindow: SHIFT_WINDOWS['中班'] },
  { id: 'OPR-01', name: '操作工 周杰', skill: 'operator', efficiency: 1.0, shift: '白班', shiftWindow: SHIFT_WINDOWS['白班'] },
  { id: 'OPR-02', name: '操作工 吴凡', skill: 'operator', efficiency: 0.9, shift: '夜班', shiftWindow: SHIFT_WINDOWS['夜班'] }
]

const DEFAULT_EXCLUSIVE = [
  { id: 'AGV-01', name: 'AGV 配送车', capacity: 1, note: '线边配送独占资源（离线）' },
  { id: 'CAL-01', name: '离线参数校准台', capacity: 1, note: '参数方案离线准备与预校准（可提前）' },
  { id: 'LINE-01', name: 'SMT 混线产线', capacity: 1, note: '任一时刻仅允许一道在线换产占用，在位工装/参数锁定至质量放行后恢复生产' }
]

// equipment：任务必须占用的设备类型实例；equipmentAlternatives：符合约束的替代设备
const TASK_TEMPLATES = [
  {
    key: 'material_pick',
    name: '物料拣配',
    phase: '物料准备与配送',
    skill: 'material',
    exclusive: null,
    equipment: null,
    mode: 'offline',
    stage: 'prep',
    deps: [],
    base: (m) => 2 + 0.02 * m.bomLines + 0.015 * m.materialTypes,
    formula: '2 + 0.02×BOM行数 + 0.015×物料种类数',
    rationale: '按 BOM 行数决定拣配步数；可离线提前执行。'
  },
  {
    key: 'material_deliver',
    name: '线边配送',
    phase: '物料准备与配送',
    skill: 'material',
    exclusive: 'AGV-01',
    equipment: null,
    mode: 'offline',
    stage: 'prep',
    deps: ['material_pick'],
    base: (m) => 1.5 + 0.004 * m.materialTypes,
    formula: '1.5 + 0.004×物料种类数',
    rationale: 'AGV 配送至线边，受 AGV 独占约束。'
  },
  {
    key: 'tooling_prep',
    name: '离线工装准备',
    phase: '工装准备与切换',
    skill: 'tooling',
    exclusive: null,
    equipment: 'PRT-01',
    equipmentAlternatives: ['PRT-02'],
    mode: 'offline',
    stage: 'prep',
    deps: [],
    base: (m) => 1.5 + 0.012 * m.materialTypes,
    formula: '1.5 + 0.012×物料种类数',
    rationale: '在锡膏印刷机工位完成钢网/刮刀离线准备，可提前；PRT-02 为替代设备。'
  },
  {
    key: 'param_prepare',
    name: '参数方案准备(离线)',
    phase: '设备参数准备与校准',
    skill: 'equipment',
    exclusive: 'CAL-01',
    equipment: 'RFL-01',
    mode: 'offline',
    stage: 'prep',
    deps: [],
    base: (m) => 1.5 + 0.015 * m.materialTypes,
    formula: '1.5 + 0.015×物料种类数',
    rationale: '在离线校准台与回流焊炉准备温区曲线方案，不改变产线参数，可提前。'
  },
  {
    key: 'line_clear',
    name: '清线与旧工装拆卸(在线)',
    phase: '工装准备与切换',
    skill: 'operator',
    exclusive: 'LINE-01',
    equipment: 'PRT-01',
    equipmentAlternatives: ['PRT-02'],
    mode: 'online',
    stage: 'line',
    deps: ['tooling_prep', 'material_deliver'],
    base: (m) => 1 + 0.5 * m.faces.length,
    formula: '1 + 0.5×装配面数',
    rationale: '停线起点：下线当前产品、清线并拆卸旧钢网；占用印刷机工位。'
  },
  {
    key: 'tooling_switch',
    name: '工装切换(在线)',
    phase: '工装准备与切换',
    skill: 'equipment',
    exclusive: 'LINE-01',
    equipment: 'MNT-01',
    equipmentAlternatives: ['MNT-02'],
    mode: 'online',
    stage: 'line',
    deps: ['tooling_prep', 'material_deliver', 'line_clear'],
    base: (m) => 2 + 0.8 * m.faces.length,
    formula: '2 + 0.8×装配面数',
    rationale: '物料到线边后在线更换供料器/吸嘴并切换贴片程序，占用贴片机；MNT-02 为替代。'
  },
  {
    key: 'param_apply',
    name: '参数应用与校准(在线)',
    phase: '设备参数准备与校准',
    skill: 'equipment',
    exclusive: 'LINE-01',
    equipment: 'RFL-01',
    mode: 'online',
    stage: 'line',
    deps: ['param_prepare', 'tooling_switch'],
    base: (m) => 1.5 + 0.015 * m.materialTypes,
    formula: '1.5 + 0.015×物料种类数',
    rationale: '把离线温区曲线方案应用到产线并校准，占用回流焊炉。'
  },
  {
    key: 'fai_produce',
    name: '首件生产(在线)',
    phase: '首件检验与质量放行',
    skill: 'operator',
    exclusive: 'LINE-01',
    equipment: null,
    mode: 'online',
    stage: 'line',
    deps: ['param_apply'],
    base: (m) => 1.5 + Math.min(2, 0.0008 * (m.qty || 0)),
    formula: '1.5 + min(2, 0.0008×排产数量)',
    rationale: '首件生产时产品、工装、参数、物料须与本订单一致。'
  },
  {
    key: 'fai_inspect',
    name: '首件检验',
    phase: '首件检验与质量放行',
    skill: 'quality',
    exclusive: null,
    equipment: 'AOI-01',
    mode: 'offline',
    stage: 'post',
    deps: ['fai_produce'],
    base: () => 3,
    formula: '3（固定）',
    rationale: 'AOI 首件外观/尺寸检测，占用 AOI 设备。'
  },
  {
    key: 'quality_release',
    name: '质量放行',
    phase: '首件检验与质量放行',
    skill: 'quality',
    exclusive: null,
    equipment: null,
    mode: 'offline',
    stage: 'post',
    deps: ['fai_inspect'],
    base: () => 1.5,
    formula: '1.5（固定）',
    rationale: '质检员复核并签署放行。'
  },
  {
    key: 'resume',
    name: '恢复生产(在线)',
    phase: '首件检验与质量放行',
    skill: 'operator',
    exclusive: 'LINE-01',
    equipment: null,
    mode: 'online',
    stage: 'line',
    deps: ['quality_release'],
    base: () => 1,
    formula: '1（固定）',
    rationale: '质量门禁通过后恢复产线，本模型到此结束。'
  }
]

// 返工与复检（仅首件不合格时动态加入）
const DYNAMIC_TEMPLATES = [
  {
    key: 'rework',
    name: '返工与重新试制(在线)',
    phase: '首件检验与质量放行',
    skill: 'operator',
    exclusive: 'LINE-01',
    equipment: 'MNT-01',
    equipmentAlternatives: ['MNT-02'],
    mode: 'online',
    stage: 'line',
    deps: ['fai_inspect'],
    base: (m) => 2 + 0.4 * ((m.faces && m.faces.length) || 1),
    formula: '2 + 0.4×装配面数',
    rationale: '返工与重新试制，占用贴片机。'
  },
  {
    key: 'recheck',
    name: '复检(离线)',
    phase: '首件检验与质量放行',
    skill: 'quality',
    exclusive: null,
    equipment: 'ICT-01',
    mode: 'offline',
    stage: 'post',
    deps: ['rework'],
    base: () => 3,
    formula: '3（固定）',
    rationale: 'ICT 复检，占用在线测试设备。'
  }
]

const PHASES = ['物料准备与配送', '工装准备与切换', '设备参数准备与校准', '首件检验与质量放行']
const OFFLINE_PREP_KEYS = ['material_pick', 'material_deliver', 'tooling_prep', 'param_prepare']
const ONLINE_KEYS = ['line_clear', 'tooling_switch', 'param_apply', 'fai_produce', 'resume']
const POST_OFFLINE_KEYS = ['fai_inspect', 'quality_release']

function templateMetricsOf(orderLike) {
  return {
    bomLines: orderLike.bomLines || 0,
    materialTypes: orderLike.materialTypes || 0,
    faces: orderLike.faces || [],
    qty: orderLike.qty || 0
  }
}

function buildTaskSet(orders, options = {}) {
  const personnel = options.personnel || DEFAULT_PERSONNEL
  const exclusive = options.exclusive || DEFAULT_EXCLUSIVE
  const tasks = []
  for (const order of orders) {
    const metrics = templateMetricsOf(order)
    for (const tpl of TASK_TEMPLATES) {
      const base = Math.max(0.5, Number(tpl.base(metrics).toFixed(2)))
      tasks.push(materializeTask(tpl, order, metrics, base))
    }
  }
  return { tasks, personnel, exclusive, equipment: EQUIPMENT }
}

function materializeTask(tpl, order, metrics, base) {
  return {
    id: `${order.order}::${tpl.key}`,
    key: tpl.key,
    name: tpl.name,
    phase: tpl.phase,
    order: order.order,
    product: order.product,
    skill: tpl.skill,
    skillLabel: SKILL_LABELS[tpl.skill],
    exclusive: tpl.exclusive,
    equipment: tpl.equipment || null,
    equipmentAlternatives: tpl.equipmentAlternatives || [],
    mode: tpl.mode,
    stage: tpl.stage,
    deps: tpl.deps.map((d) => `${order.order}::${d}`),
    baseDuration: base,
    duration: base,
    formula: tpl.formula,
    rationale: tpl.rationale
  }
}

function buildDynamicTasks(order, keys) {
  const metrics = templateMetricsOf(order)
  const out = []
  for (const key of keys) {
    const tpl = DYNAMIC_TEMPLATES.find((t) => t.key === key)
    if (!tpl) continue
    out.push({ tpl, task: materializeTask(tpl, order, metrics, Math.max(0.5, Number(tpl.base(metrics).toFixed(2)))) })
  }
  return out
}

function assumptionsPayload() {
  return {
    modelName: '电子混线换产协同仿真模型 v4.0',
    modelType: '补充仿真模型（规则驱动，仅模拟换产任务）',
    modelVersion: MODEL_VERSION,
    baselineVersion: 'v3.0（基准记录保留，不同版本结果不直接比较）',
    dataSource: {
      real: '《赛道数据包.xlsx》：订单批次号、成品专用号、成品描述、排产数量、事业部T1交货、面、物料编码、物料描述、用量（原数据未修改）。',
      missing: [
        '设备清单与设备节拍/故障参数（真实）',
        '人员技能矩阵与实际出勤（真实）',
        '工序标准工时（换产各步骤实测耗时）',
        '产出数量、良率、稼动率等 OEE 输入数据',
        '换产完成后的正式生产时长与节拍'
      ],
      simulated: '设备类型与实例、12 名人员与班次、工序依赖、工时公式、仿真日历与扩大规模、产线在位配置锁定规则均为本项目补充假设。'
    },
    declaration: '本应用中的换产耗时、停线窗口、资源等待、评测结果等均由仿真模型与排程算法计算得出，属于仿真结果，不代表工厂实测数据。',
    boundary: {
      title: '建模边界：仅模拟换产任务，不是完整生产排程',
      statement:
        '本模型只对“换产任务链”建模（离线准备 → 在线换产 → 首件检验与放行 → 恢复生产），不对换产完成后的正式生产时长、产出与良率建模。' +
        '仿真日历中的虚拟生产间隔与批次时长仅为场景编排假设，本轮不据此宣称实际产能、交付收益或 OEE 改善。',
      comparableMetric: '可与单次换产基准比较的指标是“单次在线停线窗口”（清线与旧工装拆卸开始 → 恢复生产结束）。'
    },
    lineStateModel: {
      title: '产线状态与订单一致性约束',
      rules: [
        '任务分为可离线提前的准备任务与必须在线完成的产线任务（清线、工装切换、参数应用、首件生产、恢复生产）。',
        '后续订单的物料拣配、离线工装准备、参数方案准备可提前并行。',
        '当前订单进入在线换产后，从清线与旧工装拆卸开始到质量放行、恢复生产结束，其他订单不得覆盖产线在位工装或参数。',
        '首件生产时，产线产品、在位工装、已生效参数与对应物料必须与该订单一致。',
        '参数方案的离线准备与在线应用、校准严格区分。'
      ],
      readiness: [
        '工装切换(在线) 的前置为该订单离线工装准备与线边配送完成。',
        '首件生产 的前置为该订单参数应用与校准(在线) 完成。',
        '质量门禁：首件检验合格 → 质量放行 → 恢复生产，三段严格串行。'
      ]
    },
    equipmentModel: {
      title: '设备模型（5 类设备实际参与任务约束）',
      types: EQUIPMENT_TYPES,
      instances: EQUIPMENT,
      constraints: [
        '每个相关任务必须占用一台设备实例（容量 1），设备在同一时刻只服务一个任务。',
        '贴片机、印刷机各有一台替代设备，主设备不可用时按约束启用替代方案。',
        '设备故障窗口内不安排依赖该设备的有效加工。'
      ]
    },
    personnelModel: {
      title: '人员模型（12 名，含技能、班次与可用时间）',
      note:
        '人员效率系数为后续学习能力预留，本轮任务工时固定不随效率变化。班次窗口（白班 0-720、中班 360-1080、夜班 720-1440 分钟）会真实约束派工；' +
        '人员总数 12、当前可用人数与本次实际投入人数分别统计。',
      totalCount: DEFAULT_PERSONNEL.length,
      shiftWindows: SHIFT_WINDOWS
    },
    phases: PHASES,
    offlinePrepKeys: OFFLINE_PREP_KEYS,
    onlineKeys: ONLINE_KEYS,
    postOfflineKeys: POST_OFFLINE_KEYS,
    personnel: DEFAULT_PERSONNEL,
    efficiencyNote: '人员效率系数为后续“学习能力/技能差异”预留参数；为保证对照公平，本轮任务工时固定，不随执行人效率变化。',
    exclusive: DEFAULT_EXCLUSIVE,
    equipment: EQUIPMENT,
    equipmentTypes: EQUIPMENT_TYPES,
    taskTemplates: TASK_TEMPLATES.map((t) => ({
      key: t.key,
      name: t.name,
      phase: t.phase,
      skill: t.skill,
      skillLabel: SKILL_LABELS[t.skill],
      exclusive: t.exclusive,
      equipment: t.equipment || null,
      equipmentAlternatives: t.equipmentAlternatives || [],
      mode: t.mode,
      stage: t.stage,
      deps: t.deps,
      formula: t.formula,
      rationale: t.rationale
    })),
    dynamicTemplates: DYNAMIC_TEMPLATES.map((t) => ({ key: t.key, name: t.name, equipment: t.equipment, formula: t.formula })),
    metricDefinitions: {
      totalMakespan: {
        name: '多订单总历时',
        startEvent: '全部换产任务的最早可开始时刻（t = 0）',
        endEvent: '所有任务中最后一个任务的完成时刻',
        formula: 'max(所有任务 end) − 0',
        note: '多订单批次的整体编排耗时，不能作为单次换产时间，也不能直接与 30 分钟基准比较。'
      },
      onlineStopWindow: {
        name: '单次在线停线窗口',
        startEvent: '该订单首个在线产线作业开始时刻（清线与旧工装拆卸）',
        endEvent: '该订单恢复生产(在线)结束时刻',
        formula: '恢复生产 end − 清线与旧工装拆卸 start',
        note: '停线起点显式取“清线与旧工装拆卸”，切换前的清线/拆卸/等待均计入。只有起止口径、任务范围与基准完全一致时，才可与赛题 30 分钟比较。'
      },
      offlinePrep: {
        name: '离线准备耗时',
        startEvent: '该订单首个离线准备任务开始时刻',
        endEvent: '该订单最后一个离线准备任务结束时刻',
        formula: 'prepEnd − prepStart（跨度）；另附离线准备总工时 = Σ各离线准备任务工时',
        note: '可提前并行执行。'
      },
      recovery: {
        name: '异常恢复指标',
        startEvent: '异常事件实际触发时刻（triggerAt）',
        endEvent: '恢复计划中最后一个任务完成时刻',
        formula: '实际触发后剩余时间 = 恢复完成时刻 − triggerAt；相对原计划延期 = 恢复完成时刻 − 原计划完成时刻',
        note: 'A/B/C 对照中三组在线停线合计相同，因此“缩短”只适用于多订单总历时。'
      }
    },
    eventModel: {
      title: '异常注入与动态重排（规则决策模式）',
      supported: [
        'AGV配送延迟：选择未完成的配送任务并设置延迟分钟数，已完成配送不可再次延迟。',
        '人员临时缺席：选择人员与不可用时段，在技能约束下重分配未执行工作。',
        '设备故障：选择产线或设备，设置故障与恢复时刻；故障窗口内不安排依赖该设备的加工，主设备不可用时可启用替代设备。',
        '首件检验不合格：以指定检验任务完成时的结果触发，增加返工与复检，复检合格前不得放行或恢复生产。'
      ],
      assumptions: [
        'AGV配送延迟期间 AGV 与物料员均保持占用（保守假设）。',
        '人员缺席影响在制任务默认“完成当前作业后离岗”，不更改历史执行人。',
        '设备故障影响在制任务默认“暂停后续作”，保留故障前实际片段；主设备不可用时按约束启用替代设备。',
        '同一时刻任务完成与事件发生：完成时刻 = eventTime 的任务视为已完成，事件在其后生效。',
        '重复提交同一事件不重复追加；连续事件基于上一事件后的最新执行状态处理。'
      ]
    },
    oeeNote: {
      status: '待验证',
      reason: '缺少生产工时、产出数量与良率数据，OEE 无法计算。',
      required: ['计划生产时间', '实际产出数量', '良品数量', '设备停机记录']
    }
  }
}

module.exports = {
  MODEL_VERSION,
  SKILL_LABELS,
  SHIFT_WINDOWS,
  EQUIPMENT_TYPES,
  EQUIPMENT,
  DEFAULT_PERSONNEL,
  DEFAULT_EXCLUSIVE,
  TASK_TEMPLATES,
  DYNAMIC_TEMPLATES,
  PHASES,
  OFFLINE_PREP_KEYS,
  ONLINE_KEYS,
  POST_OFFLINE_KEYS,
  buildTaskSet,
  buildDynamicTasks,
  assumptionsPayload
}
