'use strict'

/**
 * 第三轮端到端验证：数据 / A·B·C / 独立验证 / 产线一致性 / 四类异常 / R0·R1 / 持久化
 */

const assert = require('assert')
const { importWorkbook, DEFAULT_XLSX } = require('./dataLoader')
const sim = require('./simulation')
const { buildSchedules, validateSchedule } = require('./scheduler')
const recovery = require('./recovery')
const store = require('./store')

let passed = 0
let failed = 0
function check(name, fn) {
  try {
    fn()
    passed++
    console.log(`  [PASS] ${name}`)
  } catch (err) {
    failed++
    console.log(`  [FAIL] ${name} -> ${err.message}`)
  }
}

console.log('\n=== 1. Excel 导入与数据质量核查 ===')
const { meta, orders } = importWorkbook(DEFAULT_XLSX)
check('数据行数 = 5424 / 订单 97 / 产品 88 / 物料 1276', () => assert.ok(meta.dataRows === 5424 && meta.orders === 97 && meta.products === 88 && meta.materials === 1276))
check('日期范围 = 2026-09-07，无缺失/无重复', () => assert.ok(meta.dateRange.min === '2026-09-07' && meta.duplicates.fullRows === 0 && meta.duplicates.compositeKeys === 0 && Object.values(meta.missing).every((v) => v === 0)))

console.log('\n=== 2. 排产数量聚合正确性 ===')
check('按明细求和 4,916,737 vs 按订单去重 89,050', () => assert.ok(meta.quantityAggregation.rawMaterialDetailSum === 4916737 && meta.quantityAggregation.aggregatedByOrderSum === 89050))

function planFor(ids, personnel, exclusive) {
  const selected = ids.map((id) => orders.find((o) => o.order === id))
  const built = sim.buildTaskSet(selected, { personnel, exclusive })
  const res = buildSchedules({ tasks: built.tasks, personnel: built.personnel, exclusive: built.exclusive, equipment: built.equipment, ordersInOrder: ids })
  return { ...built, ...res }
}

console.log('\n=== 3. A/B/C 三排程与指标口径 ===')
const ids3 = orders.slice(0, 3).map((o) => o.order)
const p3 = planFor(ids3)
console.log(`    实测：A=${p3.A.metrics.makespan}，B=${p3.B.metrics.makespan}，C=${p3.C.metrics.makespan} 分钟；在线停线合计=${p3.C.metrics.onlineStopTotal}`)
check('A/B/C 均可行', () => assert.ok(['A', 'B', 'C'].every((m) => validateSchedule(p3[m].entries, p3.tasks, p3.personnel, {}).ok)))
check('每订单含 11 类工序，三订单 33 项', () => assert.ok(p3.A.entries.length === 33 && p3.C.metrics.orderMetrics.length === 3))
check('停线起点为“清线与旧工装拆卸(在线)”', () => assert.ok(p3.C.metrics.orderMetrics.every((m) => m.stopStartEvent.includes('清线'))))
check('三组在线停线合计相同（不支持“停线时间缩短”）', () => assert.ok(Math.abs(p3.A.metrics.onlineStopTotal - p3.B.metrics.onlineStopTotal) < 1e-6 && Math.abs(p3.B.metrics.onlineStopTotal - p3.C.metrics.onlineStopTotal) < 1e-6))
check('B <= A（提前准备收益）且 C <= B（调度算法收益）', () => assert.ok(p3.B.metrics.makespan <= p3.A.metrics.makespan + 1e-6 && p3.C.metrics.makespan <= p3.B.metrics.makespan + 1e-6))
const p1 = planFor([orders[0].order])
check('单订单：A/B/C 三套排程均可行且含 11 类工序', () => assert.ok(['A', 'B', 'C'].every((m) => validateSchedule(p1[m].entries, p1.tasks, p1.personnel, {}).ok && p1[m].entries.length === 11)))
const reduced = sim.DEFAULT_PERSONNEL.filter((p) => ['MAT-01', 'EQP-01', 'TLG-01', 'QC-01', 'OPR-01'].includes(p.id))
const pShort = planFor(ids3, reduced)
check('人员不足（仅 1 名设备工程师）时 A/B/C 仍可行', () => assert.ok(['A', 'B', 'C'].every((m) => validateSchedule(pShort[m].entries, pShort.tasks, reduced, {}).ok)))
check('A/B/C 使用了相同订单、任务耗时、人员与资源', () => assert.ok(p3.A.entries.length === p3.B.entries.length && p3.B.entries.length === p3.C.entries.length))

console.log('\n=== 4. 产线状态一致性回归（人为构造非法顺序） ===')
function personFor(key, oi) {
  if (key === 'material_pick' || key === 'material_deliver') return oi === 0 ? ['MAT-01', '物料员 张伟'] : ['MAT-02', '物料员 李娜']
  if (key === 'tooling_prep') return ['TLG-01', '工装工程师 陈涛']
  if (key === 'param_prepare') return ['EQP-02', '设备工程师 赵敏']
  if (key === 'line_clear') return ['OPR-01', '操作工 周杰']
  if (key === 'tooling_switch' || key === 'param_apply') return ['EQP-01', '设备工程师 王强']
  if (key === 'fai_produce' || key === 'resume') return ['OPR-01', '操作工 周杰']
  return ['QC-01', '质检员 刘洋']
}
function mk(order, key, start, dur, oi) {
  const tpl = sim.TASK_TEMPLATES.find((t) => t.key === key)
  const [pid, pname] = personFor(key, oi)
  return { id: `${order}::${key}`, key, name: tpl.name, phase: tpl.phase, order, product: 'x', skill: tpl.skill, skillLabel: sim.SKILL_LABELS[tpl.skill], exclusive: tpl.exclusive, mode: tpl.mode, stage: tpl.stage, deps: tpl.deps.map((d) => `${order}::${d}`), duration: dur, assigneeId: pid, assigneeName: pname, start, end: start + dur }
}
function syntheticInterleaved(A, B) {
  const e = []
  e.push(mk(A, 'material_pick', 0, 0.05, 0)); e.push(mk(A, 'material_deliver', 0.05, 0.05, 0))
  e.push(mk(A, 'tooling_prep', 0, 0.1, 0)); e.push(mk(A, 'param_prepare', 0, 0.1, 0))
  e.push(mk(B, 'material_pick', 0, 0.05, 1)); e.push(mk(B, 'material_deliver', 0.1, 0.05, 1))
  e.push(mk(B, 'tooling_prep', 0.1, 0.1, 1)); e.push(mk(B, 'param_prepare', 0.2, 0.1, 1))
  e.push(mk(A, 'line_clear', 0.2, 0.5, 0)); e.push(mk(A, 'tooling_switch', 0.7, 2, 0))
  e.push(mk(B, 'line_clear', 2.7, 0.5, 1)); e.push(mk(B, 'tooling_switch', 3.2, 1, 1)); e.push(mk(B, 'param_apply', 4.2, 1, 1))
  e.push(mk(A, 'param_apply', 5.2, 1, 0)); e.push(mk(A, 'fai_produce', 6.2, 2, 0))
  e.push(mk(A, 'fai_inspect', 8.2, 1, 0)); e.push(mk(A, 'quality_release', 9.2, 1, 0)); e.push(mk(A, 'resume', 10.2, 1, 0))
  e.push(mk(B, 'fai_produce', 11.2, 1, 1)); e.push(mk(B, 'fai_inspect', 12.2, 1, 1)); e.push(mk(B, 'quality_release', 13.2, 1, 1)); e.push(mk(B, 'resume', 14.2, 1, 1))
  return e
}
const badTasks = sim.buildTaskSet([orders[0], orders[1]]).tasks
const badResult = validateSchedule(syntheticInterleaved(orders[0].order, orders[1].order), badTasks, sim.DEFAULT_PERSONNEL, {})
check('非法“A清线→B换工装→A首件生产”被拒绝', () => assert.strictEqual(badResult.ok, false))
check('拒绝命中产线窗口交叠与首件一致性', () => assert.ok(badResult.violations.some((v) => v.type === 'line_lock') && badResult.violations.some((v) => v.type === 'line_consistency')))
check('合法 A/B/C 排程不被误判', () => assert.ok(['A', 'B', 'C'].every((m) => validateSchedule(p3[m].entries, p3.tasks, p3.personnel, {}).ok)))

console.log('\n=== 5. 四类异常（可重复案例） ===')
function fresh() {
  return recovery.createSession({ orders: orders.slice(0, 3) })
}
function deliverAt(s, order) {
  return s.actualEntries.filter((e) => e.key === 'material_deliver' && (!order || e.order === order)).sort((a, b) => a.start - b.start)[0]
}
// AGV
let sAgv = fresh()
const dAgv = deliverAt(sAgv)
const agvRes = recovery.applyEvent(sAgv, { type: 'agv_delay', target: dAgv.id, at: Math.max(0, dAgv.start), duration: 15 })
check('AGV配送延迟：注入成功且 R1 验证通过', () => assert.ok(agvRes.result.applied && agvRes.result.eventRecord.R1.validation.ok))
check('AGV配送延迟：R1 不劣于 R0（R0 作为候选）', () => assert.ok(agvRes.result.eventRecord.R1.metrics.makespan <= agvRes.result.eventRecord.R0.metrics.makespan + 1e-6))
check('AGV配送延迟：R0 独立验证通过且 R0/R1 共享同一快照编号', () => {
  const ev = agvRes.result.eventRecord
  assert.ok(ev.R0.validation.ok)
  assert.ok(ev.sharedSnapshotId && ev.R0.entries.length > 0 && ev.R1.entries.length > 0)
})
check('AGV配送延迟：已完成配送不可再次延迟', () => {
  const r = recovery.applyEvent(sAgv, { type: 'agv_delay', target: dAgv.id, at: 999, duration: 5 })
  assert.strictEqual(r.result.applied, false)
})

// 人员缺席
let sPer = fresh()
const perRes = recovery.applyEvent(sPer, { type: 'person_absence', target: 'EQP-01', at: 12, duration: 10, policy: 'finish_current' })
check('人员临时缺席：注入成功且 R1 验证通过', () => assert.ok(perRes.result.applied && perRes.result.eventRecord.R1.validation.ok))
check('人员缺席：受影响任务重分配且历史执行人不变', () => assert.ok(perRes.result.eventRecord.R1.metrics.adjustments >= 0))

// 设备故障
let sEq = fresh()
const eqRes = recovery.applyEvent(sEq, { type: 'equipment_failure', target: 'LINE-01', at: 30, duration: 10 })
check('设备故障：注入成功且 R1 验证通过', () => assert.ok(eqRes.result.applied && eqRes.result.eventRecord.R1.validation.ok))
check('设备故障：故障窗口内无依赖产线的加工', () => {
  const ev = eqRes.result.eventRecord
  const bad = ev.R1.entries.filter((e) => e.exclusive === 'LINE-01' && e.start < 40 - 1e-6 && e.end > 30 + 1e-6)
  assert.strictEqual(bad.length, 0)
})

// 首件不合格
let sFai = fresh()
const baseInspEnd = sFai.actualEntries.find((e) => e.id === `${ids3[0]}::fai_inspect`).end
const faiRes = recovery.applyEvent(sFai, { type: 'fai_fail', target: ids3[0], at: 0 })
check('首件不合格：注入成功且 R1 验证通过', () => assert.ok(faiRes.result.applied && faiRes.result.eventRecord.R1.validation.ok))
check('首件不合格：实际触发时刻 = 该订单首件检验完成时刻（晚于预约时刻）', () => {
  const ev = faiRes.result.eventRecord
  assert.ok(Math.abs(ev.triggerAt - baseInspEnd) < 1e-6, `触发 ${ev.triggerAt} != 检验完成 ${baseInspEnd}`)
  assert.strictEqual(ev.reserveAt, 0)
  assert.ok(ev.triggerAt > ev.reserveAt, '触发应晚于预约')
  assert.ok(Math.abs(ev.snapshotAt - ev.triggerAt) < 1e-6, '快照时刻应等于实际触发时刻')
})
check('首件不合格：实际触发前不安排返工（不提前利用未知失败）', () => {
  const ev = faiRes.result.eventRecord
  const rework = ev.R1.entries.find((e) => e.key === 'rework')
  assert.ok(rework.start >= ev.triggerAt - 1e-6, `返工 ${rework.start} 早于触发 ${ev.triggerAt}`)
})
check('首件不合格：实际触发后剩余时间 = 完成 − 触发', () => {
  const ev = faiRes.result.eventRecord
  assert.ok(Math.abs(ev.R1.metrics.remainingAfterTrigger - (ev.R1.metrics.makespan - ev.triggerAt)) < 1e-6)
  assert.ok(ev.R1.metrics.waitReserveToTrigger > 0, '预约到触发应有等待（预约早于触发）')
})
check('首件不合格：生成返工与复检，复检合格前不放行恢复', () => {
  const ev = faiRes.result.eventRecord
  const rework = ev.R1.entries.find((e) => e.key === 'rework')
  const recheck = ev.R1.entries.find((e) => e.key === 'recheck')
  const release = ev.R1.entries.find((e) => e.key === 'quality_release' && e.order === ids3[0])
  const resume = ev.R1.entries.find((e) => e.key === 'resume' && e.order === ids3[0])
  assert.ok(rework && recheck, '缺少返工或复检')
  assert.ok(release.start >= recheck.end - 1e-6, '放行早于复检')
  assert.ok(resume.start >= release.end - 1e-6, '恢复早于放行')
})
check('首件不合格：已放行订单返回不适用原因', () => {
  const s = fresh()
  const late = recovery.applyEvent(s, { type: 'fai_fail', target: ids3[0], at: 999 })
  assert.strictEqual(late.result.applied, false)
  assert.ok(String(late.result.reason).includes('不适用'))
})

console.log('\n=== 6. 恢复规则与边界 ===')
check('同一事件重复提交不重复追加', () => {
  const s = fresh()
  const d = deliverAt(s)
  const a = recovery.applyEvent(s, { type: 'agv_delay', target: d.id, at: Math.max(0, d.start), duration: 15 })
  const b = recovery.applyEvent(a.bundle, { type: 'agv_delay', target: d.id, at: Math.max(0, d.start), duration: 15 })
  assert.ok(a.result.applied && b.result.duplicate === true && b.bundle.events.length === 1)
})
check('连续两次事件基于最新状态且均验证通过', () => {
  const s = fresh()
  const d = deliverAt(s)
  const a = recovery.applyEvent(s, { type: 'agv_delay', target: d.id, at: Math.max(0, d.start), duration: 15 })
  const b = recovery.applyEvent(a.bundle, { type: 'person_absence', target: 'QC-01', at: 20, duration: 8 })
  assert.ok(b.result.applied && b.bundle.events.length === 2 && b.result.eventRecord.R1.validation.ok)
})
check('已完成历史不变、未开始任务不穿越事件时刻', () => {
  const ev = eqRes.result.eventRecord
  const notBefore = ev.R1.entries.every((e) => e.start >= 30 - 1e-6)
  const history = ev.R1.validation.checks.find((c) => c.name.includes('历史'))
  assert.ok(notBefore && history.status === 'pass')
})
check('故障影响在制任务时保留片段且有效加工时长正确', () => {
  const s = fresh()
  // 选一个在 10 分钟时在制的在线任务
  const running = s.actualEntries.filter((e) => e.start < 10 && e.end > 10 && e.stage === 'line')[0]
  if (!running) return // 若该时刻无在制在线任务则跳过
  const r = recovery.applyEvent(s, { type: 'equipment_failure', target: 'LINE-01', at: 10, duration: 8 })
  const ev = r.result.eventRecord
  const frag = ev.frozen.find((f) => f.kind === 'actual-fragment' && f.id.startsWith(running.id))
  assert.ok(frag && frag.segEnd - frag.segStart > 0, '未保留有效加工片段')
})
check('缺少必需技能时明确报告不可行', () => {
  const s = fresh()
  const r = recovery.applyEvent(s, { type: 'person_absence', targets: ['TLG-01', 'TLG-02'], at: 0, to: 5000 })
  assert.strictEqual(r.result.applied, false)
  assert.ok(String(r.result.reason).includes('不可用') || String(r.result.reason).includes('合格人员'))
})
check('R0/R1 共享同一执行快照与异常条件', () => {
  const ev = agvRes.result.eventRecord
  assert.ok(ev.R0.entries.length > 0 && ev.R1.entries.length > 0)
  assert.ok(ev.R0.metrics.completedByEvent === ev.R1.metrics.completedByEvent)
  assert.ok(ev.frozen.length === ev.frozen.length)
})
check('产线一致性（在线锁定）始终成立', () => {
  const ev = eqRes.result.eventRecord
  const ok = ev.R1.validation.checks.find((c) => c.name.includes('资源'))?.status === 'pass'
  assert.ok(ok)
})

console.log('\n=== 7. 持久化 ===')
store.writeJSON('verify_tmp.json', { ok: true, at: Date.now() })
check('仿真会话可写入本地存储并读取', () => assert.strictEqual(store.readJSON('verify_tmp.json').ok, true))

console.log('\n=== 8. 仿真数据层规模与事件正确性（第四轮） ===')
const simData = require('./simData').buildSimulationData({ orders })
const st = simData.stats
console.log(`    实测规模：日历 ${st.calendarDays} 天（事件跨度 ${st.eventSpanDays} 天），事件 ${st.eventTotal} 次（计划 ${st.eventPlanned}/已完成 ${st.eventCompleted}/异常 ${st.eventAbnormal}），有效换产 ${st.validChangeovers} 次，产品 ${st.distinctProducts} 种，物料 ${st.distinctMaterials} 种，人员名册 ${st.personnelRoster}（可用 ${st.personnelAvailableAtZero}/实际 ${st.personnelActuallyUsed}），设备库存 ${st.equipmentInventoryCount}/实际使用 ${st.equipmentActuallyUsed}，设备类型 ${st.equipmentTypeCount} 类`)
check('仿真日历 36 天且事件实际跨度 ≥30 天', () => assert.ok(st.calendarDays >= 36 && st.eventSpanDays >= 30))
check('换产事件 ≥72 次', () => assert.ok(st.eventTotal >= 72))
check('有效换产（已完成且通过验证）≥50 次', () => assert.ok(st.validChangeovers >= 50))
check('产品 ≥24 种、物料 ≥50 种（来源原 BOM）', () => assert.ok(st.distinctProducts >= 24 && st.distinctMaterials >= 50))
check('人员 ≥10 名、设备类型 ≥5 类', () => assert.ok(st.personnelRoster >= 10 && st.equipmentTypeCount >= 5))
check('来源产品与目标产品均不相同（同产品续批不计换产）', () => assert.ok(simData.events.every((e) => e.fromProduct !== e.toProduct)))
check('每个事件记录停线开始与恢复生产时间', () => assert.ok(simData.events.every((e) => e.stopStart != null && e.resumeTime != null && e.stopStartEvent)))
check('计划/已完成/异常事件分别统计且合计等于事件总数', () => assert.strictEqual(st.eventPlanned + st.eventCompleted + st.eventAbnormal, st.eventTotal))
check('eventId 唯一（重复运行同一事件不增加独立事件数）', () => assert.strictEqual(st.distinctEventCount, st.eventTotal))
check('场景初始产品 = 首个事件来源产品（状态衔接）', () => assert.ok(simData.scenarios.every((sc) => sc.initialProduct === sc.events[0].fromProduct)))
check('场景内事件产品状态连续（前一目标=后一来源）', () =>
  assert.ok(
    simData.scenarios.every((sc) => sc.events.every((e, i) => (i === 0 ? e.fromProduct === sc.initialProduct : e.fromProduct === sc.events[i - 1].toProduct)))
  ))
check('无重复排程窗口、无时间顺序冲突', () => {
  let dup = 0
  let chrono = 0
  for (const sc of simData.scenarios) {
    for (let i = 0; i < sc.events.length; i++) {
      const a = sc.events[i]
      if (i && a.stopStart < sc.events[i - 1].resumeTime - 1e-6) chrono++
      for (const b of sc.events.slice(i + 1)) if (a.stopStart === b.stopStart && a.resumeTime === b.resumeTime) dup++
    }
  }
  assert.ok(dup === 0 && chrono === 0, `dup=${dup} chrono=${chrono}`)
})
check('异常记录实际进入恢复引擎（含触发时刻与 R0/R1）', () => {
  const ab = simData.events.filter((e) => e.execStatus === '异常')
  assert.ok(ab.length >= 1 && ab.every((e) => e.anomaly && e.anomaly.triggerAt != null && e.anomaly.r0Makespan != null && e.anomaly.r1Makespan != null))
})
check('四类异常均出现在统一轨迹中（含首件失败返工复检）', () => {
  const types = new Set(simData.events.filter((e) => e.abnormal).map((e) => e.abnormal))
  assert.ok(types.has('agv_delay') && types.has('person_absence') && types.has('equipment_failure') && types.has('fai_fail'), [...types].join(','))
  const fai = simData.events.filter((e) => e.abnormal === 'fai_fail')
  assert.ok(fai.some((e) => e.taskInstances.some((t) => t.key === 'rework') && e.taskInstances.some((t) => t.key === 'recheck')))
})
check('产品/物料目录与实际事件引用闭合（无未解析引用）', () => {
  assert.strictEqual(st.referenceIntegrity.unresolvedReferences, 0)
  assert.strictEqual(st.referenceIntegrity.productsInCatalog, st.referenceIntegrity.productsReferenced)
  assert.strictEqual(st.distinctProducts, st.referenceIntegrity.productsReferenced)
})
check('validated 来自整场景轨迹独立验证', () => {
  const exec = simData.events.filter((e) => e.execStatus !== '计划')
  assert.ok(exec.every((e) => typeof e.validated === 'boolean'))
  assert.strictEqual(st.validChangeovers, exec.filter((e) => e.validated).length)
})
check('原始 Excel 事实未修改（行/订单/产品/物料/交期）', () => assert.ok(st.sourceDataUnchanged.rows === 5424 && st.sourceDataUnchanged.products === 88 && st.sourceDataUnchanged.materials === 1276 && st.sourceDataUnchanged.deliveryDate === '2026-09-07'))

console.log('\n=== 9. 设备、班次与库存真实参与排程（第四轮） ===')
const p4 = planFor(ids3)
check('5 类设备各被任务模板引用（含返工复检使用 ICT）', () => {
  const types = require('./simulation').EQUIPMENT_TYPES.map((t) => t.type)
  assert.strictEqual(types.length, 5)
  const tplEquip = new Set()
  for (const t of require('./simulation').TASK_TEMPLATES) {
    if (t.equipment) tplEquip.add(require('./simulation').EQUIPMENT.find((x) => x.id === t.equipment).type)
  }
  for (const t of require('./simulation').DYNAMIC_TEMPLATES) {
    if (t.equipment) tplEquip.add(require('./simulation').EQUIPMENT.find((x) => x.id === t.equipment).type)
  }
  assert.strictEqual(tplEquip.size, 5, `模板覆盖设备类型 ${tplEquip.size}`)
})
check('静态排程实际占用 ≥4 类设备且含替代设备', () => {
  const usedTypes = new Set(p4.C.entries.filter((e) => e.equipment).map((e) => require('./simulation').EQUIPMENT.find((x) => x.id === e.equipment).type))
  assert.ok(usedTypes.size >= 4)
  const usedIds = new Set(p4.C.entries.filter((e) => e.equipment).map((e) => e.equipment))
  assert.ok(usedIds.size >= 1)
})
check('设备在同刻不重叠（验证器含设备与替代资格）', () => assert.ok(validateSchedule(p4.C.entries, p4.tasks, p4.personnel, { equipment: p4.equipment }).ok))
check('人员名册/当前可用/实际投入三数分别统计', () => {
  const roster = sim.DEFAULT_PERSONNEL.length
  const avail0 = sim.DEFAULT_PERSONNEL.filter((p) => p.shiftWindow[0] <= 0).length
  const used = p4.C.metrics.utilization.filter((u) => u.busy > 0).length
  assert.ok(roster === 12 && avail0 < roster && used <= avail0 && used > 0)
})

console.log('\n=== 10. 批量评测（第四轮） ===')
const evalMod = require('./evaluation')
// 真实求解入口统一记账：回归也记录实际使用的指纹（幂等，纯筛选不记录）
const USAGE_TMP = 'eval-usage.json'
evalMod.setUsageSink((rec) => {
  const u = store.readJSON(USAGE_TMP, { fingerprints: [], runs: [], history: [] })
  const fps = new Set(u.fingerprints || [])
  for (const f of rec.fingerprints || []) fps.add(f)
  u.fingerprints = Array.from(fps)
  u.runs = (u.runs || []).concat([{ runId: rec.runId, at: rec.at, effectiveSets: rec.effectiveSets, reservedRun: rec.reservedRun }])
  store.writeJSON(USAGE_TMP, u)
})
const catalog = evalMod.buildCaseCatalog(orders)
check('评测案例数 ≥60', () => assert.ok(catalog.length >= 60))
check('覆盖单订单与 3/5/10 订单、资源紧张、四类异常、连续、边界、不可行', () => {
  const cats = new Set(catalog.map((c) => c.category))
  const need = ['静态-单订单', '静态-3订单', '静态-5订单', '静态-10订单', '静态-资源紧张', '异常-agv_delay', '异常-person_absence', '异常-equipment_failure', '异常-fai_fail', '异常-连续', '异常-边界时刻', '不可行']
  assert.ok(need.every((n) => cats.has(n)), '缺少类别: ' + need.filter((n) => !cats.has(n)).join(','))
})
check('按 dev/validation/frozen/reserved 分集且同基线变体同集', () => {
  const sets = new Set(catalog.map((c) => c.set))
  assert.ok(sets.has('dev') && sets.has('validation') && sets.has('frozen') && sets.has('reserved'))
  const byGroup = new Map()
  for (const c of catalog) {
    if (!byGroup.has(c.group)) byGroup.set(c.group, new Set())
    byGroup.get(c.group).add(c.set)
  }
  assert.ok([...byGroup.values()].every((s) => s.size === 1), '同一基线组被分到多个集合')
})
const evalReport = evalMod.runEvaluation({ orders, simData, seed: 777, sets: ['dev', 'validation', 'frozen'] })
check('种子从入口贯穿（claimedSeed = 案例实际 seed）', () => {
  assert.strictEqual(evalReport.seed, 777)
  assert.ok(evalReport.cases.every((c) => c.input.seed === 777))
})
check('计数分列：案例数/换产实例数/唯一基线数/异常注入数', () => {
  assert.ok(evalReport.caseCount > 0)
  assert.ok(evalReport.changeoverInstanceCount >= evalReport.caseCount)
  assert.ok(evalReport.uniqueBaselineCount > 0 && evalReport.uniqueBaselineCount <= evalReport.caseCount)
  assert.ok(evalReport.anomalyInjectionCount >= 0)
  assert.notStrictEqual(evalReport.changeoverInstanceCount, simData.stats.eventTotal)
})
check('缺省/空集合只运行 dev+validation，非法集合被明确记录', () => {
  const d = evalMod.runEvaluation({ orders, simData })
  assert.deepStrictEqual(d.effectiveSets, ['dev', 'validation'])
  assert.ok(!d.effectiveSets.includes('reserved'))
  const e = evalMod.runEvaluation({ orders, simData, sets: [] })
  assert.deepStrictEqual(e.effectiveSets, ['dev', 'validation'])
  const u = evalMod.runEvaluation({ orders, simData, sets: ['nope'] })
  assert.ok(u.unknownSets.includes('nope') && u.effectiveSets.length === 2)
})
check('保留清单固定：不同求解 seed 分集一致', () => {
  const a = evalMod.buildCaseCatalog(orders)
  const b = evalMod.buildCaseCatalog(orders)
  assert.deepStrictEqual(a.map((c) => c.set), b.map((c) => c.set))
})
check('保留集受历史使用指纹保护（纯筛选，不进入求解器）', () => {
  const cat = evalMod.buildCaseCatalog(orders)
  const reserved = cat.filter((c) => c.set === 'reserved')
  if (!reserved.length) return
  const usage = { fingerprints: reserved.map((c) => c.fingerprint) }
  const sel = evalMod.selectCases(cat, { sets: ['reserved'], usage })
  assert.strictEqual(sel.selected.length, 0, '全部已使用的保留案例应被排除')
  assert.strictEqual(sel.excludedReserved.length, reserved.length)
})
check('分类汇总/指标/改善齐备且加权与逐案例分别标注', () => {
  assert.ok(evalReport.summary.byCategory.length > 0)
  assert.ok(evalReport.summary.metricBlock.makespan.C.n > 0)
  assert.ok(evalReport.summary.improvement.AtoC.weightedPct != null && evalReport.summary.improvement.AtoC.perCaseMeanPct != null)
})
check('失败/不可行案例保留且记录原因', () => {
  const bad = evalReport.cases.filter((c) => c.result.status === 'infeasible' || c.result.status === 'error' || c.result.status === 'partial' || c.result.status === 'not_applicable')
  assert.ok(bad.length >= 1 && bad.every((c) => c.result.reason || c.result.failureReason))
})
check('异常案例逐事件记录成功/失败原因并共享快照', () => {
  const a = evalReport.cases.filter((c) => c.kind === 'anomaly' || c.kind === 'anomaly-consecutive' || c.kind === 'anomaly-boundary')
  assert.ok(a.length >= 1 && a.every((c) => Array.isArray(c.result.events)))
  const ok = a.filter((c) => c.result.status === 'ok')
  assert.ok(ok.length >= 1 && ok.every((c) => c.result.shareSnapshot))
})
check('在线停线取舍如实展示（不宣称全部相同/缩短）', () => assert.ok(evalReport.summary.onlineStopComparison && evalReport.summary.onlineStopComparison.note))

console.log('\n=== 11. 独立验收反例回归（修复前失败 → 修复后通过） ===')
const recovery2 = require('./recovery')
const auditFresh = () => recovery2.createSession({ orders: orders.slice(0, 3) })
check('累计故障：连续第二个事件不丢失第一个故障窗口', () => {
  const s = auditFresh()
  const a = recovery2.applyEvent(s, { type: 'equipment_failure', target: 'LINE-01', at: 1, duration: 100 })
  const b = recovery2.applyEvent(a.bundle, { type: 'equipment_failure', target: 'CAL-01', at: 2, duration: 1 })
  assert.ok(b.result.applied && b.result.eventRecord.R0.validation.ok && b.result.eventRecord.R1.validation.ok)
  const inside = b.bundle.actualEntries.filter((e) => e.exclusive === 'LINE-01' && e.start < 101 && e.end > 1)
  assert.strictEqual(inside.length, 0, '产线故障窗口内仍有加工')
  assert.ok((b.bundle.ledger.lineBlocks || []).some((x) => x[0] === 1 && x[1] === 101))
})
check('班次耗尽：无合法时段时报告不可行（不排到 1e7）', () => {
  const s = auditFresh()
  const r = recovery2.applyEvent(s, { type: 'person_absence', targets: ['MAT-01', 'MAT-02'], at: 0, to: 721 })
  assert.strictEqual(r.result.applied, false)
  assert.ok(r.result.infeasible && /可用时段|不可行/.test(r.result.reason))
})
check('空设备库存：不派设备且验证不通过', () => {
  const s = recovery2.createSession({ orders: orders.slice(0, 1), equipment: [] })
  assert.strictEqual(s.equipment.length, 0)
  assert.strictEqual(s.actualEntries.filter((e) => e.equipment).length, 0)
  assert.strictEqual(validateSchedule(s.actualEntries, s.tasks, s.personnel).ok, false)
})
check('首件失败不可变：不修改输入会话且执行结果记为 fail', () => {
  const s = auditFresh()
  const before = JSON.stringify(s)
  const order = s.orderIds[0]
  const r = recovery2.applyEvent(s, { type: 'fai_fail', target: order, at: 0 })
  assert.ok(r.result.applied)
  assert.strictEqual(JSON.stringify(s), before, '输入会话被修改')
  assert.strictEqual(r.bundle.actualEntries.find((e) => e.id === `${order}::fai_inspect`).result, 'fail')
  assert.ok(/事件前快照/.test(r.result.eventRecord.snapshot.relation))
})
check('迟到事件拒绝且不回拨时钟', () => {
  const s = auditFresh()
  const a = recovery2.applyEvent(s, { type: 'equipment_failure', target: 'LINE-01', at: 20, duration: 5 })
  const late = recovery2.applyEvent(a.bundle, { type: 'equipment_failure', target: 'CAL-01', at: 2, duration: 1 })
  assert.strictEqual(late.result.applied, false)
  assert.ok(late.result.late && /回退|迟到/.test(late.result.reason))
})
check('R0/R1 候选准入：仅通过独立验证才采用', () => {
  const s = auditFresh()
  const r = recovery2.applyEvent(s, { type: 'equipment_failure', target: 'MNT-01', at: 8, duration: 8 })
  assert.ok(r.result.applied)
  assert.ok(r.result.eventRecord.R0.validation.ok && r.result.eventRecord.R1.validation.ok)
  assert.ok(typeof r.result.eventRecord.chosenFromR0 === 'boolean')
})
check('静态与恢复验证器覆盖技能/班次/设备库存/累计故障/门禁', () => {
  const v = validateSchedule(p4.C.entries, p4.tasks, p4.personnel, { equipment: p4.equipment })
  const names = v.checks.map((c) => c.name).join('|')
  assert.ok(/班次/.test(names) && /设备库存/.test(names))
  const s = auditFresh()
  const r = recovery2.applyEvent(s, { type: 'equipment_failure', target: 'MNT-01', at: 8, duration: 8 })
  const rnames = r.result.eventRecord.R1.validation.checks.map((c) => c.name).join('|')
  assert.ok(/累计故障/.test(rnames) && /质量门禁|门禁/.test(rnames) && /班次/.test(rnames))
})

console.log(`\n=== 验证汇总：通过 ${passed} 项，失败 ${failed} 项 ===\n`)
if (failed > 0) process.exit(1)
