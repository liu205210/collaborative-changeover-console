'use strict'

/**
 * 离线准备任务优先级特征与可解释参数（第五阶段 · 策略自优化实验室）
 * -------------------------------------------------------------------------
 * 本模块只把“当前任务图中已知的静态特征”组合成优先级索引，不使用任何未来异常信息。
 * 优先级方向：score 越小越先排程（确定性并列按 task.id 字典序）。
 * 特征均在同一案例的离线准备任务集合内做 min-max 归一化（max=min 时取 0）。
 *
 * 特征定义（仅基于任务图与资源）：
 *   f_order    : 任务所属订单在候选上线顺序中的位置（0 起）/（订单数-1）
 *   f_template : 工序在模板顺序 TPL_ORDER 中的位置 /（模板数-1）
 *   f_duration : 任务时长 / 本案例最大离线准备时长
 *   f_critical : 任务“自身时长 + 后继最长剩余时长”/ 本案例最大值（关键路径贡献）
 *   f_tension  : 任务在同技能离线准备任务与同独占资源离线准备任务中的拥挤度，
 *                定义为 (同技能数 + 同独占资源数) / 本案例最大值（资源紧张程度）
 *
 * 权重含义：正权重 = 特征越大越靠后；负权重 = 特征越大越靠前。
 */

const FEATURE_VERSION = 'feat-v1'
const PARAM_VERSION = 'param-v1'

const TPL_ORDER = ['material_pick', 'material_deliver', 'tooling_prep', 'param_prepare', 'line_clear', 'tooling_switch', 'param_apply', 'fai_produce', 'fai_inspect', 'quality_release', 'resume']

// 至多 9 组可解释参数组合（含义见 meaning 字段）
const CANDIDATE_PARAMS = [
  {
    id: 'P1-order-template',
    name: '订单+模板顺序',
    meaning: '先按给定订单上线顺序，同订单再按工序模板顺序（等价于原 templateRank 的可解释形式）。',
    weights: { order: 1.0, template: 0.01 }
  },
  {
    id: 'P2-critical-first',
    name: '关键路径优先',
    meaning: '离线准备剩余关键路径越长越先排，优先打通长尾依赖链。',
    weights: { critical: -1.0, order: 0.001 }
  },
  {
    id: 'P3-longest-first',
    name: '长任务优先',
    meaning: '离线准备时长越长越先排，尽早启动耗时准备。',
    weights: { duration: -1.0, order: 0.001 }
  },
  {
    id: 'P4-shortest-first',
    name: '短任务优先',
    meaning: '离线准备时长越短越先排，尽快释放依赖给后续工序。',
    weights: { duration: 1.0, order: 0.001 }
  },
  {
    id: 'P5-tension-first',
    name: '资源紧张优先',
    meaning: '同技能/同独占资源拥挤度越高越先排，优先疏散争用瓶颈。',
    weights: { tension: -1.0, order: 0.001 }
  },
  {
    id: 'P6-order-critical',
    name: '订单+关键路径折中',
    meaning: '订单顺序权重 0.5 与关键路径（越长为先）0.5 折中。',
    weights: { order: 0.5, critical: -0.5 }
  },
  {
    id: 'P7-order-tension',
    name: '订单+资源紧张折中',
    meaning: '订单顺序权重 0.5 与资源紧张（越高为先）0.5 折中。',
    weights: { order: 0.5, tension: -0.5 }
  },
  {
    id: 'P8-balance-a',
    name: '综合A',
    meaning: '订单顺序 0.6、模板顺序 0.1、关键路径 -0.5、时长 -0.2 的加权组合。',
    weights: { order: 0.6, template: 0.1, critical: -0.5, duration: -0.2 }
  },
  {
    id: 'P9-balance-b',
    name: '综合B',
    meaning: '订单顺序 0.3、关键路径 -0.6、时长 -0.4、资源紧张 -0.3 的加权组合。',
    weights: { order: 0.3, critical: -0.6, duration: -0.4, tension: -0.3 }
  }
]

function candidateById(id) {
  return CANDIDATE_PARAMS.find((p) => p.id === id) || null
}

function minMax(values) {
  let min = Infinity
  let max = -Infinity
  for (const v of values) {
    if (v < min) min = v
    if (v > max) max = v
  }
  return { min, max }
}

// 计算某案例全部离线准备任务的特征矩阵（未归一化）
function computeRawFeatures(tasks, orderSequence) {
  const orderIndex = new Map(orderSequence.map((o, i) => [o, i]))
  const tplIndex = new Map(TPL_ORDER.map((k, i) => [k, i]))
  const prep = tasks.filter((t) => t.stage === 'prep')

  // 后续最长剩余时长（跨全部任务，含在线任务）
  const succ = new Map()
  for (const t of tasks) succ.set(t.id, [])
  for (const t of tasks) for (const d of t.deps) if (succ.has(d)) succ.get(d).push(t.id)
  const memo = new Map()
  const depth = (id) => {
    if (memo.has(id)) return memo.get(id)
    const t = tasks.find((x) => x.id === id)
    if (!t) return 0
    let m = 0
    for (const s of succ.get(id) || []) m = Math.max(m, depth(s))
    const v = t.duration + m
    memo.set(id, v)
    return v
  }

  const skillCount = new Map()
  const exCount = new Map()
  for (const t of prep) {
    skillCount.set(t.skill, (skillCount.get(t.skill) || 0) + 1)
    const ex = t.exclusive || null
    if (ex) exCount.set(ex, (exCount.get(ex) || 0) + 1)
  }

  const rows = prep.map((t) => {
    const ex = t.exclusive || null
    return {
      task: t,
      order: orderIndex.get(t.order) ?? 0,
      template: tplIndex.get(t.key) ?? 0,
      duration: t.duration,
      critical: depth(t.id),
      tension: (skillCount.get(t.skill) || 1) + (ex ? exCount.get(ex) || 1 : 0)
    }
  })
  return { rows, orderSize: Math.max(1, orderSequence.length - 1), templateSize: TPL_ORDER.length - 1 }
}

// 构造绑定到具体案例与候选订单顺序的优先级函数
function makePrepPriority(weights, orderSequence, tasks) {
  const { rows, orderSize, templateSize } = computeRawFeatures(tasks, orderSequence)
  const durMM = minMax(rows.map((r) => r.duration))
  const critMM = minMax(rows.map((r) => r.critical))
  const tensMM = minMax(rows.map((r) => r.tension))
  const norm = (v, mm) => (mm.max - mm.min > 1e-9 ? (v - mm.min) / (mm.max - mm.min) : 0)
  const score = new Map()
  for (const r of rows) {
    const f = {
      order: orderSize ? r.order / orderSize : 0,
      template: templateSize ? r.template / templateSize : 0,
      duration: norm(r.duration, durMM),
      critical: norm(r.critical, critMM),
      tension: norm(r.tension, tensMM)
    }
    let s = 0
    for (const [k, w] of Object.entries(weights || {})) s += (f[k] || 0) * w
    score.set(r.task.id, s)
  }
  // 确定性并列：score 相同时按 task.id 字典序
  const rank = new Map(rows.map((r) => [r.task.id, r.task.id]))
  return (t) => {
    const s = score.has(t.id) ? score.get(t.id) : Number.POSITIVE_INFINITY
    return s
  }
}

// 为确定性排序提供显式 key（scheduler 用按 key 最小选择，并列时用 id）
function priorityKey(weights, orderSequence, tasks) {
  const fn = makePrepPriority(weights, orderSequence, tasks)
  return (t) => fn(t)
}

module.exports = { FEATURE_VERSION, PARAM_VERSION, TPL_ORDER, CANDIDATE_PARAMS, candidateById, makePrepPriority, priorityKey }
