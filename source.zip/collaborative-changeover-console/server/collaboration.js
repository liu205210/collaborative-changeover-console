'use strict'

/**
 * 第六阶段 · 智能协作与可核验问答（事实/证据层）
 * -------------------------------------------------------------------------
 * 以“共享事实快照”为唯一事实源，构建六类角色的当前观察、判断、待办/阻塞、请求/反馈与证据引用，
 * 并生成结构化协作消息。所有结论引用服务端事实字段，不由语言模型编造。
 *
 * 边界：
 *  - 不改求解器、物理工时、约束、质量门禁、学习参数；只读取既有计划/仿真会话/实验室状态。
 *  - 区分 计划预测(plan) / 当前仿真执行(execution) / 历史回放(replay)；回放只用已保存的事件记录。
 *  - 未知信息显示“未采集/未提供”，不补造 WMS/PLC/视觉实测数据。
 *  - 不求解 reserved；本模块不做任何求解。
 */

const COLLAB_VERSION = 'v6-collab-1.0'

const ONLINE_KEYS = new Set(['line_clear', 'tooling_switch', 'param_apply', 'fai_produce', 'resume'])

const ROLES = [
  { id: 'scheduler', code: 'SCH', name: '调度智能体', role: '全局编排、产线锁定与冲突消解', keys: ['line_clear', 'resume'] },
  { id: 'equipment', code: 'EQP', name: '设备智能体', role: '参数方案离线准备、在线应用与校准', keys: ['param_prepare', 'param_apply'] },
  { id: 'material', code: 'MAT', name: '物料智能体', role: '物料拣配、线边配送与 AGV 占用', keys: ['material_pick', 'material_deliver'] },
  { id: 'tooling', code: 'TLG', name: '工装智能体', role: '离线工装准备与在线工装切换', keys: ['tooling_prep', 'tooling_switch'] },
  { id: 'quality', code: 'QC', name: '质量智能体', role: '首件检验、复检与质量放行门禁', keys: ['fai_inspect', 'quality_release', 'recheck'] },
  { id: 'employee', code: 'EMP', name: '人员调度智能体', role: '技能派工、作业执行与返工试制', keys: ['fai_produce', 'rework'] }
]

const ROLE_OF_KEY = {}
for (const r of ROLES) for (const k of r.keys) ROLE_OF_KEY[k] = r.id

const KEY_LABEL = {
  material_pick: '物料拣配',
  material_deliver: '线边配送',
  tooling_prep: '离线工装准备',
  param_prepare: '参数方案准备(离线)',
  line_clear: '清线与旧工装拆卸(在线)',
  tooling_switch: '工装切换(在线)',
  param_apply: '参数应用与校准(在线)',
  fai_produce: '首件生产(在线)',
  fai_inspect: '首件检验',
  quality_release: '质量放行',
  resume: '恢复生产(在线)',
  rework: '返工与重新试制(在线)',
  recheck: '复检(离线)'
}

const EVENT_LABEL = {
  agv_delay: 'AGV 配送延迟',
  person_absence: '人员临时缺席',
  equipment_failure: '设备故障',
  fai_fail: '首件检验不合格'
}

// 事件 → 首责角色（用于“角色发现异常”消息来源）
const EVENT_OWNER = { agv_delay: 'material', person_absence: 'employee', equipment_failure: 'equipment', fai_fail: 'quality' }

function r2(x) {
  return Math.round(x * 100) / 100
}

function isTaskFragment(entry) {
  // 后续事件可能把 kind 改为 actual；片段身份仍保留在 id/originId 中。
  return entry.kind === 'actual-fragment' || String(entry.id || '').includes('::seg@') || !!(entry.originId && entry.originId !== entry.id)
}

function findWholeTask(entries, order, key) {
  // 完整逻辑任务保留原 id，续作也使用该 id；片段仅作历史证据。
  // 缺少完整任务时返回未知，绝不拿已完成片段代替整项检验/复检/放行。
  return entries.find((e) => e.order === order && e.key === key && !isTaskFragment(e))
}

function tStatus(entry, at, doneIds, opts = {}) {
  const done = entry.end <= at + 1e-9
  if (done) {
    // 暂停片段记录的是已经执行的部分；当前阻塞由对应续作决定。
    if (isTaskFragment(entry)) return '已完成'
    // 失败仅在实际发现时刻（完成时刻）之后已知；复检完成后保留历史但不再作为活动异常
    if (entry.result === 'fail' && !opts.failureResolved) return '异常'
    return '已完成'
  }
  if (entry.kind === 'actual-fragment' || entry.status === 'paused') return '异常'
  if (entry.start <= at + 1e-9) return '进行中'
  // 前序必须真实完成；缺失前序一律视为未满足（不恒真）
  const deps = entry.deps || []
  const satisfied = doneIds instanceof Set ? deps.every((d) => doneIds.has(d)) : deps.length === 0
  if (!satisfied) return '等待'
  if (entry.delayedByResource) return '等待'
  return '待开始'
}

function metricEvidence(ref, label, value, unit, timeBasis, extra) {
  return { ref, type: 'metric', label, value, unit: unit || null, timeBasis, ...(extra || {}) }
}
function taskEvidence(e, timeBasis) {
  return {
    ref: `task:${e.id}`,
    type: 'task',
    id: e.id,
    label: e.name || KEY_LABEL[e.key] || e.key,
    order: e.order,
    key: e.key,
    stage: e.stage,
    skill: e.skill,
    assignee: e.assigneeName || null,
    resource: e.exclusive || e.equipment || null,
    start: e.start,
    end: e.end,
    duration: e.duration,
    unit: '分钟',
    timeBasis,
    result: e.result || null
  }
}
function eventEvidence(rec, timeBasis) {
  return {
    ref: `event:${rec.id}`,
    type: 'event',
    id: rec.id,
    label: `${EVENT_LABEL[rec.event.type] || rec.event.type}`,
    eventType: rec.event.type,
    target: rec.event.target || (rec.event.targets || []).join('+'),
    triggerAt: rec.triggerAt,
    observationTime: rec.snapshotAt,
    sharedSnapshotId: rec.sharedSnapshotId,
    chosen: rec.chosen,
    unit: '分钟',
    timeBasis
  }
}

// ---------------------------------------------------------------------------
// 事实快照
// ---------------------------------------------------------------------------

function digestString(str) {
  const crypto = require('crypto')
  return crypto.createHash('sha256').update(str).digest('hex').slice(0, 16)
}

function planEntryToTask(e) {
  return {
    id: e.id,
    key: e.key,
    name: e.name || KEY_LABEL[e.key],
    order: e.order,
    product: e.product,
    skill: e.skill,
    skillLabel: e.skillLabel,
    exclusive: e.exclusive || null,
    equipment: e.equipment || null,
    stage: e.stage,
    mode: e.mode,
    deps: e.deps || [],
    duration: e.duration,
    start: e.start,
    end: e.end,
    resourceWait: e.resourceWait || 0,
    delayedByResource: !!e.delayedByResource,
    assigneeId: e.assigneeId,
    assigneeName: e.assigneeName,
    kind: 'plan',
    result: 'ok'
  }
}

function snapshotFromPlan(plan) {
  const entries = (plan.schedules && plan.schedules.C ? plan.schedules.C.entries : plan.C ? plan.C.entries : []).map(planEntryToTask)
  const orders = (plan.orders || []).map((o) => ({ order: o.order, product: o.product, productDesc: o.productDesc, qty: o.qty, faces: o.faces, bomLines: o.bomLines, materialTypes: o.materialTypes }))
  const contractDigest = digestString(JSON.stringify({ orders: orders.map((o) => [o.order, o.qty, o.bomLines, o.materialTypes, o.faces]), model: plan.modelVersion }))
  return {
    snapshotId: `snap-plan-${plan.planId || 'last'}-${contractDigest}`,
    collaborationVersion: COLLAB_VERSION,
    kind: 'plan',
    sourceId: plan.planId || 'last-plan',
    modelVersion: plan.modelVersion,
    contractDigest,
    revision: 'plan',
    observationTime: null,
    timeBasis: '规划视界（t=0 起，全部为计划预测，非执行事实）',
    orders,
    tasks: entries,
    knownEvents: [],
    quality: qualityChain(entries, orders.map((o) => o.order), null),
    lineLocks: lineLocks(entries),
    metrics: {
      totalMakespan: plan.schedules && plan.schedules.C ? plan.schedules.C.metrics.makespan : plan.C && plan.C.metrics ? plan.C.metrics.makespan : null,
      onlineStopTotal: plan.schedules && plan.schedules.C ? plan.schedules.C.metrics.onlineStopTotal : null,
      mode: 'C'
    },
    limitations: [
      '计划预测：表示若按方案执行的预测排程，不代表当前正在执行的事实。',
      '单次在线停线窗口与多订单总历时是不同口径，不可相互替代。',
      '真实库存、人员位置、工厂检测值未采集（无 WMS/PLC/视觉实测）。'
    ],
    unknowns: { realInventory: '未采集（仿真假设）', personnelLocation: '未提供', factoryInspection: '未采集' }
  }
}

function basePlanEntries(session) {
  return session.basePlan.entries.map((e) => ({ ...planEntryToTask(e), kind: 'plan' }))
}

function reconstructFromEvent(rec) {
  if (!rec) return null
  const reason = rec.chosen === 'R1' ? rec.R1 : rec.R0
  const entries = rec.frozen.map((e) => ({ ...e }))
    .concat((reason ? reason.entries : []).map((e) => ({ ...e, kind: 'recovery' })))
  // 与 mergeActual 一致：首件失败在版本中体现为检验结果 fail（发现于触发时刻）
  if (rec.event && rec.event.type === 'fai_fail') {
    const insp = entries.find((e) => e.id === `${rec.event.target}::fai_inspect`)
    if (insp) insp.result = 'fail'
  }
  return entries
}

function snapshotFromSession(session, { at, eventIndex } = {}) {
  const replay = eventIndex != null && eventIndex >= 0
  const clock = session.clock || 0
  let entries
  let knownEvents
  let observationTime
  let kind
  let timeBasis
  let revision

  if (replay) {
    if (eventIndex === 0) {
      entries = basePlanEntries(session)
      knownEvents = []
      observationTime = 0
      kind = 'replay'
      revision = 'replay:baseline'
      timeBasis = '历史回放：异常发生前的计划基线（已保存），不使用最终重排结果解释未发生事件'
    } else {
      const rec = session.events[eventIndex - 1]
      if (!rec) throw new Error(`不存在事件序号 ${eventIndex}（该历史版本未保存，不能还原）`)
      entries = reconstructFromEvent(rec)
      knownEvents = session.events.slice(0, eventIndex)
      observationTime = rec.triggerAt
      kind = 'replay'
      revision = `replay:after-${rec.id}`
      timeBasis = `历史回放：事件 ${rec.id} 之后采用方案 ${rec.chosen} 的执行状态（当时已知事件）`
    }
  } else {
    // 任意观察时刻 at 都从当时有效的已保存版本构造：
    // 无已发生事件 → 计划基线；有事件 → 该时刻最后一个已应用事件的冻结片段 + 实际采用方案。
    const viewAt = at == null ? clock : Math.max(0, at)
    const known = session.events.filter((e) => e.triggerAt <= viewAt + 1e-9)
    knownEvents = known
    observationTime = r2(viewAt)
    if (!known.length) {
      entries = basePlanEntries(session)
      revision = 'baseline'
      kind = session.events.length ? 'replay' : (viewAt >= clock ? 'execution' : 'replay')
      timeBasis = session.events.length
        ? '观察时刻早于全部已保存事件：使用异常发生前的计划基线，不拼接历史'
        : '当前仿真执行：尚未发生异常，使用计划基线'
    } else {
      const rec = known[known.length - 1]
      entries = reconstructFromEvent(rec)
      revision = `after-${rec.id}`
      kind = viewAt >= clock ? 'execution' : 'replay'
      timeBasis = viewAt >= clock
        ? `当前仿真执行：会话时钟 ${r2(clock)} 分钟，末次已应用事件 ${rec.id}`
        : `观察时刻（只读快照）：使用该时刻最后一个已应用事件 ${rec.id} 的版本，不改变真实会话时钟`
    }
  }

  const orderIds = session.orderIds || session.orders.map((o) => o.order)
  const orders = (session.orders || []).map((o) => ({ order: o.order, product: o.product, productDesc: o.productDesc, qty: o.qty, faces: o.faces, bomLines: o.bomLines, materialTypes: o.materialTypes }))
  const quality = qualityChain(entries, orderIds, observationTime)
  // 事实内容摘要：任务/结果/资源窗口/已知事件/质量链变化时快照身份必须变化
  const contentDigest = digestString(JSON.stringify({
    tasks: entries.map((e) => [e.id, e.start, e.end, e.duration, e.result || null, e.kind || null, e.assigneeId || null, e.exclusive || null, e.equipment || null, e.delayedByResource ? 1 : 0]),
    events: knownEvents.map((e) => e.signature || e.id),
    quality: quality.map((q) => [q.order, q.faiComplete, q.faiStatus, q.releaseComplete, q.resumeComplete, q.reworkPresent, q.recheckComplete])
  }))
  return {
    snapshotId: `snap-${session.sessionId}-${revision}-${r2(observationTime)}-${contentDigest}`,
    collaborationVersion: COLLAB_VERSION,
    kind,
    sourceId: session.sessionId,
    modelVersion: session.modelVersion,
    contractDigest: digestString(JSON.stringify({ orders: orders.map((o) => [o.order, o.qty, o.bomLines, o.materialTypes, o.faces]), model: session.modelVersion, revision, contentDigest })),
    contentDigest,
    revision,
    observationTime,
    clock: session.clock || 0,
    timeBasis,
    orders,
    tasks: entries,
    knownEvents,
    quality,
    lineLocks: lineLocks(entries),
    metrics: {
      totalMakespan: null,
      onlineStopTotal: null,
      basePlanMakespan: session.basePlan && session.basePlan.metrics ? session.basePlan.metrics.makespan : null,
      mode: 'C'
    },
    limitations: [
      kind === 'replay' ? '历史回放：使用对应版本与当时已知事件，不拼接不存在的真实历史。' : '当前仿真执行：为会话时钟时刻的仿真事实。',
      '真实库存、人员位置、工厂检测值未采集（无 WMS/PLC/视觉实测）。',
      '任务时长来自补充仿真模型，不代表工厂实测工时。'
    ],
    unknowns: { realInventory: '未采集（仿真假设）', personnelLocation: '未提供', factoryInspection: '未采集' }
  }
}

function qualityChain(entries, orderIds, at) {
  const find = (oid, key) => findWholeTask(entries, oid, key)
  return orderIds.map((oid) => {
    const insp = find(oid, 'fai_inspect')
    const rel = find(oid, 'quality_release')
    const rs = find(oid, 'resume')
    const rework = find(oid, 'rework')
    const recheck = find(oid, 'recheck')
    const know = (e) => e && (at == null || e.end <= at + 1e-9 || e.start <= at + 1e-9)
    const faiComplete = !!(insp && (at == null ? insp.end != null : insp.end <= at + 1e-9))
    const releaseComplete = !!(rel && (at == null ? rel.end != null : rel.end <= at + 1e-9))
    const resumeComplete = !!(rs && (at == null ? rs.end != null : rs.end <= at + 1e-9))
    const lockStart = entries.filter((e) => e.order === oid && ONLINE_KEYS.has(e.key)).reduce((m, e) => Math.min(m, e.start), Infinity)
    const lockEnd = rs ? rs.end : -Infinity
    const locked = Number.isFinite(lockStart) && (at == null ? lockStart <= lockEnd : lockStart <= at + 1e-9 && lockEnd > at + 1e-9)
    return {
      order: oid,
      faiComplete,
      faiStatus: insp ? (insp.result === 'fail' && faiComplete ? '不合格' : faiComplete ? '合格' : '待检验') : '未采集',
      releaseComplete,
      resumeComplete,
      lineLockStart: Number.isFinite(lockStart) ? lockStart : null,
      lineLockEnd: Number.isFinite(lockEnd) ? lockEnd : null,
      lineUnlocked: resumeComplete,
      reworkPresent: !!rework,
      recheckPresent: !!recheck,
      recheckComplete: !!(recheck && at != null && recheck.end <= at + 1e-9),
      known: !!insp
    }
  })
}

function lineLocks(entries) {
  const byOrder = {}
  for (const e of entries) {
    if (!ONLINE_KEYS.has(e.key)) continue
    if (!byOrder[e.order]) byOrder[e.order] = { order: e.order, start: Infinity, end: -Infinity }
    byOrder[e.order].start = Math.min(byOrder[e.order].start, e.start)
    byOrder[e.order].end = Math.max(byOrder[e.order].end, e.end)
  }
  return Object.values(byOrder).sort((a, b) => a.start - b.start)
}

// ---------------------------------------------------------------------------
// 六角色状态（同一快照）
// ---------------------------------------------------------------------------

function roleStatusOf(statuses, hasTasks) {
  if (statuses.some((s) => s === '异常')) return '异常'
  if (statuses.some((s) => s === '进行中')) return '进行中'
  if (statuses.some((s) => s === '等待')) return '等待'
  if (hasTasks && statuses.every((s) => s === '已完成')) return '已完成'
  return '待开始'
}

function roleNarrative(roleId, status, ctx) {
  const { at, activeOrder, lineLocks, quality, events } = ctx
  const timeTxt = at == null ? '规划视界' : `${at} 分钟`
  const lock = lineLocks.find((l) => l.start <= (at == null ? 1e9 : at) && l.end > (at == null ? -1e9 : at))
  const base = { observation: '', judgement: '', todo: '', request: '' }
  if (roleId === 'scheduler') {
    base.observation = `${timeTxt}：订单 ${ctx.orders.map((o) => o.order).join('、')}；${lock ? `产线由订单 ${lock.order} 在线换产锁定（${lock.start}→${lock.end} 分钟）` : '当前无在线换产锁定'}`
    base.judgement = status === '已完成' ? '全部在线换产窗口已结束，产线锁定已解除' : '在线换产窗口互斥，锁定自清线开始至恢复生产结束'
    base.todo = status === '等待' ? '等待前置离线准备/线边配送完成后再切入在线换产' : '按快照推进/收束在线换产窗口'
    base.request = status === '异常' ? '收到异常报告，生成 R0/R1 恢复候选并交独立验证' : '维持产线状态一致性'
  } else if (roleId === 'material') {
    base.observation = `AGV-01 线边配送独占；${ctx.roleTasks.filter((t) => t.status !== '已完成').length} 项配送/拣配未完成`
    base.judgement = '物料拣配与线边配送可离线提前；配送未完成则下游清线不得开始'
    base.todo = status === '等待' ? '等待 AGV 释放或前序拣配完成' : '按优先级完成拣配与配送'
    base.request = ctx.events.some((e) => e.event.type === 'agv_delay') ? 'AGV 延迟已记录，请求重排配送顺序' : '请求保持线边配送前置完成'
  } else if (roleId === 'equipment') {
    base.observation = `离线校准台 CAL-01 与回流焊 RFL-01 参与；参数准备/应用 ${ctx.roleTasks.length} 项`
    base.judgement = '参数方案离线准备与在线应用严格区分；在线应用在工装切换后'
    base.todo = status === '等待' ? '等待工装切换或前序完成' : '完成离线准备与在线应用校准'
    base.request = ctx.events.some((e) => e.event.type === 'equipment_failure') ? '设备故障窗口已记录，请求避让故障设备' : '请求保持设备可用'
  } else if (roleId === 'tooling') {
    base.observation = `离线工装准备 + 产线在位切换 ${ctx.roleTasks.length} 项`
    base.judgement = '在线切换开始即锁定产线在位配置，直至本订单质量放行、恢复生产'
    base.todo = status === '等待' ? '等待离线工装准备与线边配送完成' : '执行离线准备与在线切换'
    base.request = '物料未到线边时不做无意义在线切换'
  } else if (roleId === 'quality') {
    const resolvedFails = quality.filter((x) => x.faiStatus === '不合格' && x.recheckComplete)
    const q = quality.map((x) => `${x.order}:${x.faiStatus}${x.releaseComplete ? '/已放行' : ''}${x.reworkPresent ? (x.recheckComplete ? '/返工复检已完成' : '/返工中') : ''}`).join('，')
    base.observation = `${timeTxt} 质量链：${q}`
    base.judgement = '首件检验合格 → 质量放行 → 恢复生产；不合格需返工复检，复检合格前禁止放行'
    base.todo = quality.some((x) => x.faiStatus === '不合格' && !x.recheckComplete) ? '等待返工与复检完成' : '完成首件检验与放行复核'
    base.request = quality.some((x) => x.faiStatus === '不合格' && !x.recheckComplete)
      ? '已拦截放行并触发返工，请求安排复检'
      : resolvedFails.length
        ? `历史上曾有 ${resolvedFails.map((x) => x.order).join('、')} 首件不合格，已完成返工复检，保留历史记录`
        : '门禁保持'
  } else if (roleId === 'employee') {
    base.observation = `人员名册 ${ctx.personnelCount} 人；执行工序 ${ctx.roleTasks.length} 项`
    base.judgement = '相同人员同一时刻不得承担冲突任务；技能须匹配'
    base.todo = status === '等待' ? '等待前序完成或人员释放' : '按技能派工并执行'
    base.request = ctx.events.some((e) => e.event.type === 'person_absence') ? '人员缺席时段已记录，请求在技能约束下重分配' : '请求保持派工与技能匹配'
  }
  return base
}

function buildRoleStates(snapshot) {
  const at = snapshot.observationTime
  const atVal = at == null ? 0 : at
  const doneIds = new Set(snapshot.tasks.filter((t) => t.end <= atVal + 1e-9).map((t) => t.id))
  // 已复检完成的失败属于历史，不再计为活动异常
  const resolvedFailIds = new Set()
  for (const t of snapshot.tasks) {
    if (t.result !== 'fail' || isTaskFragment(t)) continue
    const recheck = findWholeTask(snapshot.tasks, t.order, 'recheck')
    if (recheck && recheck.end <= atVal + 1e-9) resolvedFailIds.add(t.id)
  }
  const personnelCount = 12

  return ROLES.map((def) => {
    const roleTasks = snapshot.tasks.filter((t) => def.keys.includes(t.key))
    const tasks = roleTasks.map((t) => {
      const status = tStatus(t, atVal, doneIds, { failureResolved: resolvedFailIds.has(t.id) })
      let blockedReason = null
      if (status === '等待') {
        const missing = (t.deps || []).filter((d) => !doneIds.has(d))
        blockedReason = missing.length ? `前序未完成：${missing.join('、')}` : t.delayedByResource ? `资源等待 ${r2(t.resourceWait)} 分钟（${t.exclusive || t.skill}）` : '等待资源'
      } else if (status === '异常') {
        blockedReason = t.result === 'fail' ? '首件检验不合格，触发返工/复检' : '在制片段因异常暂停'
      }
      return { ...t, status, blockedReason, resolvedFailure: resolvedFailIds.has(t.id) }
    })
    const statuses = tasks.map((t) => t.status)
    const status = roleStatusOf(statuses, tasks.length > 0)
    const salient = tasks.find((t) => t.status === '进行中') || tasks.find((t) => t.status === '异常') || tasks.find((t) => t.status === '等待') || tasks.find((t) => t.status === '待开始') || tasks[tasks.length - 1] || null
    const narrative = roleNarrative(def.id, status, { at, activeOrder: snapshot.lineLocks[0] ? snapshot.lineLocks[0].order : null, lineLocks: snapshot.lineLocks, quality: snapshot.quality, events: snapshot.knownEvents, roleTasks: tasks, orders: snapshot.orders, personnelCount })
    const evidenceRefs = tasks.map((t) => taskEvidence(t, snapshot.timeBasis))
    for (const rec of snapshot.knownEvents) {
      if (EVENT_OWNER[rec.event.type] === def.id) evidenceRefs.push(eventEvidence(rec, snapshot.timeBasis))
    }
    return {
      id: def.id,
      code: def.code,
      name: def.name,
      role: def.role,
      status,
      taskCount: tasks.length,
      observation: narrative.observation,
      judgement: narrative.judgement,
      todo: narrative.todo,
      request: narrative.request,
      blocked: tasks.filter((t) => t.status === '等待' || t.status === '异常').map((t) => ({ taskId: t.id, order: t.order, key: t.key, status: t.status, reason: t.blockedReason, kind: t.kind })),
      tasks,
      currentTask: salient ? { id: salient.id, order: salient.order, key: salient.key, name: salient.name, status: salient.status, start: salient.start, end: salient.end, assignee: salient.assigneeName || null, kind: salient.kind } : null,
      evidenceRefs
    }
  })
}

// ---------------------------------------------------------------------------
// 真实协作记录（结构化消息 + 证据引用）
// ---------------------------------------------------------------------------

function buildMessages(snapshot) {
  const at = snapshot.observationTime == null ? 1e9 : snapshot.observationTime
  const messages = []
  let seq = 0
  const push = (time, from, to, type, reasonCode, text, evidenceRefs, extra) => {
    seq++
    messages.push({ id: `msg:${snapshot.snapshotId}:${seq}`, snapshotId: snapshot.snapshotId, time: r2(time), from, to, type, reasonCode, text, evidenceRefs: evidenceRefs || [], ...(extra || {}) })
  }
  const roleName = (id) => (ROLES.find((r) => r.id === id) || {}).name || id
  const timeBasis = snapshot.timeBasis

  // 计划/执行：调度下达指令
  push(0, 'scheduler', 'all', '指令', 'ORDER_DISPATCHED', `下达换产指令：订单 ${snapshot.orders.map((o) => o.order).join('、')}；本快照为${snapshot.kind === 'plan' ? '计划预测' : snapshot.kind === 'replay' ? '历史回放' : '当前仿真执行'}`, snapshot.orders.map((o) => ({ ref: `order:${o.order}`, type: 'order', label: `订单 ${o.order}`, value: o.product, timeBasis })))

  const roles = buildRoleStates(snapshot)
  for (const role of roles) {
    if (!role.currentTask) continue
    const ev = role.evidenceRefs.slice(0, 4)
    if (role.status === '异常') {
      push(role.currentTask.start, role.id, 'scheduler', '异常', 'ANOMALY_DETECTED', `${role.name}报告：${role.currentTask.name}（订单 ${role.currentTask.order}）状态异常，${role.blocked.map((b) => b.reason).join('；') || '需协调'}`, ev, { evidenceTask: role.currentTask.id })
    } else if (role.status === '等待') {
      push(role.currentTask.start, role.id, 'scheduler', '请求', 'WAIT_PREDECESSOR', `${role.name}请求：${role.currentTask.name}（订单 ${role.currentTask.order}）等待中，${role.blocked.map((b) => b.reason).join('；')}`, ev, { evidenceTask: role.currentTask.id })
    } else if (role.status === '进行中') {
      push(role.currentTask.start, role.id, 'scheduler', '执行反馈', 'EXECUTING', `${role.name}：${role.currentTask.name}（订单 ${role.currentTask.order}）执行中，执行人 ${role.currentTask.assignee || '—'}`, ev, { evidenceTask: role.currentTask.id })
    } else if (role.status === '已完成' && role.tasks.length) {
      const last = role.tasks[role.tasks.length - 1]
      push(last.end, role.id, 'scheduler', '执行反馈', 'FEEDBACK', `${role.name}：本快照内 ${role.tasks.length} 项工序全部完成`, ev)
    }
  }

  // 质量门禁
  for (const q of snapshot.quality) {
    const insp = findWholeTask(snapshot.tasks, q.order, 'fai_inspect')
    if (!insp) continue
    if (q.faiComplete) {
      if (q.faiStatus === '不合格' && q.recheckComplete) {
        const recheck = findWholeTask(snapshot.tasks, q.order, 'recheck')
        push(insp.end, 'quality', 'scheduler', '历史不合格', 'GATE_HISTORICAL', `订单 ${q.order} 曾首件不合格，已完成返工复检，保留历史记录（复检完成 ${recheck ? recheck.end : '—'} 分钟）`, [taskEvidence(insp, timeBasis), ...(recheck ? [taskEvidence(recheck, timeBasis)] : [])])
      } else {
        push(insp.end, 'quality', 'scheduler', q.faiStatus === '不合格' ? '质量拦截' : '质量放行', q.faiStatus === '不合格' ? 'GATE_FAIL' : 'GATE_PASS', `订单 ${q.order} 首件检验完成：${q.faiStatus}${q.faiStatus === '不合格' ? '，禁止放行与恢复生产，触发返工/复检' : '，进入质量放行复核'}`, [taskEvidence(insp, timeBasis)])
      }
    }
    const rel = findWholeTask(snapshot.tasks, q.order, 'quality_release')
    if (rel && q.releaseComplete) push(rel.end, 'quality', 'scheduler', '质量放行', 'GATE_PASS', `订单 ${q.order} 质量放行完成`, [taskEvidence(rel, timeBasis)])
    const rs = findWholeTask(snapshot.tasks, q.order, 'resume')
    if (rs && q.resumeComplete) push(rs.end, 'scheduler', 'all', '锁定解除', 'LINE_UNLOCKED', `订单 ${q.order} 恢复生产完成，产线锁定解除`, [taskEvidence(rs, timeBasis)])
  }

  // 事件协调链
  for (const rec of snapshot.knownEvents) {
    const owner = EVENT_OWNER[rec.event.type] || 'scheduler'
    const evd = eventEvidence(rec, timeBasis)
    push(rec.triggerAt, owner, 'scheduler', '异常', 'ANOMALY_DETECTED', `${roleName(owner)}发现异常：${EVENT_LABEL[rec.event.type]}（对象 ${evd.target}），实际触发 ${rec.triggerAt} 分钟`, [evd])
    push(rec.snapshotAt, 'scheduler', 'all', '共享快照', 'SNAPSHOT_SHARED', `以事件前快照 ${rec.sharedSnapshotId} 为准（冻结至触发时刻），不使用未来信息`, [{ ref: `snapshot:${rec.sharedSnapshotId}`, type: 'snapshot', label: rec.sharedSnapshotId, value: rec.snapshotAt, unit: '分钟', timeBasis }])
    const d = r2(rec.R0.metrics.makespan - rec.R1.metrics.makespan)
    push(rec.triggerAt, 'scheduler', 'all', '对比', 'R0R1_COMPARED', `R0（固定顺序）${rec.R0.metrics.makespan} 分钟 vs R1（动态）${rec.R1.metrics.makespan} 分钟，差值 ${d} 分钟${Math.abs(d) <= 0.05 ? '（持平）' : ''}`, [
      metricEvidence(`metric:${rec.id}:R0`, 'R0 恢复总历时', rec.R0.metrics.makespan, '分钟', timeBasis),
      metricEvidence(`metric:${rec.id}:R1`, 'R1 恢复总历时', rec.R1.metrics.makespan, '分钟', timeBasis),
      metricEvidence(`metric:${rec.id}:remaining`, '触发后剩余时间（R1）', rec.R1.metrics.remainingAfterTrigger, '分钟', timeBasis)
    ])
    push(rec.triggerAt, 'scheduler', 'all', '独立验证', 'VALIDATION_RESULT', `R0 验证${rec.R0.validation.ok ? '通过' : '未通过'}，R1 验证${rec.R1.validation.ok ? '通过' : '未通过'}；采用 ${rec.chosen}${rec.chosenFromR0 ? '（R1 未通过或未改善，回退 R0）' : ''}`, [
      { ref: `validation:${rec.id}:R0`, type: 'validation', label: 'R0 独立验证', value: rec.R0.validation.ok ? '通过' : '未通过', timeBasis, checks: rec.R0.validation.checks.map((c) => `${c.name}:${c.status}`) },
      { ref: `validation:${rec.id}:R1`, type: 'validation', label: 'R1 独立验证', value: rec.R1.validation.ok ? '通过' : '未通过', timeBasis, checks: rec.R1.validation.checks.map((c) => `${c.name}:${c.status}`) }
    ])
    push(rec.triggerAt, 'scheduler', 'all', '采用', 'PLAN_ADOPTED', `采用 ${rec.chosen} 作为后续执行；计划调整 ${rec.chosen === 'R1' ? rec.R1.metrics.adjustments : rec.R0.metrics.adjustments} 项`, [metricEvidence(`metric:${rec.id}:adjust`, '计划调整数量', rec.chosen === 'R1' ? rec.R1.metrics.adjustments : rec.R0.metrics.adjustments, '项', timeBasis)])
    push(rec.triggerAt, owner, 'scheduler', '执行反馈', 'FEEDBACK', `${roleName(owner)}按 ${rec.chosen} 更新后续任务并保留历史执行片段`, [evd])
  }

  push(at === 1e9 ? (snapshot.metrics.totalMakespan || snapshot.metrics.basePlanMakespan || 0) : at, 'scheduler', 'all', '汇总', 'SUMMARY', `快照 ${snapshot.snapshotId}：任务 ${snapshot.tasks.length} 项，已知事件 ${snapshot.knownEvents.length} 个，${snapshot.timeBasis}`, [metricEvidence('metric:snapshot:taskCount', '任务数', snapshot.tasks.length, '项', timeBasis)])

  return messages.sort((a, b) => a.time - b.time || (a.id < b.id ? -1 : 1))
}

module.exports = { COLLAB_VERSION, ROLES, ROLE_OF_KEY, KEY_LABEL, EVENT_LABEL, EVENT_OWNER, snapshotFromPlan, snapshotFromSession, buildRoleStates, buildMessages, qualityChain, lineLocks, tStatus, taskEvidence, eventEvidence, metricEvidence, r2 }

