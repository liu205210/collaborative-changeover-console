'use strict'

/**
 * 批量评测（Batch Evaluation）· 收尾修复版
 * -------------------------------------------------------------------------
 * - 目录/分组使用固定 CATALOG_SEED，求解 seed 只影响求解，不改变分集。
 * - 缺省或空数组只运行 dev+validation；非法集合明确处理；绝不默默运行全部。
 * - reserved 保留集由历史使用指纹保护，已使用场景不能被重贴为未使用。
 * - 计数分列：案例数 / 换产实例数 / 唯一基线数 / 异常注入数。
 * - 指标仅纳入对应方案可行的结果；失败/不可行/不适用/部分分别记录。
 * - 4000ms 为性能警戒线（仅统计标记），非求解预算上限。
 */

const sim = require('./simulation')
const sched = require('./scheduler')
const recovery = require('./recovery')
const fs = require('fs')
const path = require('path')
const store = require('./store')

const CATALOG_SEED = 20261007
const RESERVED_SEED = 20261101
const PERF_WARN_MS = 4000
const DEFAULT_SETS = ['dev', 'validation']
const ALL_SETS = ['dev', 'validation', 'frozen', 'reserved']

// 历史实际已使用的保留集指纹（v4.2 verify 的“保留集保护”测试实际求解，见 data-eval-evidence.json）。
// 内嵌以保证不因删除运行期文件而被重置；usedAt 未知，不伪造时间戳。
const HISTORICAL_RESERVED_USED = [
  { id: 'R1-2', fingerprint: 'static|4003111909|normal||静态-单订单' },
  { id: 'R1-3', fingerprint: 'static|4003111848|normal||静态-单订单' },
  { id: 'R1-4', fingerprint: 'static|4003111640|normal||静态-单订单' },
  { id: 'R3-5', fingerprint: 'static|4003111279+4003111656+4003111848|normal||静态-3订单' },
  { id: 'R3-6', fingerprint: 'static|4003111635+4003111816+4003111960|normal||静态-3订单' },
  { id: 'R3-7', fingerprint: 'static|4003111812+4003111905+4003111914|normal||静态-3订单' },
  { id: 'R3-8', fingerprint: 'static|4003111142+4003111655+4003111677|normal||静态-3订单' },
  { id: 'R5-9', fingerprint: 'static|4003111149+4003111692+4003111869+4003111900+4003111910|normal||静态-5订单' },
  { id: 'R5-10', fingerprint: 'static|4003111034+4003111188+4003111811+4003111813+4003111902|normal||静态-5订单' },
  { id: 'R5-11', fingerprint: 'static|4003111034+4003111601+4003111864+4003111900+4003111903|normal||静态-5订单' }
]
const HISTORICAL_RESERVED_USED_FP = HISTORICAL_RESERVED_USED.map((x) => x.fingerprint)
const RETIRED_UNUSED_RESERVED = { id: 'R1-1', note: '旧保留集中被排除、未实际求解的退役案例' }

// 独立 CLI 默认持久化；HTTP/回归可继续注册自己的同步 sink。
// 纯筛选（selectCases）不触发 sink，因此不记为执行。
let usageSink = null
function setUsageSink(fn) {
  usageSink = typeof fn === 'function' ? fn : null
}

const USAGE_FILE = 'eval-usage.json'
function readDefaultUsage() {
  const file = path.join(store.STORE_DIR, USAGE_FILE)
  // 不使用 store.readJSON 的容错回退：坏账本不能被当作从未运行。
  const usage = fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {}
  if (!usage || typeof usage !== 'object' || Array.isArray(usage)) throw new Error('使用账本必须是对象')
  for (const key of ['fingerprints', 'runs', 'history']) {
    if (usage[key] === undefined) usage[key] = []
    if (!Array.isArray(usage[key])) throw new Error(`使用账本 ${key} 必须是数组`)
  }
  const fingerprints = new Set(usage.fingerprints)
  const history = new Set(usage.history.map((entry) => entry.fingerprint))
  for (const entry of HISTORICAL_RESERVED_USED) {
    fingerprints.add(entry.fingerprint)
    if (!history.has(entry.fingerprint)) {
      usage.history.push({ ...entry, source: 'v4.2 verify 保留集保护测试（回归实际求解）', usedAt: 'unknown', evidence: 'data-eval-evidence.json / release/round4/test-output.txt' })
      history.add(entry.fingerprint)
    }
  }
  usage.fingerprints = Array.from(fingerprints)
  return usage
}

function defaultUsageSink(record) {
  const usage = readDefaultUsage()
  usage.fingerprints = Array.from(new Set([...usage.fingerprints, ...record.fingerprints]))
  if (!usage.runs.some((run) => run.runId === record.runId)) {
    usage.runs.push({ ...record, runId: record.runId, at: record.at, effectiveSets: record.effectiveSets, reservedRun: record.reservedRun })
  }
  store.writeJSON(USAGE_FILE, usage)
}

function usageFailure(cause, report) {
  const recoveryRecord = report ? { runId: report.runId, fingerprints: report.usedFingerprints } : null
  const error = new Error(report
    ? `评测已执行，但使用记账失败；不得视为未运行。恢复记录=${JSON.stringify(recoveryRecord)}；原因：${cause.message}`
    : `评测未执行：无法读取或写入使用账本。原因：${cause.message}`)
  error.code = 'EVALUATION_USAGE_UNAVAILABLE'
  error.executed = !!report
  error.runId = report ? report.runId : null
  error.usedFingerprints = report ? report.usedFingerprints.slice() : []
  error.report = report || null
  error.cause = cause
  return error
}

function mulberry32(seed) {
  let a = seed >>> 0
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
function round2(x) {
  return Math.round(x * 100) / 100
}
function fingerprint(c) {
  return [c.kind, (c.orders || []).slice().sort().join('+'), c.resources || 'normal', c.anomaly || '', c.category].join('|')
}

const TIGHT_PERSONNEL_IDS = ['MAT-01', 'EQP-01', 'TLG-01', 'QC-01', 'OPR-01']
function tightPersonnel() {
  return sim.DEFAULT_PERSONNEL.filter((p) => TIGHT_PERSONNEL_IDS.includes(p.id))
}

function combos(list, size, count, rand) {
  const out = []
  let guard = 0
  while (out.length < count && guard++ < 5000) {
    const c = []
    const used = new Set()
    while (c.length < size) {
      const idx = Math.floor(rand() * list.length)
      if (used.has(idx)) continue
      used.add(idx)
      c.push(list[idx].order)
    }
    const key = c.slice().sort().join('|')
    if (!out.some((x) => x.key === key)) out.push({ key, orders: c })
  }
  return out
}

// 固定目录：分组与分集只依赖 CATALOG_SEED；reserved 用独立种子生成，并与历史已用输入去重（不求解）
function buildCaseCatalog(orders, usedFingerprints) {
  const used = new Set([...(usedFingerprints || []), ...HISTORICAL_RESERVED_USED_FP])
  const rand = mulberry32(CATALOG_SEED)
  const raw = []
  const push = (c) => raw.push(c)
  combos(orders, 1, 10, rand).forEach((c, i) => push({ id: `S1-${i + 1}`, group: `g1:${c.key}`, category: '静态-单订单', kind: 'static', orders: c.orders, resources: 'normal' }))
  combos(orders, 3, 9, rand).forEach((c, i) => push({ id: `S3-${i + 1}`, group: `g3:${c.key}`, category: '静态-3订单', kind: 'static', orders: c.orders, resources: 'normal' }))
  combos(orders, 5, 6, rand).forEach((c, i) => push({ id: `S5-${i + 1}`, group: `g5:${c.key}`, category: '静态-5订单', kind: 'static', orders: c.orders, resources: 'normal' }))
  combos(orders, 10, 3, rand).forEach((c, i) => push({ id: `S10-${i + 1}`, group: `g10:${c.key}`, category: '静态-10订单', kind: 'static', orders: c.orders, resources: 'normal' }))
  ;[0, 1, 2].forEach((i) => {
    const base = raw.find((x) => x.id === `S3-${i + 1}`)
    if (base) push({ id: `T3-${i + 1}`, group: base.group, category: '静态-资源紧张', kind: 'static', orders: base.orders, resources: 'tight' })
  })
  ;[0, 1].forEach((i) => {
    const base = raw.find((x) => x.id === `S5-${i + 1}`)
    if (base) push({ id: `T5-${i + 1}`, group: base.group, category: '静态-资源紧张', kind: 'static', orders: base.orders, resources: 'tight' })
  })
  const anomalyTypes = ['agv_delay', 'person_absence', 'equipment_failure', 'fai_fail']
  anomalyTypes.forEach((type, ti) => {
    for (let i = 0; i < 4; i++) {
      const o = orders[(ti * 4 + i) % orders.length]
      push({ id: `A-${type}-${i + 1}`, group: `g1:${o.order}`, category: `异常-${type}`, kind: 'anomaly', orders: [o.order], anomaly: type })
    }
  })
  for (let i = 0; i < 4; i++) {
    const os = orders.slice(i, i + 3)
    push({ id: `AC-${i + 1}`, group: `g3:${os.map((o) => o.order).sort().join('|')}`, category: '异常-连续', kind: 'anomaly-consecutive', orders: os.map((o) => o.order), anomaly: 'consecutive' })
  }
  for (let i = 0; i < 4; i++) {
    const o = orders[(i + 20) % orders.length]
    push({ id: `AB-${i + 1}`, group: `g1:${o.order}`, category: '异常-边界时刻', kind: 'anomaly-boundary', orders: [o.order], anomaly: 'equipment_failure' })
  }
  for (let i = 0; i < 3; i++) {
    const o = orders[(i + 30) % orders.length]
    push({ id: `IF-${i + 1}`, group: `g1:${o.order}`, category: '不可行', kind: 'infeasible', orders: [o.order], anomaly: 'person_absence' })
  }
  const groups = Array.from(new Set(raw.map((c) => c.group)))
  const groupSet = new Map()
  // 核心集合（dev/validation/frozen）按基线组稳定分配；reserved 单独用不同种子生成，保证是未使用的新场景
  groups.forEach((g, i) => groupSet.set(g, ['dev', 'validation', 'frozen'][i % 3]))
  const core = raw.map((c) => ({ ...c, set: groupSet.get(c.group), fingerprint: fingerprint(c) }))
  const coreFp = new Set(core.map((c) => c.fingerprint))

  const rrand = mulberry32(RESERVED_SEED)
  const reserved = []
  // 与全部核心/历史已用“输入”去重（按订单集合与指纹双重去重），避免同一基线跨集冒充独立验证
  const coreOrderKeys = new Set(core.map((c) => c.orders.slice().sort().join('+')))
  const usedOrderKeys = new Set()
  for (const fp of used) {
    const m = fp.split('|')[1]
    if (m) usedOrderKeys.add(m.split('+').slice().sort().join('+'))
  }
  const reservedSpecs = [
    { size: 1, count: 30, target: 4, cat: '静态-单订单', kind: 'static', prefix: 'R1' },
    { size: 3, count: 30, target: 4, cat: '静态-3订单', kind: 'static', prefix: 'R3' },
    { size: 5, count: 30, target: 4, cat: '静态-5订单', kind: 'static', prefix: 'R5' }
  ]
  for (const spec of reservedSpecs) {
    let n = 0
    for (const c of combos(orders, spec.size, spec.count, rrand)) {
      if (reserved.filter((x) => x.category === spec.cat).length >= spec.target) break
      const key = c.orders.slice().sort().join('+')
      if (coreOrderKeys.has(key) || usedOrderKeys.has(key)) continue
      const cand = { id: `${spec.prefix}-r${++n}`, group: `reserved:g${spec.size}:${c.key}`, category: spec.cat, kind: spec.kind, orders: c.orders, resources: 'normal' }
      const fp = fingerprint(cand)
      if (coreFp.has(fp) || used.has(fp) || reserved.some((x) => x.fingerprint === fp)) continue
      reserved.push({ ...cand, set: 'reserved', fingerprint: fp })
    }
  }
  return core.concat(reserved)
}

// 纯选择/筛选：不进入任何求解器。用于页面选择、审计与回归。
function selectCases(catalog, { sets, categories, usage } = {}) {
  const requested = Array.isArray(sets) && sets.length ? sets.slice() : DEFAULT_SETS.slice()
  const unknown = requested.filter((s) => !ALL_SETS.includes(s))
  let effective = requested.filter((s) => ALL_SETS.includes(s))
  if (!effective.length) effective = DEFAULT_SETS.slice()
  const usedFp = new Set([...(usage && usage.fingerprints ? usage.fingerprints : []), ...HISTORICAL_RESERVED_USED_FP])
  const excludedReserved = []
  let selected = catalog.filter((c) => effective.includes(c.set))
  if (effective.includes('reserved')) {
    const kept = []
    for (const c of selected) {
      if (c.set === 'reserved' && usedFp.has(c.fingerprint)) excludedReserved.push(c.id)
      else kept.push(c)
    }
    selected = kept
  }
  if (Array.isArray(categories) && categories.length) selected = selected.filter((c) => categories.includes(c.category))
  return { selected, effectiveSets: effective, unknownSets: unknown, excludedReserved }
}

// ---------------------------------------------------------------------------
// 单案执行
// ---------------------------------------------------------------------------

function runStaticCase(entry, ordersById, seed, strategyOverride) {
  const selOrders = entry.orders.map((id) => ordersById.get(id)).filter(Boolean)
  const personnel = entry.resources === 'tight' ? tightPersonnel() : sim.DEFAULT_PERSONNEL
  const { tasks, personnel: per, exclusive, equipment } = sim.buildTaskSet(selOrders, { personnel })
  const t0 = performance.now()
  let result
  try {
    result = sched.buildSchedules({ tasks, personnel: per, exclusive, equipment, ordersInOrder: entry.orders, seed, strategyOverride })
  } catch (e) {
    const infeasible = /设备库存|班次\/资源日历/.test(e.message)
    return { status: infeasible ? 'infeasible' : 'error', reason: e.message, changeoverInstances: 0, anomalyInjections: 0 }
  }
  const computeTimeMs = performance.now() - t0
  const validation = {
    A: sched.validateSchedule(result.A.entries, tasks, per, { equipment }),
    B: sched.validateSchedule(result.B.entries, tasks, per, { equipment }),
    C: sched.validateSchedule(result.C.entries, tasks, per, { equipment })
  }
  const feasible = { A: validation.A.ok, B: validation.B.ok, C: validation.C.ok }
  return {
    status: 'ok',
    computeTimeMs: Number(computeTimeMs.toFixed(1)),
    perfWarn: computeTimeMs > PERF_WARN_MS,
    feasible,
    changeoverInstances: entry.orders.length,
    anomalyInjections: 0,
    makespan: { A: result.A.metrics.makespan, B: result.B.metrics.makespan, C: result.C.metrics.makespan },
    onlineStopTotal: { A: result.A.metrics.onlineStopTotal, B: result.B.metrics.onlineStopTotal, C: result.C.metrics.onlineStopTotal },
    equipmentUsed: Array.from(new Set(result.C.metrics.equipmentUsage.filter((e) => e.busy > 0).map((e) => e.id))),
    personnel: { roster: sim.DEFAULT_PERSONNEL.length, availableAtZero: sim.DEFAULT_PERSONNEL.filter((p) => p.shiftWindow[0] <= 0).length, used: result.C.metrics.utilization.filter((u) => u.busy > 0).length },
    validation: { A: validation.A.checks.map((c) => `${c.name}:${c.status}`), B: validation.B.checks.map((c) => `${c.name}:${c.status}`), C: validation.C.checks.map((c) => `${c.name}:${c.status}`) },
    delta: { AtoB: round2(result.A.metrics.makespan - result.B.metrics.makespan), BtoC: round2(result.B.metrics.makespan - result.C.metrics.makespan), AtoC: round2(result.A.metrics.makespan - result.C.metrics.makespan) }
  }
}

function firstDelivery(session, order) {
  return session.actualEntries.filter((e) => e.key === 'material_deliver' && (!order || e.order === order)).sort((a, b) => a.start - b.start)[0]
}
function anomalyEvent(type, session, entry, boundary) {
  const order = entry.orders[0]
  if (type === 'agv_delay') {
    const d = firstDelivery(session, order) || firstDelivery(session)
    return { type: 'agv_delay', target: d.id, at: Math.max(0, d.start), duration: 15 }
  }
  if (type === 'person_absence') return { type: 'person_absence', target: 'EQP-01', at: 6, duration: 8, policy: 'finish_current' }
  if (type === 'equipment_failure') {
    if (boundary) {
      const d = firstDelivery(session, order) || firstDelivery(session)
      return { type: 'equipment_failure', target: 'MNT-01', at: d.end, duration: 8 }
    }
    return { type: 'equipment_failure', target: 'MNT-01', at: 8, duration: 8 }
  }
  if (type === 'fai_fail') return { type: 'fai_fail', target: order, at: 0 }
  return null
}

function runAnomalyCase(entry, ordersById, seed) {
  const selOrders = entry.orders.map((id) => ordersById.get(id)).filter(Boolean)
  let bundle = recovery.createSession({ orders: selOrders, seed })
  if (bundle.infeasible) return { status: 'infeasible', reason: bundle.infeasibleReason, changeoverInstances: 0, anomalyInjections: 0 }
  const planned = []
  if (entry.kind === 'anomaly-consecutive') {
    planned.push(anomalyEvent('agv_delay', bundle, entry, false))
    planned.push(anomalyEvent('person_absence', bundle, entry, false))
  } else {
    planned.push(anomalyEvent(entry.anomaly, bundle, entry, entry.kind === 'anomaly-boundary'))
  }
  const t0 = performance.now()
  const events = []
  let lastRecord = null
  for (const ev of planned) {
    if (!ev) {
      events.push({ type: null, applied: false, reason: '无可注入事件' })
      continue
    }
    const res = recovery.applyEvent(bundle, ev)
    events.push({ type: ev.type, at: ev.at, target: ev.target, applied: !!res.result.applied, reason: res.result.reason || null })
    if (res.result.applied) {
      bundle = res.bundle
      lastRecord = res.result.eventRecord
    }
  }
  const computeTimeMs = performance.now() - t0
  const appliedCount = events.filter((r) => r.applied).length
  if (!lastRecord) return { status: 'not_applicable', reason: events.map((r) => r.reason).filter(Boolean).join('；') || '事件未生效', events, changeoverInstances: 0, anomalyInjections: 0, computeTimeMs: Number(computeTimeMs.toFixed(1)) }
  const r0 = lastRecord.R0
  const r1 = lastRecord.R1
  return {
    status: appliedCount === planned.filter(Boolean).length ? 'ok' : 'partial',
    events,
    eventsApplied: appliedCount,
    eventsPlanned: planned.filter(Boolean).length,
    failureReason: events.filter((r) => !r.applied).map((r) => r.reason).filter(Boolean).join('；') || null,
    computeTimeMs: Number(computeTimeMs.toFixed(1)),
    perfWarn: computeTimeMs > PERF_WARN_MS,
    changeoverInstances: 1,
    anomalyInjections: appliedCount,
    triggerAt: lastRecord.triggerAt,
    r0Feasible: r0.validation.ok,
    r1Feasible: r1.validation.ok,
    r0Makespan: r0.metrics.makespan,
    r1Makespan: r1.metrics.makespan,
    r0Remaining: r0.metrics.remainingAfterTrigger,
    r1Remaining: r1.metrics.remainingAfterTrigger,
    onlineStopTotal: r1.metrics.onlineStopTotal,
    adjustments: r1.metrics.adjustments,
    usedR0Fallback: lastRecord.chosenFromR0 === true,
    chosen: lastRecord.chosen,
    shareSnapshot: lastRecord.sharedSnapshotId,
    trajectory: (lastRecord.R1.entries || []).map((e) => ({ id: e.id, key: e.key, order: e.order, start: e.start, end: e.end, assignee: e.assigneeName, equipment: e.equipment }))
  }
}

function runInfeasibleCase(entry, ordersById, seed) {
  const selOrders = entry.orders.map((id) => ordersById.get(id)).filter(Boolean)
  const bundle = recovery.createSession({ orders: selOrders, seed })
  const toolingIds = sim.DEFAULT_PERSONNEL.filter((p) => p.skill === 'tooling').map((p) => p.id)
  const res = recovery.applyEvent(bundle, { type: 'person_absence', targets: toolingIds, at: 0, to: 5000 })
  return { status: res.result.applied ? 'unexpected_ok' : 'infeasible', reason: res.result.reason || '不可行', applied: res.result.applied, changeoverInstances: 0, anomalyInjections: 0 }
}

// ---------------------------------------------------------------------------
// 统计
// ---------------------------------------------------------------------------

function pctl(values, p) {
  if (!values.length) return null
  const arr = values.slice().sort((a, b) => a - b)
  return arr[Math.min(arr.length - 1, Math.ceil(p * arr.length) - 1)]
}
function stat(values) {
  const v = values.filter((x) => typeof x === 'number' && Number.isFinite(x))
  if (!v.length) return { n: 0, mean: null, median: null, p95: null }
  return { n: v.length, mean: round2(v.reduce((s, x) => s + x, 0) / v.length), median: round2(pctl(v, 0.5)), p95: round2(pctl(v, 0.95)) }
}

function summarize(cases) {
  const byCategory = {}
  for (const c of cases) {
    const k = c.category
    byCategory[k] = byCategory[k] || { category: k, cases: 0, feasiblePlans: 0, totalPlans: 0, violations: 0, infeasible: 0, notApplicable: 0, partial: 0, perfWarn: 0, errors: 0, validPairs: 0 }
    const b = byCategory[k]
    b.cases++
    if (c.result.status === 'ok' || c.result.status === 'partial') {
      if (c.kind === 'static') {
        b.totalPlans += 3
        b.feasiblePlans += ['A', 'B', 'C'].filter((m) => c.result.feasible[m]).length
        b.violations += Object.values(c.result.validation || {}).reduce((s, v) => s + v.filter((x) => x.endsWith(':fail')).length, 0)
        if (c.result.feasible.A && c.result.feasible.C) b.validPairs++
      } else {
        b.totalPlans += 2
        b.feasiblePlans += (c.result.r0Feasible ? 1 : 0) + (c.result.r1Feasible ? 1 : 0)
        if (c.result.r0Feasible && c.result.r1Feasible) b.validPairs++
      }
      if (c.result.perfWarn) b.perfWarn++
      if (c.result.status === 'partial') b.partial++
    } else if (c.result.status === 'infeasible' || c.result.status === 'unexpected_ok') b.infeasible++
    else if (c.result.status === 'not_applicable') b.notApplicable++
    else if (c.result.status === 'error') b.errors++
  }

  const staticOk = cases.filter((c) => c.kind === 'static' && c.result.status === 'ok')
  const anomalyCases = cases.filter((c) => c.kind === 'anomaly' || c.kind === 'anomaly-consecutive' || c.kind === 'anomaly-boundary')
  const anomalyOk = anomalyCases.filter((c) => c.result.status === 'ok' || c.result.status === 'partial')

  // 指标仅纳入对应方案可行的结果
  const metricBlock = {
    makespan: {
      A: stat(staticOk.filter((c) => c.result.feasible.A).map((c) => c.result.makespan.A)),
      B: stat(staticOk.filter((c) => c.result.feasible.B).map((c) => c.result.makespan.B)),
      C: stat(staticOk.filter((c) => c.result.feasible.C).map((c) => c.result.makespan.C))
    },
    onlineStopTotal: {
      A: stat(staticOk.filter((c) => c.result.feasible.A).map((c) => c.result.onlineStopTotal.A)),
      B: stat(staticOk.filter((c) => c.result.feasible.B).map((c) => c.result.onlineStopTotal.B)),
      C: stat(staticOk.filter((c) => c.result.feasible.C).map((c) => c.result.onlineStopTotal.C))
    },
    computeTimeMs: stat(staticOk.map((c) => c.result.computeTimeMs))
  }

  function improve(pairs) {
    let improved = 0
    let tie = 0
    let worse = 0
    let sumFrom = 0
    let sumTo = 0
    const perCase = []
    for (const p of pairs) {
      sumFrom += p.from
      sumTo += p.to
      const d = p.from - p.to
      if (d > 0.05) improved++
      else if (d < -0.05) worse++
      else tie++
      perCase.push(p.from ? ((p.from - p.to) / p.from) * 100 : 0)
    }
    return { n: pairs.length, improved, tie, worse, weightedPct: sumFrom ? round2(((sumFrom - sumTo) / sumFrom) * 100) : null, perCaseMeanPct: perCase.length ? round2(perCase.reduce((s, x) => s + x, 0) / perCase.length) : null }
  }
  const ab = staticOk.filter((c) => c.result.feasible.A && c.result.feasible.B).map((c) => ({ from: c.result.makespan.A, to: c.result.makespan.B }))
  const bc = staticOk.filter((c) => c.result.feasible.B && c.result.feasible.C).map((c) => ({ from: c.result.makespan.B, to: c.result.makespan.C }))
  const ac = staticOk.filter((c) => c.result.feasible.A && c.result.feasible.C).map((c) => ({ from: c.result.makespan.A, to: c.result.makespan.C }))

  let rImproved = 0
  let rTie = 0
  let rWorse = 0
  let r0Fallback = 0
  for (const c of anomalyOk) {
    if (!c.result.r1Feasible || !c.result.r0Feasible) continue
    const d = c.result.r0Makespan - c.result.r1Makespan
    if (d > 0.05) rImproved++
    else if (d < -0.05) rWorse++
    else rTie++
    if (c.result.usedR0Fallback) r0Fallback++
  }

  return {
    byCategory: Object.values(byCategory),
    metricBlock,
    improvement: { AtoB: improve(ab), BtoC: improve(bc), AtoC: improve(ac) },
    onlineStopComparison: { AtoC: { A: metricBlock.onlineStopTotal.A.mean, C: metricBlock.onlineStopTotal.C.mean, delta: round2((metricBlock.onlineStopTotal.C.mean || 0) - (metricBlock.onlineStopTotal.A.mean || 0)) }, note: '总历时减少不代表停线缩短；停线合计可能上升或下降，属目标取舍。' },
    anomaly: {
      cases: anomalyCases.length,
      ok: anomalyOk.length,
      partial: anomalyOk.filter((c) => c.result.status === 'partial').length,
      improved: rImproved,
      tie: rTie,
      worse: rWorse,
      r0FallbackCount: r0Fallback,
      r0Makespan: stat(anomalyOk.map((c) => c.result.r0Makespan)),
      r1Makespan: stat(anomalyOk.map((c) => c.result.r1Makespan)),
      r1Remaining: stat(anomalyOk.map((c) => c.result.r1Remaining)),
      computeTimeMs: stat(anomalyOk.map((c) => c.result.computeTimeMs))
    }
  }
}

// ---------------------------------------------------------------------------
// 入口
// ---------------------------------------------------------------------------

function runEvaluation({ orders, simData, sets, categories, seed = CATALOG_SEED, usage, note, strategyOverride = null }) {
  const sink = usageSink || defaultUsageSink
  if (!usageSink) {
    try {
      const persisted = readDefaultUsage()
      // 求解前确认可写并补记历史；此时不登记本次案例为已运行。
      store.writeJSON(USAGE_FILE, persisted)
      usage = { ...persisted, ...usage, fingerprints: Array.from(new Set([...persisted.fingerprints, ...((usage && usage.fingerprints) || [])])) }
    } catch (error) {
      throw usageFailure(error, null)
    }
  }
  const byId = new Map(orders.map((o) => [o.order, o]))
  const usedFpAll = [...(usage && usage.fingerprints ? usage.fingerprints : []), ...HISTORICAL_RESERVED_USED_FP]
  const catalog = buildCaseCatalog(orders, usedFpAll)
  const { selected, effectiveSets: effective, unknownSets: unknown, excludedReserved } = selectCases(catalog, { sets, categories, usage })

  const results = []
  for (const entry of selected) {
    const withSeed = { ...entry, input: { orders: entry.orders, resources: entry.resources || 'normal', anomaly: entry.anomaly || null, seed } }
    let result
    try {
      if (entry.kind === 'static') result = runStaticCase(entry, byId, seed, strategyOverride)
      else if (entry.kind === 'infeasible') result = runInfeasibleCase(entry, byId, seed)
      else result = runAnomalyCase(entry, byId, seed)
    } catch (e) {
      result = { status: 'error', reason: e.message, changeoverInstances: 0, anomalyInjections: 0 }
    }
    results.push({ id: entry.id, set: entry.set, group: entry.group, category: entry.category, kind: entry.kind, fingerprint: entry.fingerprint, input: withSeed.input, result, delta: result.delta || null })
  }

  const changeoverInstances = results.reduce((s, r) => s + (r.result.changeoverInstances || 0), 0)
  const anomalyInjections = results.reduce((s, r) => s + (r.result.anomalyInjections || 0), 0)
  const uniqueBaselineCount = new Set(results.map((r) => r.group)).size
  const usedFingerprints = results.map((r) => r.fingerprint)

  const report = {
    runId: `eval-${new Date().toISOString().replace(/[:.]/g, '')}`,
    modelVersion: sim.MODEL_VERSION,
    seed,
    catalogSeed: CATALOG_SEED,
    generatedAt: new Date().toISOString(),
    runtime: `Node.js ${process.version}`,
    inputDigest: `orders=${orders.length};sets=${effective.join('+')};seed=${seed}`,
    searchCap: { strategyC: '订单排列 × 40 组离线优先级随机起点', recoveryR1: '订单排列 × 30 组随机起点 + R0 基线', perfWarnMs: PERF_WARN_MS, note: '4000ms 为性能警戒线（仅统计标记，不中断求解），非求解预算上限' },
    requestedSets: Array.isArray(sets) && sets.length ? sets.slice() : DEFAULT_SETS.slice(),
    unknownSets: unknown,
    effectiveSets: effective,
    caseCount: results.length,
    changeoverInstanceCount: changeoverInstances,
    uniqueBaselineCount,
    anomalyInjectionCount: anomalyInjections,
    excludedReserved,
    reservedRun: effective.includes('reserved'),
    usedFingerprints,
    sets: ALL_SETS.reduce((a, s) => ({ ...a, [s]: results.filter((r) => r.set === s).length }), {}),
    setUsage: { frozen: '已使用评测集（此前 verify 与默认页面已运行过）', reserved: '保留集（参数定稿后使用；已使用指纹受保护，纯筛选不记为执行）', dev: '开发集（无机器学习环节，故不称训练集）', validation: '验证集' },
    summary: summarize(results),
    cases: results,
    declaration: '评测结果均为仿真结果，不代表工厂实测；OEE 待验证。',
    note: note || '缺省仅运行 dev+validation；reserved 保留集不默认运行。'
  }
  try {
    sink({ runId: report.runId, at: report.generatedAt, effectiveSets: effective, fingerprints: usedFingerprints, reservedRun: report.reservedRun })
  } catch (error) {
    throw usageFailure(error, report)
  }
  return report
}

// 统一记账出口：真实求解（含候选搜索、验证、失败与回退）都必须经此登记；
// 纯筛选不调用。写入失败按 v4.2.2 补丁处理，绝不静默漏记。
function emitUsage(record, report) {
  const sink = usageSink || defaultUsageSink
  try {
    sink(record)
    return true
  } catch (error) {
    throw usageFailure(error, report || null)
  }
}

module.exports = { runEvaluation, buildCaseCatalog, selectCases, setUsageSink, emitUsage, CATALOG_SEED, PERF_WARN_MS, DEFAULT_SETS, ALL_SETS, HISTORICAL_RESERVED_USED, HISTORICAL_RESERVED_USED_FP, RETIRED_UNUSED_RESERVED }
