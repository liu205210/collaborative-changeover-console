'use strict'

/**
 * 异常注入、动态重排与决策回放引擎（规则决策模式）
 * -------------------------------------------------------------------------
 * 设计要点：
 *  - 已完成任务的实际起止/人员/资源/结果冻结不可修改。
 *  - 未开始任务不得安排到事件时刻之前（release = eventTime）。
 *  - 在制任务保留已执行片段，剩余工作按连续续作或重做处理。
 *  - 发生故障的资源在其窗口内不接受有效加工。
 *  - 只使用事件时刻已获知的信息；连续事件基于上一事件后的最新执行状态。
 *  - 相同输入 + 事件序列 + 随机种子可复现；重复事件去重。
 *  - 同一时刻：完成时刻 = eventTime 的任务视为已完成，事件随后生效。
 */

const { buildTaskSet, DEFAULT_PERSONNEL, DEFAULT_EXCLUSIVE, SKILL_LABELS, MODEL_VERSION } = require('./simulation')
const sched = require('./scheduler')

const EPS = 1e-9
const ONLINE_KEYS = new Set(['line_clear', 'tooling_switch', 'param_apply', 'fai_produce', 'resume'])

function r2(x) {
  return Math.round(x * 100) / 100
}

// ---------------------------------------------------------------------------
// 会话创建
// ---------------------------------------------------------------------------

function digestOfOrders(orders) {
  return 'in-' + orders.map((o) => `${o.order}:${o.qty}:${o.bomLines}`).join('_') + '@' + MODEL_VERSION
}

function createSession({ orders, seed = 20261005, personnel, exclusive, equipment }) {
  const built = buildTaskSet(orders, { personnel, exclusive })
  const equip = equipment !== undefined ? equipment : built.equipment
  let plan = null
  let infeasible = false
  let reason = null
  try {
    plan = sched.buildSchedules({ tasks: built.tasks, personnel: built.personnel, exclusive: built.exclusive, equipment: equip, ordersInOrder: orders.map((o) => o.order), seed })
  } catch (e) {
    infeasible = true
    reason = e.message
  }
  const baseEntries = plan ? plan.C.entries.map((e) => ({ ...e, kind: 'plan', result: 'ok' })) : []
  return {
    sessionId: `sim-${Date.now().toString(36)}`,
    modelVersion: MODEL_VERSION,
    seed,
    inputDigest: digestOfOrders(orders),
    orderIds: orders.map((o) => o.order),
    orders,
    tasks: built.tasks,
    personnel: built.personnel,
    exclusive: built.exclusive,
    equipment: equip,
    infeasible,
    infeasibleReason: reason,
    clock: 0,
    ledger: { resourceBlocks: {}, personBlocks: {}, lineBlocks: [], outages: [], absences: [] },
    basePlan: plan ? { mode: 'C', modeName: plan.C.modeName, description: plan.C.description, entries: baseEntries, metrics: plan.C.metrics } : { mode: 'C', modeName: '不可行', description: reason, entries: [], metrics: null },
    actualEntries: baseEntries.map((e) => ({ ...e })),
    events: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
}

function cloneBundle(bundle) {
  return JSON.parse(JSON.stringify(bundle))
}

function mergeLedger(target, extra) {
  const out = {
    resourceBlocks: { ...target.resourceBlocks },
    personBlocks: { ...target.personBlocks },
    lineBlocks: (target.lineBlocks || []).slice(),
    outages: (target.outages || []).slice(),
    absences: (target.absences || []).slice()
  }
  for (const [k, v] of Object.entries(extra.resourceBlocks || {})) out.resourceBlocks[k] = (out.resourceBlocks[k] || []).concat(v)
  for (const [k, v] of Object.entries(extra.personBlocks || {})) out.personBlocks[k] = (out.personBlocks[k] || []).concat(v)
  out.lineBlocks = out.lineBlocks.concat(extra.lineBlocks || [])
  out.outages = out.outages.concat(extra.outages || [])
  out.absences = out.absences.concat(extra.absences || [])
  return out
}

// ---------------------------------------------------------------------------
// 事件签名与适用性
// ---------------------------------------------------------------------------

function eventSignature(ev) {
  const tgt = ev.target || (ev.targets || []).join('+')
  return [ev.type, tgt, r2(ev.at), r2(ev.duration || 0), r2(ev.to || 0), ev.policy || '', ev.redo ? 'redo' : ''].join('|')
}

function findEntry(entries, id) {
  return entries.find((e) => e.id === id)
}

function validateEvent(bundle, ev) {
  const entries = bundle.actualEntries
  if (ev.type === 'agv_delay') {
    const e = findEntry(entries, ev.target)
    if (!e) return { applicable: false, reason: `未找到配送任务 ${ev.target}` }
    if (e.key !== 'material_deliver') return { applicable: false, reason: `目标 ${ev.target} 不是配送任务` }
    if (e.end <= ev.at + EPS) return { applicable: false, reason: `配送任务 ${ev.target} 在 ${ev.at} 分钟已完成，已完成配送不能被再次延迟` }
    return { applicable: true }
  }
  if (ev.type === 'person_absence') {
    const ids = ev.targets && ev.targets.length ? ev.targets : [ev.target]
    for (const id of ids) {
      const p = bundle.personnel.find((x) => x.id === id)
      if (!p) return { applicable: false, reason: `未找到人员 ${id}` }
    }
    const to = ev.to != null ? ev.to : ev.at + (ev.duration || 30)
    if (to <= ev.at) return { applicable: false, reason: '人员不可用时段无效（结束不晚于开始）' }
    return { applicable: true }
  }
  if (ev.type === 'equipment_failure') {
    const eqIds = (bundle.equipment || []).map((e) => e.id)
    if (!['LINE-01', 'CAL-01', ...eqIds].includes(ev.target)) {
      return { applicable: false, reason: `不支持对资源 ${ev.target} 注入故障（支持产线 LINE-01、校准台 CAL-01 或已登记设备）` }
    }
    const to = ev.to != null ? ev.to : ev.at + (ev.duration || 15)
    if (to <= ev.at) return { applicable: false, reason: '故障窗口无效（恢复不晚于发生）' }
    return { applicable: true }
  }
  if (ev.type === 'fai_fail') {
    const order = ev.target
    if (!bundle.orderIds.includes(order)) return { applicable: false, reason: `未找到订单 ${order}` }
    const rel = findEntry(entries, `${order}::quality_release`)
    if (rel && rel.end <= ev.at + EPS) {
      return { applicable: false, reason: `订单 ${order} 已于 ${rel.end} 分钟质量放行，首件不合格事件不适用，且不倒改历史` }
    }
    return { applicable: true }
  }
  return { applicable: false, reason: `未知事件类型 ${ev.type}` }
}

// ---------------------------------------------------------------------------
// 事件时刻快照
// ---------------------------------------------------------------------------

function snapshotAt(bundle, at) {
  const entries = bundle.actualEntries
  const done = entries.filter((e) => e.end <= at + EPS)
  const running = entries.filter((e) => e.start < at - EPS && e.end > at + EPS)
  const pending = entries.filter((e) => e.start >= at - EPS)
  const locks = entries
    .filter((e) => ONLINE_KEYS.has(e.key))
    .reduce((acc, e) => {
      if (!acc[e.order]) acc[e.order] = { start: Infinity, end: -Infinity }
      acc[e.order].start = Math.min(acc[e.order].start, e.start)
      acc[e.order].end = Math.max(acc[e.order].end, e.end)
      return acc
    }, {})
  let activeOrder = null
  for (const [order, w] of Object.entries(locks)) {
    if (w.start <= at + EPS && w.end > at + EPS) activeOrder = order
  }
  const quality = bundle.orderIds.map((oid) => {
    const rel = findEntry(entries, `${oid}::quality_release`)
    const insp = findEntry(entries, `${oid}::fai_inspect`)
    return {
      order: oid,
      faiStatus: insp && insp.end <= at + EPS ? (insp.result === 'fail' ? '不合格' : '合格') : '待检验',
      released: !!(rel && rel.end <= at + EPS)
    }
  })
  return {
    at: r2(at),
    done: done.map((e) => e.id),
    running: running.map((e) => ({ id: e.id, start: e.start, end: e.end, assigneeId: e.assigneeId, assigneeName: e.assigneeName })),
    pending: pending.map((e) => e.id),
    activeOrder,
    locks,
    quality,
    lockProtected: activeOrder ? `订单 ${activeOrder} 在线换产中，产线配置锁定` : '当前无在线换产锁定'
  }
}

// ---------------------------------------------------------------------------
// 构造恢复调度单元与资源约束
// ---------------------------------------------------------------------------

function buildRecoveryInput(bundle, ev, snap) {
  const at = ev.at
  const units = []
  const doneEnd = new Map()
  const frozen = []

  for (const e of bundle.actualEntries) {
    if (e.end <= at + EPS) {
      // 已完成，冻结
      doneEnd.set(e.id, e.end)
      frozen.push({ ...e, kind: 'actual', status: 'done' })
    } else if (e.start < at - EPS && e.end > at + EPS) {
      // 在制：保留片段 [start, at]（独立记录），剩余后续作
      // 与排程记录统一为 0.01 分钟精度，不额外补足至 0.1 分钟。
      const remaining = r2(e.end - at)
      frozen.push({ ...e, id: `${e.id}::seg@${at}`, kind: 'actual-fragment', status: 'paused', start: e.start, end: at, segStart: e.start, segEnd: at, originId: e.id })
      units.push({
        ...e,
        duration: remaining,
        release: at,
        remainingFrom: remaining,
        isContinuation: true,
        originalId: e.id
      })
    } else {
      units.push({ ...e, duration: e.duration, release: at, isContinuation: false })
    }
  }

  // 资源不可用约束：从会话累计台账开始，叠加本次事件（累计故障/缺席/占用）
  const personBlocks = new Map(Object.entries(bundle.ledger?.personBlocks || {}).map(([k, v]) => [k, v.slice()]))
  const resourceBlocks = new Map(Object.entries(bundle.ledger?.resourceBlocks || {}).map(([k, v]) => [k, v.slice()]))
  const lineBlocks = (bundle.ledger?.lineBlocks || []).slice()
  const absenceInfo = []
  const newOutages = []
  const newAbsences = []
  let faiFailOrder = null

  if (ev.type === 'person_absence') {
    const to = ev.to != null ? ev.to : at + (ev.duration || 30)
    const ids = ev.targets && ev.targets.length ? ev.targets : [ev.target]
    const policy = ev.policy || 'finish_current'
    for (const id of ids) {
      const p = bundle.personnel.find((x) => x.id === id)
      const runningByPerson = snap.running.find((r) => r.assigneeId === id)
      let from = ev.at
      if (runningByPerson && policy === 'finish_current') from = Math.max(ev.at, runningByPerson.end)
      addBlock(personBlocks, id, [from, to])
      absenceInfo.push({
        person: p ? p.name : id,
        window: `${r2(from)} → ${r2(to)}`,
        policy: policy === 'finish_current' ? '完成当前作业后离岗' : '暂停并交接',
        note: runningByPerson ? `影响在制任务 ${runningByPerson.id}，保留其已执行片段，历史执行人不变` : '影响未执行任务，按技能约束重新分配'
      })
      newAbsences.push({ person: id, window: [from, to], policy })
    }
  }

  if (ev.type === 'agv_delay') {
    const target = units.find((u) => u.id === ev.target)
    const delay = ev.duration || 15
    // 延迟只计一次：作为该配送任务的新增有效工时（任务本身占用 AGV 与物料员），
    // 不再叠加独立的资源阻塞窗口，避免 15 分钟被重复计时。
    if (target) {
      target.duration = r2(target.duration + delay)
      target.addedMin = (target.addedMin || 0) + delay
    }
    absenceInfo.push({
      resource: 'AGV-01',
      window: `${r2(at)} → ${r2(at + delay)}`,
      policy: 'AGV 与物料员随该配送任务一并占用（计入任务工时，只计一次）',
      note: `配送任务 ${ev.target} 顺延 ${delay} 分钟，后续依赖物料到线的任务相应顺延`
    })
    newOutages.push({ resource: 'AGV-01', window: [at, at + delay], type: 'agv_delay' })
  }

  if (ev.type === 'equipment_failure') {
    const to = ev.to != null ? ev.to : at + (ev.duration || 15)
    if (ev.target === 'LINE-01') lineBlocks.push([at, to])
    else addBlock(resourceBlocks, ev.target, [at, to])
    const redo = !!ev.redo
    // 受影响的在制任务：保留片段，续作或重做
    for (const u of units) {
      const usesLine = ev.target === 'LINE-01' && u.stage === 'line'
      const usesExclusive = u.exclusive === ev.target
      const usesEquipment = u.equipment === ev.target
      if (!usesLine && !usesExclusive && !usesEquipment) continue
      if (u.isContinuation && redo) {
        const base = bundle.tasks.find((t) => t.id === u.originalId)
        u.duration = r2((base && base.duration) || u.duration + u.remainingFrom)
        u.redo = true
      }
      u.release = Math.max(u.release, to)
      if (u.isContinuation) u.failurePolicy = redo ? '重做' : '暂停后续作'
    }
    absenceInfo.push({
      resource: ev.target,
      window: `${r2(at)} → ${r2(to)}`,
      policy: redo ? '受影响在制任务重做' : '受影响在制任务暂停后续作',
      note: '故障窗口内不安排依赖该设备的有效加工；故障前实际片段保留；其他未受影响任务可继续'
    })
    newOutages.push({ resource: ev.target, window: [at, to], type: 'equipment_failure' })
  }

  if (ev.type === 'fai_fail') {
    const order = ev.target
    // 移除原 quality_release 依赖，改为返工→复检→放行
    const reworkId = `${order}::rework`
    const recheckId = `${order}::recheck`
    const orderTasks = bundle.tasks.filter((t) => t.order === order)
    const metrics = orderTasks.length
      ? {
          bomLines: orderTasks[0].bomLines || 0,
          materialTypes: orderTasks[0].materialTypes || 0,
          faces: orderTasks[0].faces || [],
          qty: orderTasks[0].qty || 0
        }
      : { faces: [] }
    const reworkDur = r2(2 + 0.4 * ((metrics.faces && metrics.faces.length) || 1))
    // 需要在 units 中插入返工与复检
    units.push({
      id: reworkId,
      key: 'rework',
      name: '返工与重新试制(在线)',
      phase: '首件检验与质量放行',
      order,
      product: findEntry(bundle.actualEntries, `${order}::fai_produce`)?.product || '',
      skill: 'operator',
      skillLabel: SKILL_LABELS.operator,
      exclusive: 'LINE-01',
      equipment: 'MNT-01',
      equipmentAlternatives: ['MNT-02'],
      mode: 'online',
      stage: 'line',
      deps: [`${order}::fai_inspect`],
      duration: reworkDur,
      release: at,
      isContinuation: false,
      kind: 'rework'
    })
    units.push({
      id: recheckId,
      key: 'recheck',
      name: '复检(离线)',
      phase: '首件检验与质量放行',
      order,
      product: '',
      skill: 'quality',
      skillLabel: SKILL_LABELS.quality,
      exclusive: null,
      equipment: 'ICT-01',
      equipmentAlternatives: [],
      mode: 'offline',
      stage: 'post',
      deps: [reworkId],
      duration: 3,
      release: at,
      isContinuation: false,
      kind: 'recheck'
    })
    for (const u of units) {
      if (u.id === `${order}::quality_release`) u.deps = [recheckId]
    }
    // 标记首件检验结果为不合格（若尚未完成，则在完成时判定失败）
    // 不修改输入会话：失败结果在合并时写入新会话的执行台账
    faiFailOrder = order
    absenceInfo.push({
      order,
      window: `检验完成时（${r2(at)} 起生效）`,
      policy: '返工 → 复检 → 质量放行',
      note: `首件不合格，增加返工任务（${reworkDur} 分钟）与复检（3 分钟）；复检合格前不得放行或恢复生产，产线配置继续受保护`
    })
  }

  return { units, frozen, doneEnd, personBlocks, resourceBlocks, lineBlocks, absenceInfo, newOutages, newAbsences, faiFailOrder }
}

function addBlock(map, key, interval) {
  if (!map.has(key)) map.set(key, [])
  map.get(key).push(interval)
}

// ---------------------------------------------------------------------------
// 恢复调度
// ---------------------------------------------------------------------------

function prepareBanks(bundle, personBlocks, resourceBlocks, frozen, doneEnd) {
  const banks = sched.makeBanks(bundle.personnel, bundle.exclusive, bundle.equipment)
  for (const [pid, blocks] of personBlocks.entries()) {
    for (const arr of banks.skills.values()) {
      const p = arr.find((x) => x.id === pid)
      if (p) for (const b of blocks) p.intervals.push([b[0], b[1]])
    }
  }
  for (const [rid, blocks] of resourceBlocks.entries()) {
    const ex = banks.exclusiveBanks.get(rid)
    if (ex) for (const b of blocks) ex.intervals.push([b[0], b[1]])
  }
  return banks
}

function scheduleRecovery(bundle, input, sequence, prepPriority, at) {
  const { units, doneEnd, personBlocks, resourceBlocks, lineBlocks } = input
  const banks = prepareBanks(bundle, personBlocks, resourceBlocks, input.frozen, doneEnd)

  const taskById = new Map(units.map((u) => [u.id, { ...u }]))
  const endOf = (id) => {
    if (taskById.has(id) && taskById.get(id).end != null) return taskById.get(id).end
    if (doneEnd.has(id)) return doneEnd.get(id)
    return 0
  }

  const prep = units.filter((u) => u.stage === 'prep')
  const prepEntries = sched.schedulePrep(prep, prepPriority, banks, at)
  for (const e of prepEntries) {
    const t = taskById.get(e.id)
    if (t) t.end = e.end
  }

  const bandEntries = scheduleBandChain(taskById, sequence, banks, at, lineBlocks, endOf)
  return { entries: prepEntries.concat(bandEntries), banks }
}

function scheduleBandChain(taskById, sequence, banks, at, lineBlocks, endOf) {
  const entries = []
  const blocks = (lineBlocks || []).slice().sort((a, b) => a[0] - b[0])
  let cursor = at

  function avoid(t, dur) {
    let x = t
    let guard = 0
    while (guard++ < 50) {
      const hit = blocks.find(([a, b]) => x < b - EPS && x + dur > a + EPS)
      if (!hit) return x
      x = hit[1]
    }
    return x
  }
  function online(task, lower) {
    if (!task) return lower
    let t = avoid(Math.max(lower, at), task.duration)
    for (let i = 0; i < 80; i++) {
      const eq = sched.earliestEquipment(banks, task, t, task.duration)
      const cur = Math.max(t, eq.start)
      const p = sched.earliestPersonForSkill(banks, task.skill, cur, task.duration)
      if (!p) return lower
      let start = Math.max(cur, p.start)
      const adj = avoid(start, task.duration)
      if (adj > start + EPS) {
        t = adj
        continue
      }
      const eq2 = sched.earliestEquipment(banks, task, start, task.duration)
      if (eq2.start > start + EPS) {
        t = eq2.start
        continue
      }
      const p2 = sched.earliestPersonForSkill(banks, task.skill, start, task.duration)
      if (p2 && p2.start <= start + EPS) {
        p2.person.intervals.push([start, start + task.duration])
        if (eq2.id) banks.exclusiveBanks.get(eq2.id).intervals.push([start, start + task.duration])
        task.end = start + task.duration
        entries.push(mkRec(task, start, p2.person, eq2.id))
        return task.end
      }
      t = p2 ? p2.start : start + task.duration
    }
    return lower
  }
  function offline(task, lower, deps) {
    if (!task) return lower
    let L = Math.max(lower, at)
    for (const d of deps) L = Math.max(L, endOf(d))
    const eq = sched.earliestEquipment(banks, task, L, task.duration)
    L = Math.max(L, eq.start)
    const p = sched.earliestPersonForSkill(banks, task.skill, L, task.duration)
    const start = Math.max(L, p.start)
    const eq2 = sched.earliestEquipment(banks, task, start, task.duration)
    const begin = Math.max(start, eq2.start)
    p.person.intervals.push([begin, begin + task.duration])
    if (eq2.id) banks.exclusiveBanks.get(eq2.id).intervals.push([begin, begin + task.duration])
    task.end = begin + task.duration
    entries.push(mkRec(task, begin, p.person, eq2.id))
    return task.end
  }

  for (const order of sequence) {
    const get = (k) => taskById.get(`${order}::${k}`)
    if (![get('line_clear'), get('tooling_switch'), get('param_apply'), get('fai_produce'), get('resume')].some(Boolean) && !get('fai_inspect')) {
      continue
    }
    let t = cursor
    // 在线链条（若某步已完成则跳过，其 end 由 endOf 提供）
    t = online(get('line_clear'), Math.max(t, endOf(`${order}::tooling_prep`), endOf(`${order}::material_deliver`)))
    t = online(get('tooling_switch'), Math.max(t, endOf(`${order}::tooling_prep`), endOf(`${order}::material_deliver`), endOf(`${order}::line_clear`)))
    t = online(get('param_apply'), Math.max(t, endOf(`${order}::param_prepare`), endOf(`${order}::tooling_switch`)))
    t = online(get('fai_produce'), Math.max(t, endOf(`${order}::param_apply`)))
    // 质量链：首检 →（返工→复检，按剩余节点与已完成状态分别推进）→ 放行
    t = offline(get('fai_inspect'), t, [`${order}::fai_produce`])
    if (get('rework')) t = online(get('rework'), Math.max(t, endOf(`${order}::fai_inspect`)))
    const recheckId = `${order}::recheck`
    const hasRecheck = !!get('recheck') || endOf(recheckId) > 0
    if (get('recheck')) t = offline(get('recheck'), t, [`${order}::rework`])
    t = offline(get('quality_release'), t, hasRecheck ? [recheckId] : [`${order}::fai_inspect`])
    t = online(get('resume'), Math.max(t, endOf(`${order}::quality_release`), hasRecheck ? endOf(recheckId) : 0))
    cursor = Math.max(cursor, t)
  }
  return entries
}

function mkRec(task, start, person, eqId) {
  return {
    id: task.id,
    key: task.key,
    name: task.name,
    phase: task.phase,
    order: task.order,
    product: task.product,
    skill: task.skill,
    skillLabel: task.skillLabel,
    exclusive: task.exclusive,
    equipment: eqId || task.equipment || null,
    equipmentAlternatives: task.equipmentAlternatives || [],
    mode: task.mode,
    stage: task.stage,
    deps: task.deps,
    release: task.release || 0,
    duration: r2(task.duration),
    assigneeId: person.id,
    assigneeName: person.name,
    start: r2(start),
    end: r2(start + task.duration),
    depEarliest: r2(Math.max(task.release || 0, 0)),
    resourceWait: 0,
    delayedByResource: false,
    kind: task.kind || 'recovery'
  }
}

// ---------------------------------------------------------------------------
// 恢复指标与验证
// ---------------------------------------------------------------------------

function recoveryTaskList(bundle, input, extraTasks) {
  // 供验证器使用的“任务定义集合”：已完成任务 + 恢复单元 + 返工/复检
  const tasks = []
  for (const e of input.frozen) {
    tasks.push({
      id: e.id,
      key: e.key,
      name: e.name,
      order: e.order,
      skill: e.skill,
      skillLabel: e.skillLabel,
      exclusive: e.exclusive,
      deps: e.deps || [],
      duration: e.duration,
      stage: e.stage
    })
  }
  for (const u of input.units) {
    tasks.push({
      id: u.id,
      key: u.key,
      name: u.name,
      order: u.order,
      skill: u.skill,
      skillLabel: u.skillLabel,
      exclusive: u.exclusive,
      deps: u.deps || [],
      duration: u.duration,
      stage: u.stage
    })
  }
  for (const t of extraTasks || []) tasks.push(t)
  return tasks
}

function computeRecoveryMetrics(entries, frozen, personnel, exclusive, baseMakespan, at, originalEntries, timing) {
  const all = frozen.concat(entries)
  const makespan = all.reduce((m, e) => Math.max(m, e.end), 0)
  const online = all.filter((e) => e.stage === 'line' && ONLINE_KEYS.has(e.key))
  const stopByOrder = {}
  for (const e of online) {
    if (!stopByOrder[e.order]) stopByOrder[e.order] = { start: Infinity, end: -Infinity }
    stopByOrder[e.order].start = Math.min(stopByOrder[e.order].start, e.start)
    stopByOrder[e.order].end = Math.max(stopByOrder[e.order].end, e.end)
  }
  const onlineStopTotal = r2(Object.values(stopByOrder).reduce((s, w) => s + (w.end - w.start), 0))
  // 计划调整数量：恢复条目相对原计划（同 id）开始时间或执行人变化 + 新增任务
  const origById = new Map((originalEntries || []).map((e) => [e.id, e]))
  let adjustments = 0
  for (const e of entries) {
    const o = origById.get(e.id)
    if (!o) {
      adjustments++
      continue
    }
    if (Math.abs(o.start - e.start) > 0.05 || o.assigneeId !== e.assigneeId) adjustments++
  }
  const reserveAt = timing ? timing.reserveAt : at
  const triggerAt = timing ? timing.triggerAt : at
  return {
    makespan: r2(makespan),
    reserveAt: r2(reserveAt),
    triggerAt: r2(triggerAt),
    // 实际触发后剩余时间 = 最终完成时间 − 实际触发时刻（唯一可作为“事件后剩余”的口径）
    remainingAfterTrigger: r2(makespan - triggerAt),
    // 从预约时刻到实际触发的等待（仅首件失败存在，其余为 0）
    waitReserveToTrigger: r2(Math.max(0, triggerAt - reserveAt)),
    // 兼容字段，含义为“从预约时刻到完成”，不得当作事件后剩余时间使用
    remainingFromReserve: r2(makespan - reserveAt),
    onlineStopTotal,
    delayVsOriginal: r2(makespan - baseMakespan),
    adjustments,
    completedByEvent: frozen.filter((f) => f.kind === 'actual').length,
    resumedTasks: entries.length
  }
}

function validateRecovery(bundle, input, entries, ev) {
  const at = ev.at
  const violations = []
  const taskById = new Map(bundle.tasks.map((t) => [t.id, t]))
  const roster = new Map(bundle.personnel.map((p) => [p.id, p]))
  const invSet = new Set((bundle.equipment || []).map((x) => x.id))
  const expected = new Map(input.units.map((u) => [u.id, u]))
  const byId = new Map()
  for (const f of input.frozen) byId.set(f.id, f)

  // 1. 完整性、唯一性、来源身份（以独立任务合同 input.units 为准，不信任候选自带字段）
  const seen = new Set()
  let dup = 0
  let extra = 0
  for (const e of entries) {
    if (seen.has(e.id)) dup++
    seen.add(e.id)
    if (!expected.has(e.id)) extra++
    byId.set(e.id, e)
  }
  let missing = 0
  for (const u of input.units) if (!seen.has(u.id)) missing++
  if (missing) violations.push({ type: 'incomplete', detail: `恢复计划缺失 ${missing} 项应执行任务` })
  if (extra) violations.push({ type: 'unknown_task', detail: `恢复计划含 ${extra} 项合同外任务` })
  if (dup) violations.push({ type: 'duplicate_task', detail: `恢复计划含 ${dup} 项重复任务` })

  // 2. 恢复任务不得早于事件时刻
  let notBefore = 0
  for (const e of entries) {
    if (typeof e.start !== 'number' || typeof e.end !== 'number' || !(e.end >= e.start)) {
      notBefore++
      violations.push({ type: 'time_invalid', detail: `${e.id} 起止时间非法` })
    } else if (e.start < at - EPS) {
      notBefore++
      violations.push({ type: 'recovery_before_event', detail: `${e.id} 被安排到事件时刻之前（${e.start} < ${at}）` })
    }
  }

  // 3. 已完成历史不可变
  let historyChanged = 0
  const baseById = new Map(bundle.actualEntries.map((e) => [e.id, e]))
  for (const f of input.frozen) {
    if (f.kind === 'actual-fragment') continue
    const before = baseById.get(f.id)
    if (before && (Math.abs(before.start - f.start) > 1e-6 || Math.abs(before.end - f.end) > 1e-6 || before.assigneeId !== f.assigneeId)) {
      historyChanged++
      violations.push({ type: 'history_changed', detail: `已完成任务 ${f.id} 的实际记录被修改` })
    }
  }

  // 4. 人员存在、技能、班次；设备库存与替代资格；工时与片段守恒；前置依赖（均以名单/合同/台账为准）
  let peopleViol = 0
  let skillViol = 0
  let shiftViol = 0
  let equipViol = 0
  let durationViol = 0
  let depViol = 0
  for (const e of entries) {
    const u = expected.get(e.id)
    if (!u) continue // 合同外任务已在 completeness 计
    const contract = taskById.get(e.id) || u
    const person = roster.get(e.assigneeId)
    if (!person) {
      peopleViol++
      violations.push({ type: 'unknown_person', detail: `${e.id} 指派了名册外人员 ${e.assigneeId}` })
    } else {
      if (contract.skill && person.skill !== contract.skill) {
        skillViol++
        violations.push({ type: 'skill', detail: `${e.id} 人员 ${person.name}（${person.skill}）技能与所需 ${contract.skill} 不匹配` })
      }
      if (Array.isArray(person.shiftWindow) && (e.start < person.shiftWindow[0] - 1e-6 || e.end > person.shiftWindow[1] + 1e-6)) {
        shiftViol++
        violations.push({ type: 'shift', detail: `${e.id} 超出 ${person.name} 班次 [${person.shiftWindow[0]},${person.shiftWindow[1]}]` })
      }
    }
    if (contract.equipment) {
      const ok = e.equipment === contract.equipment || (contract.equipmentAlternatives || []).includes(e.equipment)
      if (!e.equipment || !ok || (invSet.size && !invSet.has(e.equipment))) {
        equipViol++
        violations.push({ type: 'equipment', detail: `${e.id} 设备 ${e.equipment || '无'} 不符合库存/类型/替代资格` })
      }
    }
    // 工时守恒：与真实时间精度匹配（0.01 分钟精度 + 少量舍入），拒绝逐项 shortened
    if (Math.abs(e.end - e.start - u.duration) > 0.05) {
      durationViol++
      violations.push({ type: 'duration_tampered', detail: `${e.id} 实际工时 ${r2(e.end - e.start)} 与应执行 ${u.duration} 不符` })
    }
    // 前置依赖：以“事件转换后的有效任务合同”input.units 的依赖为准（含动态复检依赖），缺失前序也报错
    const effectiveDeps = (u.deps && u.deps.length ? u.deps : contract.deps) || []
    for (const d of effectiveDeps) {
      const de = byId.get(d)
      if (!de) {
        if (!expected.has(d) && !input.frozen.some((f) => f.originId === d || f.id === d)) {
          depViol++
          violations.push({ type: 'missing_predecessor', detail: `${e.id} 的前序 ${d} 缺失` })
        }
      } else if (de.end > e.start + 1e-6) {
        depViol++
        violations.push({ type: 'precedence', detail: `${e.id} 在 ${d} 完成前开始` })
      }
    }
  }

  // 5. 在制片段保留与片段守恒（含本事件合法新增时间）
  let fragmentViol = 0
  for (const f of input.frozen) {
    if (f.kind === 'actual-fragment' && f.segEnd <= f.segStart + EPS) {
      fragmentViol++
      violations.push({ type: 'fragment_invalid', detail: `在制任务 ${f.id} 的已执行片段无效` })
    }
  }
  for (const u of input.units) {
    if (!u.isContinuation || u.redo) continue
    const frag = input.frozen.find((f) => f.originId === u.originalId && Math.abs(f.segEnd - at) < 1e-6)
    const orig = bundle.actualEntries.find((e) => e.id === u.originalId)
    if (frag && orig) {
      const expectedRemain = r2(orig.end - frag.segEnd) + (u.addedMin || 0)
      if (Math.abs(u.duration - expectedRemain) > 0.05) {
        fragmentViol++
        violations.push({ type: 'fragment_conservation', detail: `${u.originalId} 续作时长与剩余不符（${u.duration} vs ${expectedRemain}）` })
      }
    }
  }

  // 6. 资源冲突
  const all = input.frozen.concat(entries)
  const conflict = checkResourceConflicts(all)
  violations.push(...conflict.violations)

  // 7. 累计故障与缺席窗口内无有效加工（仅新恢复任务）
  let blockedWork = 0
  for (const e of entries) {
    for (const b of input.lineBlocks || []) {
      if (e.exclusive === 'LINE-01' && e.start < b[1] - 1e-6 && e.end > b[0] + 1e-6) {
        blockedWork++
        violations.push({ type: 'work_during_failure', detail: `${e.id} 在产线累计故障窗口 [${b[0]},${b[1]}] 内安排加工` })
      }
    }
    for (const b of input.resourceBlocks.get(e.exclusive) || []) {
      if (e.start < b[1] - 1e-6 && e.end > b[0] + 1e-6) {
        blockedWork++
        violations.push({ type: 'work_during_failure', detail: `${e.id} 在资源 ${e.exclusive} 累计故障窗口内安排加工` })
      }
    }
    for (const b of input.resourceBlocks.get(e.equipment) || []) {
      if (e.start < b[1] - 1e-6 && e.end > b[0] + 1e-6) {
        blockedWork++
        violations.push({ type: 'work_during_failure', detail: `${e.id} 在设备 ${e.equipment} 累计故障窗口内安排加工` })
      }
    }
    for (const b of input.personBlocks.get(e.assigneeId) || []) {
      if (e.start < b[1] - 1e-6 && e.end > b[0] + 1e-6) {
        blockedWork++
        violations.push({ type: 'work_during_absence', detail: `${e.id} 在人员缺席窗口内派工` })
      }
    }
  }

  // 8. 产线在线窗口不交叠 + 质量门禁
  let lockViol = 0
  const locks = {}
  for (const e of all) {
    if (!ONLINE_KEYS.has(e.key)) continue
    if (!locks[e.order]) locks[e.order] = { start: Infinity, end: -Infinity }
    locks[e.order].start = Math.min(locks[e.order].start, e.start)
    locks[e.order].end = Math.max(locks[e.order].end, e.end)
  }
  const lockArr = Object.entries(locks)
  for (let i = 0; i < lockArr.length; i++) {
    for (let j = i + 1; j < lockArr.length; j++) {
      const a = lockArr[i][1]
      const b = lockArr[j][1]
      if (a.start < b.end - 1e-6 && b.start < a.end - 1e-6) {
        lockViol++
        violations.push({ type: 'line_lock', detail: `订单 ${lockArr[i][0]} 与 ${lockArr[j][0]} 在线换产窗口交叠` })
      }
    }
  }
  let gateViol = 0
  for (const oid of Array.from(new Set(bundle.orderIds))) {
    const find = (id) => byId.get(id) || input.frozen.find((f) => f.originId === id || f.id === id)
    const rel = find(`${oid}::quality_release`)
    const res = find(`${oid}::resume`)
    const insp = find(`${oid}::fai_inspect`)
    const recheck = find(`${oid}::recheck`)
    const hasRecheck = !!recheck || !!expected.get(`${oid}::recheck`)
    // 质量失败状态来自“事件转换后的有效合同”（本次首件失败事件写入的 faiFailOrder / 复检单元），
    // 不能只依赖事件前快照是否已写 fail。
    const orderFailed = (insp && insp.result === 'fail') || input.faiFailOrder === oid || hasRecheck
    if (orderFailed) {
      if (!hasRecheck) {
        gateViol++
        violations.push({ type: 'quality_gate', detail: `订单 ${oid} 首件不合格但无复检任务` })
      } else if (rel && recheck && rel.start < recheck.end - 1e-6) {
        gateViol++
        violations.push({ type: 'quality_gate', detail: `订单 ${oid} 质量放行早于复检完成` })
      }
    }
    if (rel && res && rel.end > res.start + 1e-6) {
      gateViol++
      violations.push({ type: 'quality_gate', detail: `订单 ${oid} 恢复生产早于质量放行` })
    }
  }

  const checks = [
    { name: '恢复任务完整性与唯一性', status: missing + extra + dup === 0 ? 'pass' : 'fail', detail: missing + extra + dup === 0 ? `合同 ${input.units.length} 项任务完整且无重复` : `缺失${missing}/多余${extra}/重复${dup}`, violations: missing + extra + dup },
    { name: '恢复任务不早于事件时刻', status: notBefore === 0 ? 'pass' : 'fail', detail: notBefore === 0 ? `全部恢复任务均不早于 ${at} 分钟` : `${notBefore} 项时间非法或穿越事件时刻`, violations: notBefore },
    { name: '已完成历史不可变', status: historyChanged === 0 ? 'pass' : 'fail', detail: historyChanged === 0 ? `${input.frozen.filter((f) => f.kind === 'actual').length} 项已完成记录保持不变` : `${historyChanged} 项历史被修改`, violations: historyChanged },
    { name: '人员存在·技能·班次', status: peopleViol + skillViol + shiftViol === 0 ? 'pass' : 'fail', detail: peopleViol + skillViol + shiftViol === 0 ? '人员均在名册内且技能班次匹配' : `未知人员${peopleViol}/技能${skillViol}/班次${shiftViol}`, violations: peopleViol + skillViol + shiftViol },
    { name: '设备库存成员/替代资格', status: equipViol === 0 ? 'pass' : 'fail', detail: equipViol === 0 ? '设备均在库存内且符合类型与替代资格' : `${equipViol} 处设备违规`, violations: equipViol },
    { name: '工时与片段守恒', status: durationViol + fragmentViol === 0 ? 'pass' : 'fail', detail: durationViol + fragmentViol === 0 ? '候选工时与应执行工时一致，在制片段守恒' : `工时${durationViol}/片段${fragmentViol}`, violations: durationViol + fragmentViol },
    { name: '恢复前置依赖', status: depViol === 0 ? 'pass' : 'fail', detail: depViol === 0 ? '恢复任务顺序满足前置依赖' : `${depViol} 处依赖违例`, violations: depViol },
    { name: '资源占用与冲突', status: conflict.violations.length === 0 ? 'pass' : 'fail', detail: conflict.violations.length === 0 ? '人员与独占资源无重叠占用' : `${conflict.violations.length} 处冲突`, violations: conflict.violations.length },
    { name: '累计故障/缺席窗口内无有效加工', status: blockedWork === 0 ? 'pass' : 'fail', detail: blockedWork === 0 ? '累计故障与缺席窗口内未安排加工' : `${blockedWork} 项违规`, violations: blockedWork },
    { name: '产线在线窗口与质量门禁', status: lockViol + gateViol === 0 ? 'pass' : 'fail', detail: lockViol + gateViol === 0 ? '在线窗口不交叠且首件/复检门禁有效' : `窗口交叠${lockViol}/门禁${gateViol}`, violations: lockViol + gateViol }
  ]
  return { ok: violations.length === 0, checks, violations }
}

function validateTrajectory(bundle) {
  // 整段执行轨迹的独立验证（供场景级 validated 使用）：以冻结历史与最终台账为权威
  const entries = bundle.actualEntries
  const expected = new Map()
  for (const t of bundle.tasks) expected.set(t.id, t)
  for (const oid of bundle.orderIds) {
    const hasRecheck = entries.some((e) => e.key === 'recheck' && e.order === oid)
    const hasRework = entries.some((e) => e.key === 'rework' && e.order === oid)
    if (hasRework) expected.set(`${oid}::rework`, { id: `${oid}::rework`, key: 'rework', order: oid, skill: 'operator', deps: [`${oid}::fai_inspect`], duration: null })
    if (hasRecheck) expected.set(`${oid}::recheck`, { id: `${oid}::recheck`, key: 'recheck', order: oid, skill: 'quality', deps: [`${oid}::rework`], duration: null })
  }
  const violations = []
  const roster = new Map(bundle.personnel.map((p) => [p.id, p]))
  const invSet = new Set((bundle.equipment || []).map((x) => x.id))
  const covered = new Set()
  for (const e of entries) {
    if (e.kind === 'actual-fragment') continue
    if (expected.has(e.id)) covered.add(e.id)
    else if (e.originId && expected.has(e.originId)) covered.add(e.originId)
    else if (!e.id.includes('::seg@')) violations.push({ type: 'unknown_task', detail: `${e.id} 不属于场景任务合同` })
    const t = expected.get(e.id) || expected.get(e.originId)
    const person = roster.get(e.assigneeId)
    if (t && t.skill && person && person.skill !== t.skill) violations.push({ type: 'skill', detail: `${e.id} 技能不匹配` })
    if (!person) violations.push({ type: 'unknown_person', detail: `${e.id} 名册外人员 ${e.assigneeId}` })
    if (person && Array.isArray(person.shiftWindow) && (e.start < person.shiftWindow[0] - 1e-6 || e.end > person.shiftWindow[1] + 1e-6)) violations.push({ type: 'shift', detail: `${e.id} 超出班次` })
    const contract = t || e
    if (contract.equipment && e.equipment && invSet.size && !invSet.has(e.equipment)) violations.push({ type: 'equipment', detail: `${e.id} 库存外设备` })
  }
  for (const id of expected.keys()) if (!covered.has(id)) violations.push({ type: 'incomplete', detail: `场景缺少任务 ${id}` })
  const conflict = checkResourceConflicts(entries)
  violations.push(...conflict.violations)
  return { ok: violations.length === 0, violations }
}

function checkResourceConflicts(all) {
  const violations = []
  const personIntervals = new Map()
  const exIntervals = new Map()
  for (const e of all) {
    if (!personIntervals.has(e.assigneeId)) personIntervals.set(e.assigneeId, [])
    personIntervals.get(e.assigneeId).push([e.start, e.end, e.id])
    if (e.exclusive) {
      if (!exIntervals.has(e.exclusive)) exIntervals.set(e.exclusive, [])
      exIntervals.get(e.exclusive).push([e.start, e.end, e.id])
    }
    if (e.equipment) {
      if (!exIntervals.has(e.equipment)) exIntervals.set(e.equipment, [])
      exIntervals.get(e.equipment).push([e.start, e.end, e.id])
    }
  }
  for (const [pid, arr] of personIntervals) {
    arr.sort((a, b) => a[0] - b[0])
    for (let i = 1; i < arr.length; i++) if (arr[i][0] < arr[i - 1][1] - 1e-6) violations.push({ type: 'resource', detail: `人员 ${pid} 任务重叠：${arr[i - 1][2]}/${arr[i][2]}` })
  }
  for (const [ex, arr] of exIntervals) {
    arr.sort((a, b) => a[0] - b[0])
    for (let i = 1; i < arr.length; i++) if (arr[i][0] < arr[i - 1][1] - 1e-6) violations.push({ type: 'resource', detail: `独占资源 ${ex} 任务重叠：${arr[i - 1][2]}/${arr[i][2]}` })
  }
  return { violations }
}

// ---------------------------------------------------------------------------
// 应用事件（R0 / R1）
// ---------------------------------------------------------------------------

function applyEvent(bundle, ev) {
  const base = cloneBundle(bundle) // 不可变：所有操作在副本上进行
  const sig = eventSignature(ev)
  if (base.events.some((x) => x.signature === sig)) {
    return { bundle, result: { applied: false, duplicate: true, reason: '重复事件：相同类型/对象/时刻/参数已注入，未重复追加延迟或返工' } }
  }
  // 会话时钟单调：迟到事件（预约时刻早于已推进时钟）直接拒绝，不回拨历史
  if (Number.isFinite(base.clock) && ev.at < base.clock - EPS) {
    return { bundle, result: { applied: false, applicable: false, late: true, reason: `迟到事件：预约时刻 ${ev.at} 早于会话时钟 ${base.clock}，会话时钟不可回退` } }
  }
  const applicability = validateEvent(base, ev)
  if (!applicability.applicable) {
    return { bundle, result: { applied: false, applicable: false, reason: applicability.reason } }
  }

  // 事件时间语义：预约时刻 vs 实际触发时刻。首件失败以“检验完成时刻”与“预约时刻”的较晚者为触发，
  // 检验已完成后再提出失败不得回拨时钟、覆盖已执行的放行片段。
  let timing = { reserveAt: ev.at, triggerAt: ev.at, snapshotAt: ev.at, basis: '事件发生时刻' }
  let effectiveAt = ev.at
  if (ev.type === 'fai_fail') {
    const insp = findEntry(base.actualEntries, `${ev.target}::fai_inspect`)
    const triggerAt = Math.max(insp ? insp.end : ev.at, ev.at)
    effectiveAt = triggerAt
    timing = {
      reserveAt: ev.at,
      triggerAt,
      snapshotAt: triggerAt,
      basis: insp ? '取检验完成时刻与预约时刻的较晚者（失败在此时被发现）' : '未能定位检验任务，退回按预约时刻'
    }
    const rel = findEntry(base.actualEntries, `${ev.target}::quality_release`)
    if (rel && rel.end <= triggerAt + EPS) {
      return { bundle, result: { applied: false, applicable: false, reason: `订单 ${ev.target} 在触发时刻 ${r2(triggerAt)} 前已质量放行，首件不合格事件不适用，且不倒改历史` } }
    }
  }
  const effectiveEv = { ...ev, at: effectiveAt, reserveAt: ev.at }
  const snap = snapshotAt(base, effectiveAt)
  const input = buildRecoveryInput(base, effectiveEv, snap)

  const infeasible = checkSkillFeasible(base, input)
  if (infeasible.infeasible) {
    return { bundle, result: { applied: false, applicable: true, infeasible: true, reason: infeasible.reason } }
  }

  const baseMakespan = base.basePlan.metrics ? base.basePlan.metrics.makespan : 0
  const at = effectiveAt
  const activeOrder = snap.activeOrder

  const admission = (entries) => validateRecovery(base, input, entries, effectiveEv).ok

  const originalSeq = base.orderIds.slice()
  const r0Seq = activeOrder ? [activeOrder, ...originalSeq.filter((o) => o !== activeOrder)] : originalSeq
  const r0Priority = sched.templateRank(r0Seq)
  let r0
  let r1
  try {
    r0 = scheduleRecovery(base, input, r0Seq, r0Priority, at)
  } catch (err) {
    return { bundle, result: { applied: false, applicable: true, infeasible: true, reason: `无法生成可行恢复计划：${err.message}` } }
  }
  const r0Validation = validateRecovery(base, input, r0.entries, effectiveEv)
  if (!r0Validation.ok) {
    return { bundle, result: { applied: false, applicable: true, infeasible: true, rejected: true, reason: 'R0 恢复计划未通过独立验证，不采用也不持久化' } }
  }
  try {
    r1 = optimizeRecovery(base, input, r0Seq, activeOrder, at, base.seed, r0Validation.ok ? r0 : null, admission)
  } catch (err) {
    r1 = r0
  }
  if (!r1) r1 = r0
  const r1Validation = validateRecovery(base, input, r1.entries, effectiveEv)

  // 候选准入：仅采用通过独立验证的方案；R1 失败则回退 R0；两者皆失败则不采用
  let adopted = null
  let adoptedName = null
  let chosenFromR0 = false
  if (r1Validation.ok) {
    adopted = r1
    adoptedName = 'R1'
    chosenFromR0 = r1.chosenFromR0 === true
  } else if (r0Validation.ok) {
    adopted = r0
    adoptedName = 'R0'
    chosenFromR0 = true
  }
  if (!adopted) {
    return { bundle, result: { applied: false, applicable: true, rejected: true, reason: 'R0 与 R1 恢复计划均未通过独立验证，不采用也不持久化' } }
  }

  const r0Metrics = computeRecoveryMetrics(r0.entries, input.frozen, base.personnel, base.exclusive, baseMakespan, at, base.actualEntries, timing)
  const r1Metrics = computeRecoveryMetrics(r1.entries, input.frozen, base.personnel, base.exclusive, baseMakespan, at, base.actualEntries, timing)

  const sharedSnapshotId = `${base.sessionId}-${base.events.length + 1}`
  const eventRecord = {
    id: `ev-${base.events.length + 1}`,
    signature: sig,
    event: ev,
    timing,
    reserveAt: r2(timing.reserveAt),
    triggerAt: r2(timing.triggerAt),
    snapshotAt: r2(timing.snapshotAt),
    sharedSnapshotId,
    eventTime: r2(timing.triggerAt),
    applicable: true,
    snapshot: {
      at: r2(timing.snapshotAt),
      relation: '事件前快照（冻结至触发时刻）',
      doneCount: snap.done.length,
      running: snap.running,
      activeOrder: snap.activeOrder,
      lockProtected: snap.lockProtected,
      quality: snap.quality,
      personnelAvailability: availabilityFromBlocks(base.personnel, input.personBlocks),
      resourceAvailability: resourceFromBlocks(base.exclusive, input.resourceBlocks, input.lineBlocks)
    },
    cumulativeConstraints: {
      outages: (base.ledger?.outages || []).concat(input.newOutages || []),
      absences: (base.ledger?.absences || []).concat(input.newAbsences || [])
    },
    assumptions: input.absenceInfo,
    frozen: input.frozen,
    baseMakespan,
    R0: { entries: r0.entries, metrics: r0Metrics, validation: r0Validation },
    R1: { entries: r1.entries, metrics: r1Metrics, validation: r1Validation, chosenFromR0 },
    chosen: adoptedName,
    chosenFromR0,
    infeasible: false,
    infeasibleReason: null,
    createdAt: new Date().toISOString()
  }

  const merged = mergeActual(base, input, adopted.entries, effectiveEv)
  const toObj = (m) => Object.fromEntries([...m.entries()].map(([k, v]) => [k, v.map((x) => [x[0], x[1]])]))
  const next = {
    ...base,
    actualEntries: merged,
    events: base.events.concat(eventRecord),
    clock: Math.max(base.clock || 0, r2(timing.triggerAt)),
    ledger: {
      resourceBlocks: toObj(input.resourceBlocks),
      personBlocks: toObj(input.personBlocks),
      lineBlocks: input.lineBlocks.map((x) => [x[0], x[1]]),
      outages: (base.ledger?.outages || []).concat(input.newOutages || []),
      absences: (base.ledger?.absences || []).concat(input.newAbsences || [])
    },
    updatedAt: new Date().toISOString()
  }
  return { bundle: next, result: { applied: true, eventRecord } }
}

function optimizeRecovery(bundle, input, baseSeq, activeOrder, at, seed, baseline, admissionFn) {
  const rand = mulberryLocal(seed + Math.round(at * 1000))
  const seqs = []
  const others = baseSeq.filter((o) => o !== activeOrder)
  const perms = others.length <= 4 ? permutations(others) : [others]
  for (const p of perms) seqs.push(activeOrder ? [activeOrder, ...p] : p)
  const ranks = [sched.templateRank(baseSeq), sched.criticalPathRank(input.units)]
  for (let i = 0; i < 30; i++) {
    const score = new Map(input.units.map((u) => [u.id, rand()]))
    ranks.push((t) => score.get(t.id) ?? 0)
  }
  const admit = typeof admissionFn === 'function' ? admissionFn : () => true
  let best = null
  // 候选基线：独立验证通过的 R0（仅验证通过才作为候选）
  if (baseline && baseline.entries && admit(baseline.entries)) {
    const m = input.frozen.concat(baseline.entries).reduce((mx, e) => Math.max(mx, e.end), 0)
    best = { entries: baseline.entries, makespan: m, seq: baseSeq, chosenFromR0: true }
  }
  for (const seq of seqs) {
    for (const rank of ranks) {
      let res
      try {
        res = scheduleRecovery(bundle, input, seq, rank, at)
      } catch (e) {
        continue
      }
      const makespan = input.frozen.concat(res.entries).reduce((m, e) => Math.max(m, e.end), 0)
      // 仅当可能改善且通过独立验证时才参与比较
      if (!best || makespan < best.makespan - EPS) {
        if (!admit(res.entries)) continue
        best = { entries: res.entries, makespan, seq, chosenFromR0: false }
      }
    }
  }
  return best || scheduleRecovery(bundle, input, baseSeq, sched.templateRank(baseSeq), at)
}

function mergeActual(bundle, input, recoveryEntries, ev) {
  const merged = input.frozen.map((f) => {
    if (f.kind === 'actual') return { ...f }
    // 在制片段：仅保留已执行部分 [segStart, segEnd]，独立 id
    const base = bundle.actualEntries.find((e) => e.id === f.id) || f
    return {
      ...base,
      id: f.id,
      kind: 'actual-fragment',
      status: 'paused',
      start: f.segStart,
      end: f.segEnd,
      segStart: f.segStart,
      segEnd: f.segEnd
    }
  })
  for (const e of recoveryEntries) merged.push({ ...e, kind: e.kind === 'rework' || e.kind === 'recheck' ? e.kind : 'recovery' })
  // 首件失败：在新会话执行台账中把该订单检验结果写为 fail（不修改输入会话）
  if (input.faiFailOrder) {
    const insp = merged.find((e) => e.id === `${input.faiFailOrder}::fai_inspect`)
    if (insp) insp.result = 'fail'
  }
  return merged.sort((a, b) => a.start - b.start)
}

function checkSkillFeasible(bundle, input) {
  for (const u of input.units) {
    const qualified = bundle.personnel.filter((p) => p.skill === u.skill)
    if (!qualified.length) {
      return { infeasible: true, reason: `缺少工种 ${u.skillLabel || u.skill} 的合格人员，无法生成可行恢复计划` }
    }
    const anyFree = qualified.some((p) => {
      const blocks = []
      if (Array.isArray(p.shiftWindow)) {
        blocks.push([-1e9, p.shiftWindow[0]])
        blocks.push([p.shiftWindow[1], 1e9])
      }
      for (const b of input.personBlocks.get(p.id) || []) blocks.push(b)
      const s = sched.firstFreeSlot(blocks, Math.max(u.release || 0, 0), u.duration)
      const shiftEnd = Array.isArray(p.shiftWindow) ? p.shiftWindow[1] : 1440
      return s + u.duration <= shiftEnd + 1e-6
    })
    if (!anyFree) {
      return { infeasible: true, reason: `工种 ${u.skillLabel || u.skill} 的合格人员在班次与缺席约束下无可用时段，无法生成可行恢复计划` }
    }
  }
  return { infeasible: false, reason: null }
}

function availabilityFromBlocks(personnel, personBlocks) {
  return personnel.map((p) => {
    const blocks = personBlocks.get(p.id) || []
    return { id: p.id, name: p.name, skill: p.skill, unavailable: blocks.map((b) => `${r2(b[0])}→${r2(b[1])}`) }
  })
}

function resourceFromBlocks(exclusive, resourceBlocks, lineBlocks) {
  const list = exclusive.map((r) => {
    const blocks = resourceBlocks.get(r.id) || []
    return { id: r.id, name: r.name, blocked: blocks.map((b) => `${r2(b[0])}→${r2(b[1])}`) }
  })
  list.push({ id: 'LINE-01', name: 'SMT 混线产线', blocked: (lineBlocks || []).map((b) => `${r2(b[0])}→${r2(b[1])}`) })
  return list
}

function permutations(arr) {
  if (arr.length <= 1) return [arr.slice()]
  const out = []
  for (let i = 0; i < arr.length; i++) {
    const rest = arr.slice(0, i).concat(arr.slice(i + 1))
    for (const p of permutations(rest)) out.push([arr[i], ...p])
  }
  return out
}

function mulberryLocal(seed) {
  let a = seed >>> 0
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// ---------------------------------------------------------------------------
// 执行状态视图（供前端播放）
// ---------------------------------------------------------------------------

function buildExecutionView(bundle, at) {
  const records = bundle.actualEntries.map((e) => {
    let status = 'pending'
    if (e.end <= at + EPS) status = 'done'
    else if (e.start <= at + EPS && e.end > at + EPS) status = e.kind === 'actual-fragment' ? 'paused' : 'running'
    else status = 'pending'
    return { ...e, status, progressPct: status === 'running' ? r2(((at - e.start) / Math.max(0.001, e.end - e.start)) * 100) : status === 'done' ? 100 : 0 }
  })
  return {
    at: r2(at),
    records,
    events: bundle.events.map((ev) => ({ id: ev.id, type: ev.event.type, at: ev.eventTime, target: ev.event.target, chosen: ev.chosen }))
  }
}

module.exports = {
  MODEL_VERSION,
  createSession,
  applyEvent,
  snapshotAt,
  buildExecutionView,
  eventSignature,
  validateEvent,
  buildRecoveryInput,
  scheduleRecovery,
  validateRecovery,
  validateTrajectory
}
