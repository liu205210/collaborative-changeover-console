'use strict'

/**
 * 第五阶段 · 策略自优化实验室回归（真实运行完整闭环）
 * 用法：node server/lab-regressions.js
 * 覆盖：参数可解释、学习参数影响优先级、可重现、物理合同、验证器拒绝非法、预算计数、
 *      集合隔离与 reserved 守卫、模板版本不匹配、启用/回滚/重启、失败与退化保留、统一记账。
 */

const assert = require('assert')
const sim = require('./simulation')
const sched = require('./scheduler')
const prep = require('./prepPriority')
const lab = require('./lab')
const evaluation = require('./evaluation')
const store = require('./store')
const { importWorkbook, DEFAULT_XLSX } = require('./dataLoader')

const { orders } = importWorkbook(DEFAULT_XLSX)
const reservedFingerprints = new Set(
  evaluation.buildCaseCatalog(orders, evaluation.HISTORICAL_RESERVED_USED_FP)
    .filter((c) => c.set === 'reserved')
    .map((c) => c.fingerprint)
)

let passed = 0
let failed = 0
function check(name, fn) {
  try {
    fn()
    passed++
    console.log(`  [PASS] ${name}`)
  } catch (err) {
    failed++
    console.log(`  [FAIL] ${name} -> ${err.message}`)
  }
}

const three = orders.slice(0, 3)
const built = sim.buildTaskSet(three)
const seq = three.map((o) => o.order)
const weightsA = prep.CANDIDATE_PARAMS[1].weights
const weightsB = prep.CANDIDATE_PARAMS[3].weights

console.log('\n=== 1. 候选参数与特征 ===')
check('候选参数至多 9 组且权重特征均可解释', () => {
  assert.ok(prep.CANDIDATE_PARAMS.length <= 9 && prep.CANDIDATE_PARAMS.length >= 1)
  const feat = new Set(['order', 'template', 'duration', 'critical', 'tension'])
  for (const p of prep.CANDIDATE_PARAMS) {
    assert.ok(p.name && p.meaning, `${p.id} 缺少说明`)
    for (const k of Object.keys(p.weights)) assert.ok(feat.has(k), `未知特征 ${k}`)
  }
})

check('学习参数实际影响离线准备优先级', () => {
  const rankA = prep.makePrepPriority(weightsA, seq, built.tasks)
  const rankB = prep.makePrepPriority(weightsB, seq, built.tasks)
  const prepTasks = built.tasks.filter((t) => t.stage === 'prep')
  assert.ok(prepTasks.some((t) => Math.abs(rankA(t) - rankB(t)) > 1e-9), '两组参数产生完全相同的优先级')
})

console.log('\n=== 2. 可重现与物理合同 ===')
check('相同输入/参数/种子重现同一排程', () => {
  const r1 = sched.buildStrategyCLearned(built.tasks, seq, built.personnel, built.exclusive, built.equipment, weightsA)
  const r2 = sched.buildStrategyCLearned(built.tasks, seq, built.personnel, built.exclusive, built.equipment, weightsA)
  assert.deepStrictEqual(r1.entries, r2.entries)
})

check('学习排程保持物理合同且通过独立验证', () => {
  const r = sched.buildStrategyCLearned(built.tasks, seq, built.personnel, built.exclusive, built.equipment, weightsA)
  const v = sched.validateSchedule(r.entries, built.tasks, built.personnel, { equipment: built.equipment })
  assert.ok(v.ok, JSON.stringify(v.violations.slice(0, 3)))
  for (const e of r.entries) {
    const t = built.tasks.find((x) => x.id === e.id)
    assert.ok(Math.abs(e.duration - t.duration) < 1e-6, `${e.id} 工时被修改`)
  }
})

check('验证器拒绝人为非法候选', () => {
  const r = sched.buildStrategyCLearned(built.tasks, seq, built.personnel, built.exclusive, built.equipment, weightsA)
  const bad = r.entries.map((e) => ({ ...e, assigneeId: 'UNKNOWN' }))
  assert.strictEqual(sched.validateSchedule(bad, built.tasks, built.personnel, { equipment: built.equipment }).ok, false)
})

console.log('\n=== 3. 预算计数 ===')
check('原 C 与实际尝试计数等于 订单顺序数×42，C-learned 同上限', () => {
  const a = sched.buildStrategyC(built.tasks, seq, built.personnel, built.exclusive, built.equipment)
  const b = sched.buildStrategyCLearned(built.tasks, seq, built.personnel, built.exclusive, built.equipment, prep.CANDIDATE_PARAMS[0].weights)
  const seqs = sched.enumerateSequences(seq).length
  assert.strictEqual(a.candidateAttempts, seqs * 42)
  assert.strictEqual(a.maxCandidateAttempts, seqs * 42)
  assert.strictEqual(b.maxCandidateAttempts, seqs * 42)
  assert.ok(b.candidateAttempts > 0 && b.candidateAttempts <= b.maxCandidateAttempts)
})

console.log('\n=== 4. 集合隔离与版本 ===')
check('学习集=dev、验证集=validation 且互不重叠，禁止访问 reserved', () => {
  const dev = lab.staticCasesFor(orders, 'dev')
  const val = lab.staticCasesFor(orders, 'validation')
  assert.ok(dev.length > 0 && val.length > 0)
  const devFp = new Set(dev.map((c) => c.fingerprint))
  assert.ok(val.every((c) => !devFp.has(c.fingerprint)))
  assert.ok(dev.every((c) => c.set === 'dev') && val.every((c) => c.set === 'validation'))
  assert.throws(() => lab.staticCasesFor(orders, 'reserved'), /reserved/)
})

check('模板版本/摘要不匹配时标记为不适用', () => {
  const base = { modelVersion: sim.MODEL_VERSION, featureVersion: prep.FEATURE_VERSION, paramVersion: prep.PARAM_VERSION, protocolDigest: 'd1' }
  assert.strictEqual(lab.applicabilityOf(base, 'd1', sim.MODEL_VERSION).applicable, true)
  assert.strictEqual(lab.applicabilityOf(base, 'd2', sim.MODEL_VERSION).applicable, false)
  assert.strictEqual(lab.applicabilityOf({ ...base, modelVersion: 'v0' }, 'd1', sim.MODEL_VERSION).applicable, false)
  assert.strictEqual(lab.applicabilityOf(null, 'd1', sim.MODEL_VERSION).applicable, false)
})

check('同订单编号但内容变化时真实合同摘要改变', () => {
  const dev = lab.staticCasesFor(orders, 'dev')
  const val = lab.staticCasesFor(orders, 'validation')
  const d0 = lab.digestOf(orders, dev, val)
  const changed = orders.map((o) => ({ ...o }))
  const id = dev[0].orders[0]
  const obj = changed.find((o) => o.order === id)
  obj.qty += 10000
  obj.materialTypes += 500
  obj.bomLines += 500
  obj.faces = ['BOT', 'TOP']
  const d1 = lab.digestOf(changed, dev, val)
  assert.notStrictEqual(d0, d1, '任务内容变化后摘要未改变')
})

console.log('\n=== 5. 完整闭环（真实求解，计入统一使用记录） ===')
const schedOrigC = sched.buildStrategyC
const schedOrigL = sched.buildStrategyCLearned
let solverCalls = 0
sched.buildStrategyC = (...a) => { solverCalls++; return schedOrigC(...a) }
sched.buildStrategyCLearned = (...a) => { solverCalls++; return schedOrigL(...a) }
// 自建旧轮次夹具，避免归档断言依赖发布包之外的历史运行数据。
lab.ensureProtocol(orders)
const archiveBefore = (store.readJSON('lab-archive.json', []) || []).length
const resetResult = lab.reset({ orders })
check('显式开始新一轮时归档旧协议/选择/验证并新建轮次编号', () => {
  const archive = store.readJSON('lab-archive.json', []) || []
  assert.strictEqual(archive.length, archiveBefore + 1, '未归档旧轮次')
  assert.ok(resetResult.newProtocolId && resetResult.newRound >= 1)
  assert.strictEqual(store.readJSON('lab-selection.json', null), null, '新轮次应清空选择')
})
const history = lab.analyzeDevHistory({ orders })
check('开发历史分析产出真实瓶颈证据', () => {
  assert.ok(history.caseCount > 0 && history.bottlenecks.length > 0)
  assert.ok(history.baseline.length === history.caseCount && history.baseline.every((b) => b.feasible))
  assert.ok(history.aggregate.byKey.length > 0 && history.aggregate.byPerson.length > 0)
})
const experiment = lab.runExperiment({ orders })
check('参数实验记录全部候选并唯一选定，且只用 dev', () => {
  assert.strictEqual(experiment.candidates.length, prep.CANDIDATE_PARAMS.length)
  assert.ok(experiment.selectedId)
  assert.ok(experiment.devCaseFingerprints.every((f) => lab.staticCasesFor(orders, 'dev').some((c) => c.fingerprint === f)))
  assert.ok(experiment.devCaseFingerprints.every((f) => !reservedFingerprints.has(f)))
  assert.ok(experiment.baselineCost && experiment.baselineCost.attempts > 0, '原 C 基线成本应单独记录')
})
check('同一锁定轮次的普通重复实验复用结果且不重新求解', () => {
  const before = solverCalls
  const again = lab.runExperiment({ orders })
  assert.ok(again.reused, '重复实验应复用既有结果')
  assert.strictEqual(solverCalls, before, '重复实验不应重新求解')
})
const selection = store.readJSON('lab-selection.json', null)
check('选定记录不可变并含依据/版本/种子', () => {
  assert.ok(selection && selection.templateId === experiment.selectedId && selection.immutable)
  assert.ok(selection.selectionBasis && selection.seed != null && selection.featureVersion && selection.paramVersion)
  assert.ok(selection.protocolId && selection.protocolDigest)
})
const validation = lab.runValidation({ orders })
check('验证对照只覆盖 validation 且基线均可行', () => {
  assert.strictEqual(validation.caseCount, lab.staticCasesFor(orders, 'validation').length)
  assert.ok(validation.cases.every((c) => c.baseline.feasible))
  assert.ok(validation.caseFingerprints.every((f) => !reservedFingerprints.has(f)))
})
check('两策略使用相同预算上限且实际计数', () => {
  assert.strictEqual(validation.budget.baselineMax, validation.budget.learnedMax)
  assert.ok(validation.budget.baselineAttempts > 0 && validation.budget.learnedAttempts > 0)
})
check('改善/持平/退化分列且不截断为 0', () => {
  const im = validation.improvement
  assert.strictEqual(im.improved + im.tie + im.worse, im.n)
  assert.ok(im.denominator >= im.n)
  assert.ok(im.weightedPct != null && im.perCaseMeanPct != null)
})
check('失败/不可行案例保留原因（不计为 0）', () => {
  for (const c of validation.cases) {
    if (!c.learned.feasible) assert.ok(c.learned.reason, `${c.id} 不可行却无原因`)
  }
})
check('启用结论与保守规则一致（不预设提升）', () => {
  assert.strictEqual(validation.eligibleForActivation, validation.reasons.length === 0)
  if (!validation.eligibleForActivation) assert.ok(validation.conclusion.includes('保留原策略'))
})
sched.buildStrategyC = schedOrigC
sched.buildStrategyCLearned = schedOrigL

console.log('\n=== 6. 启用 / 回滚 / 持久化 ===')
check('启用、回滚真实影响所选策略并可重启核验', () => {
  lab.rollback({ reason: 'test pre' })
  assert.strictEqual(lab.getActiveOverride(orders), null)
  if (validation.eligibleForActivation) {
    lab.activate({ orders })
    let ov = lab.getActiveOverride(orders)
    assert.ok(ov && ov.templateId === selection.templateId, '启用后应返回学习参数')
    // 模拟重启：丢弃模块缓存后重新读取持久化状态
    delete require.cache[require.resolve('./lab')]
    const lab2 = require('./lab')
    ov = lab2.getActiveOverride(orders)
    assert.ok(ov && ov.templateId === selection.templateId, '重启后应保持启用状态')
    lab2.rollback({ reason: 'test post' })
    assert.strictEqual(lab2.getActiveOverride(orders), null, '回滚后应回到原策略')
  }
})

console.log('\n=== 7. 统一记账与 reserved 守卫 ===')
check('学习/验证求解进入统一使用记录且无 reserved', () => {
  const usage = store.readJSON('eval-usage.json', { fingerprints: [], runs: [] })
  const stages = new Set((usage.runs || []).map((r) => r.stage))
  assert.ok(stages.has('history') && stages.has('baseline') && stages.has('candidate') && stages.has('validation'))
  assert.ok((usage.runs || []).every((r) => r.reservedRun !== true && !(r.effectiveSets || []).includes('reserved')))
  const fps = new Set(usage.fingerprints || [])
  assert.ok([...reservedFingerprints].every((f) => !fps.has(f)), '使用记录中出现 reserved 指纹')
  const candidateRun = (usage.runs || []).find((r) => r.stage === 'candidate')
  assert.ok(candidateRun && candidateRun.paramId != null && Array.isArray(candidateRun.attemptsByParam))
})

console.log('\n=== 8. 记账失败语义与待记账恢复 ===')
check('求解后记账失败报 executed=true 且带 runId/指纹，重试幂等补记', () => {
  store.writeJSON('lab-validation.json', null)
  let thrown = null
  evaluation.setUsageSink(() => { throw new Error('AUDIT_USAGE_WRITE_FAILURE') })
  try { lab.runValidation({ orders }) } catch (e) { thrown = e } finally { evaluation.setUsageSink(null) }
  assert.ok(thrown, '记账失败不得报告成功')
  assert.strictEqual(thrown.executed, true, '已求解却报告未执行')
  assert.ok(thrown.runId && thrown.usedFingerprints && thrown.usedFingerprints.length, '缺少可恢复运行编号或指纹')
  assert.strictEqual(store.readJSON('lab-validation.json', null), null, '记账失败时不得暴露为可启用结果')
  assert.ok(store.readJSON('lab-pending.json', null), '应保留待记账运行记录')
  const retry = lab.runValidation({ orders })
  assert.ok(retry && retry.caseCount > 0, '修复记账器后应恢复返回验证结果')
  assert.strictEqual(store.readJSON('lab-pending.json', null), null, '补记成功后应清除待记账记录')
})

console.log('\n=== 9. 全失败候选保留尝试数与业务原因 ===')
check('质检人员缺失时方案C抛出业务原因并保留 42 次实际尝试', () => {
  const entry = lab.staticCasesFor(orders, 'dev').find((c) => c.orders.length === 1)
  const selected = entry.orders.map((id) => orders.find((o) => o.order === id))
  const built = sim.buildTaskSet(selected)
  built.personnel = built.personnel.filter((p) => p.skill !== 'quality')
  let err = null
  try { sched.buildStrategyC(built.tasks, entry.orders, built.personnel, built.exclusive, built.equipment, 20261021) } catch (e) { err = e }
  assert.ok(err, '缺少质检人员应不可行')
  assert.strictEqual(err.candidateAttempts != null ? err.candidateAttempts : err.attempts, 42, '应保留 42 次实际失败尝试')
  assert.ok(!/Cannot read properties of null/.test(err.message), '应保留业务不可行原因')
})

console.log(`\n=== 实验室回归汇总：通过 ${passed} 项，失败 ${failed} 项 ===\n`)
if (failed > 0) process.exit(1)
