'use strict'

const fs = require('fs')
const path = require('path')
const XLSX = require('xlsx')

const DATA_DIR = path.join(__dirname, '..', 'data')
const UPLOAD_DIR = path.join(DATA_DIR, 'upload')
const STORE_DIR = path.join(DATA_DIR, 'store')
const DEFAULT_XLSX = path.join(UPLOAD_DIR, '赛道数据包.xlsx')

function ensureDirs() {
  for (const d of [DATA_DIR, UPLOAD_DIR, STORE_DIR]) {
    if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true })
  }
}

// 编码类字段统一按字符串处理，避免前导零丢失、避免科学计数法。
function toCode(value) {
  if (value === null || value === undefined) return ''
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return String(value)
    if (Number.isInteger(value)) return value.toFixed(0)
    return String(value)
  }
  return String(value).trim()
}

function toNumber(value) {
  if (value === null || value === undefined || value === '') return null
  const n = typeof value === 'number' ? value : Number(String(value).replace(/,/g, '').trim())
  return Number.isFinite(n) ? n : null
}

function toDateString(value) {
  if (value === null || value === undefined || value === '') return ''
  // Excel 日期序列号（1900 日期系统），使用 SSF 解析避免时区漂移
  if (typeof value === 'number' && Number.isFinite(value)) {
    const parsed = XLSX.SSF.parse_date_code(value)
    if (parsed && parsed.y) {
      const m = String(parsed.m).padStart(2, '0')
      const d = String(parsed.d).padStart(2, '0')
      return `${parsed.y}-${m}-${d}`
    }
    return ''
  }
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    const y = value.getFullYear()
    const m = String(value.getMonth() + 1).padStart(2, '0')
    const d = String(value.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }
  return String(value).trim()
}

function listWorkbooks() {
  if (!fs.existsSync(UPLOAD_DIR)) return []
  return fs
    .readdirSync(UPLOAD_DIR)
    .filter((f) => /\.(xlsx|xls)$/i.test(f))
    .map((f) => path.join(UPLOAD_DIR, f))
}

/**
 * 读取 Excel 并做数据质量核查 + 规范化聚合。
 * 关键点：按订单聚合排产数量时必须去重，不能因物料明细行重复而累加。
 */
function importWorkbook(filePath) {
  ensureDirs()
  const wb = XLSX.readFile(filePath)
  const sheetName = wb.SheetNames[0]
  const ws = wb.Sheets[sheetName]
  const matrix = XLSX.utils.sheet_to_json(ws, { header: 1, raw: true, defval: null })
  if (!matrix.length) {
    throw new Error(`工作表 ${sheetName} 为空`)
  }
  const header = matrix[0].map((h) => (h === null || h === undefined ? '' : String(h).trim()))
  const idx = {}
  // 兼容表头可能带有前后空白
  header.forEach((h, i) => {
    idx[h] = i
  })
  const need = ['订单批次号', '成品专用号', '成品描述', '排产数量', '事业部T1交货', '面', '物料编码', '物料描述', '用量']
  const missingCols = need.filter((c) => idx[c] === undefined)
  if (missingCols.length) {
    throw new Error(`缺少必要字段: ${missingCols.join('、')}`)
  }

  const rawRows = matrix.slice(1)
  const dataRows = rawRows.filter((r) => Array.isArray(r) && r.some((v) => v !== null && v !== undefined && String(v).trim() !== ''))

  const missing = {}
  for (const c of need) missing[c] = 0
  const blankRows = rawRows.length - dataRows.length

  const orderMap = new Map()
  const fullRowSet = new Map()
  const keySet = new Map()

  let rawQtySum = 0
  let rawQtyCount = 0

  for (const r of dataRows) {
    const order = toCode(r[idx['订单批次号']])
    const product = toCode(r[idx['成品专用号']])
    const productDesc = toCode(r[idx['成品描述']])
    const qty = toNumber(r[idx['排产数量']])
    const delivery = toDateString(r[idx['事业部T1交货']])
    const face = toCode(r[idx['面']])
    const material = toCode(r[idx['物料编码']])
    const materialDesc = toCode(r[idx['物料描述']])
    const usage = toNumber(r[idx['用量']])

    for (const [col, val] of Object.entries({
      订单批次号: order,
      成品专用号: product,
      成品描述: productDesc,
      排产数量: qty,
      事业部T1交货: delivery,
      面: face,
      物料编码: material,
      物料描述: materialDesc,
      用量: usage
    })) {
      if (val === null || val === '' || (typeof val === 'string' && val.trim() === '')) {
        missing[col] += 1
      }
    }

    if (qty !== null) {
      rawQtySum += qty
      rawQtyCount += 1
    }

    const fullKey = [order, product, productDesc, qty, delivery, face, material, materialDesc, usage].join('\u0001')
    fullRowSet.set(fullKey, (fullRowSet.get(fullKey) || 0) + 1)
    const key = [order, product, material, face].join('\u0001')
    keySet.set(key, (keySet.get(key) || 0) + 1)

    if (!orderMap.has(order)) {
      orderMap.set(order, {
        order,
        products: new Set(),
        productDescs: new Set(),
        qty: qty,
        deliveries: new Set(),
        faces: new Set(),
        bom: [],
        materialSet: new Set()
      })
    }
    const rec = orderMap.get(order)
    rec.products.add(product)
    rec.productDescs.add(productDesc)
    if (delivery) rec.deliveries.add(delivery)
    if (face) rec.faces.add(face)
    rec.materialSet.add(material)
    rec.bom.push({
      material,
      materialDesc: materialDesc || '未分类',
      usage: usage === null ? 0 : usage,
      face,
      lineQty: qty
    })
  }

  const orders = Array.from(orderMap.values()).map((rec) => {
    const bom = rec.bom
    return {
      order: rec.order,
      product: Array.from(rec.products)[0] || '',
      productCount: rec.products.size,
      productDesc: Array.from(rec.productDescs)[0] || '',
      qty: rec.qty || 0,
      delivery: Array.from(rec.deliveries).sort()[0] || '',
      faces: Array.from(rec.faces).sort(),
      bomLines: bom.length,
      materialTypes: rec.materialSet.size,
      bom
    }
  }).sort((a, b) => (a.order < b.order ? -1 : 1))

  const allDates = new Set()
  for (const rec of orderMap.values()) for (const d of rec.deliveries) allDates.add(d)
  const materials = new Set()
  const products = new Set()
  for (const rec of orderMap.values()) {
    for (const m of rec.materialSet) materials.add(m)
    for (const p of rec.products) products.add(p)
  }

  const fullDuplicates = Array.from(fullRowSet.values()).filter((c) => c > 1)
  const keyDuplicates = Array.from(keySet.values()).filter((c) => c > 1)

  const aggregatedQty = orders.reduce((s, o) => s + (o.qty || 0), 0)

  const meta = {
    sourceFile: path.basename(filePath),
    sheet: sheetName,
    sheetCount: wb.SheetNames.length,
    sheetNames: wb.SheetNames,
    dataRows: dataRows.length,
    blankRows,
    orders: orders.length,
    products: products.size,
    materials: materials.size,
    dateRange: {
      min: Array.from(allDates).sort()[0] || '',
      max: Array.from(allDates).sort().slice(-1)[0] || '',
      distinctDays: allDates.size
    },
    missing,
    duplicates: {
      fullRows: fullDuplicates.length,
      compositeKeys: keyDuplicates.length,
      compositeKeyDefinition: '订单批次号+成品专用号+物料编码+面'
    },
    quantityAggregation: {
      rawMaterialDetailSum: rawQtySum,
      rawMaterialDetailRows: rawQtyCount,
      aggregatedByOrderSum: aggregatedQty,
      inflatedTimes: rawQtySum && aggregatedQty ? Number((rawQtySum / aggregatedQty).toFixed(2)) : null,
      note: '排产数量为订单级字段，物料明细行的重复仅是BOM展开，聚合时必须按订单去重。'
    },
    bomLineTotal: orders.reduce((s, o) => s + o.bomLines, 0),
    materialCategories: categoryBreakdown(orders)
  }

  return { meta, orders }
}

function categoryBreakdown(orders) {
  const counter = new Map()
  for (const o of orders) {
    for (const b of o.bom) {
      counter.set(b.materialDesc, (counter.get(b.materialDesc) || 0) + 1)
    }
  }
  return Array.from(counter.entries())
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count)
}

module.exports = {
  DEFAULT_XLSX,
  UPLOAD_DIR,
  STORE_DIR,
  importWorkbook,
  listWorkbooks,
  ensureDirs,
  toCode,
  toNumber,
  toDateString
}
