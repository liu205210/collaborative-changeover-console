'use strict'

const path = require('path')
const fs = require('fs')
const crypto = require('crypto')
const express = require('express')
const cors = require('cors')
const compression = require('compression')

const { importWorkbook, listWorkbooks, ensureDirs, DEFAULT_XLSX } = require('./dataLoader')
const store = require('./store')
const { buildTaskSet, assumptionsPayload, MODEL_VERSION } = require('./simulation')
const { buildSchedules, validateSchedule } = require('./scheduler')
const { buildAgentView } = require('./agents')
const recovery = require('./recovery')
const { buildSimulationData } = require('./simData')
const { runEvaluation, buildCaseCatalog, selectCases, setUsageSink, emitUsage, HISTORICAL_RESERVED_USED, RETIRED_UNUSED_RESERVED } = require('./evaluation')
const lab = require('./lab')
const collab = require('./collaboration')
const assistant = require('./assistant')

const PORT = Number(process.env.PORT || 3001)
const WEB_DIST = path.join(__dirname, '..', 'web', 'dist')
const DATASET_STORE = 'dataset.json'
const PLAN_STORE = 'lastPlan.json'

const app = express()
app.use(cors())
app.use(compression())
app.use(express.json({ limit: '2mb' }))

let DATASET = { meta: null, orders: [] }

function loadOrImportData() {
  ensureDirs()
  const cached = store.readJSON(DATASET_STORE, null)
  if (cached && cached.meta && Array.isArray(cached.orders) && cached.orders.length) {
    DATASET = cached
    console.log(`[data] 已从本地存储加载 ${DATASET.orders.length} 个订单（刷新后保留）`)
    return
  }
  try {
    const { meta, orders } = importWorkbook(DEFAULT_XLSX)
    DATASET = { meta, orders }
    store.writeJSON(DATASET_STORE, DATASET)
    console.log(`[data] 首次导入完成：${orders.length} 个订单，${meta.dataRows} 行`)
  } catch (err) {
    console.error('[data] 导入失败:', err.message)
    DATASET = { meta: { error: err.message }, orders: [] }
  }
}

function orderSummary(o) {
  return {
    order: o.order,
    product: o.product,
    productDesc: o.productDesc,
    qty: o.qty,
    delivery: o.delivery,
    faces: o.faces,
    bomLines: o.bomLines,
    materialTypes: o.materialTypes
  }
}

// --------------------------- API ---------------------------

app.get('/api/health', (req, res) => {
  res.json({ ok: true, time: new Date().toISOString(), orders: DATASET.orders.length })
})

app.get('/api/dataset', (req, res) => {
  res.json({
    meta: DATASET.meta,
    orders: DATASET.orders.map(orderSummary),
    sourceFiles: listWorkbooks().map((p) => path.basename(p))
  })
})

app.get('/api/orders', (req, res) => {
  const q = String(req.query.q || '').trim().toLowerCase()
  let list = DATASET.orders
  if (q) {
    list = list.filter(
      (o) => o.order.toLowerCase().includes(q) || o.product.toLowerCase().includes(q) || (o.productDesc || '').toLowerCase().includes(q)
    )
  }
  res.json({ total: list.length, orders: list.slice(0, 200).map(orderSummary) })
})

app.get('/api/orders/:id', (req, res) => {
  const o = DATASET.orders.find((x) => x.order === req.params.id)
  if (!o) return res.status(404).json({ error: `未找到订单 ${req.params.id}` })
  res.json(o)
})

app.get('/api/assumptions', (req, res) => {
  res.json(assumptionsPayload())
})

app.post('/api/import', (req, res) => {
  try {
    const files = listWorkbooks()
    const target = DEFAULT_XLSX
    if (!fs.existsSync(target)) {
      return res.status(400).json({ error: `未找到数据文件 ${path.basename(target)}` })
    }
    const { meta, orders } = importWorkbook(target)
    DATASET = { meta, orders }
    store.writeJSON(DATASET_STORE, DATASET)
    res.json({ ok: true, meta, orderCount: orders.length, files: files.map((f) => path.basename(f)) })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.post('/api/plans', (req, res) => {
  try {
    const body = req.body || {}
    const orderIds = Array.isArray(body.orders) && body.orders.length ? body.orders.map(String) : []
    const failSet = new Set(Array.isArray(body.faiFailures) ? body.faiFailures.map(String) : [])
    if (!orderIds.length) return res.status(400).json({ error: '请至少选择一个订单' })

    const selected = orderIds
      .map((id) => DATASET.orders.find((o) => o.order === id))
      .filter(Boolean)
    if (!selected.length) return res.status(404).json({ error: '所选订单不存在' })

    const ordersInOrder = selected.map((o) => o.order)
    const { tasks, personnel, exclusive, equipment } = buildTaskSet(selected)
    const faiResults = {}
    for (const id of orderIds) faiResults[id] = failSet.has(id) ? 'fail' : 'pass'

    const activeOverride = lab.getActiveOverride(DATASET.orders)
    const { A, B, C, comparison } = buildSchedules({ tasks, personnel, exclusive, equipment, ordersInOrder, strategyOverride: activeOverride })
    const validation = {
      A: validateSchedule(A.entries, tasks, personnel, { faiResults }),
      B: validateSchedule(B.entries, tasks, personnel, { faiResults }),
      C: validateSchedule(C.entries, tasks, personnel, { faiResults })
    }
    const agents = {
      A: buildAgentView({ orders: selected, schedule: A, personnel, exclusive, mode: 'A', faiResults }),
      B: buildAgentView({ orders: selected, schedule: B, personnel, exclusive, mode: 'B', faiResults }),
      C: buildAgentView({ orders: selected, schedule: C, personnel, exclusive, mode: 'C', faiResults })
    }

    const payload = {
      generatedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      planId: `plan-${Date.now().toString(36)}`,
      modelVersion: MODEL_VERSION,
      inputDigest: `in-${orderIds.join('_')}@${MODEL_VERSION}`,
      activeStrategy: activeOverride ? 'C-learned' : 'C',
      activeTemplateId: activeOverride ? activeOverride.templateId : null,
      orderIds,
      orders: selected,
      tasks,
      resources: { personnel, exclusive, equipment },
      schedules: { A, B, C },
      validation,
      agents,
      comparison,
      assumptions: assumptionsPayload()
    }
    store.writeJSON(PLAN_STORE, payload)
    res.json(payload)
  } catch (err) {
    console.error('[plans] 生成失败:', err)
    res.status(500).json({ error: err.message })
  }
})

app.get('/api/plans/last', (req, res) => {
  const cached = store.readJSON(PLAN_STORE, null)
  if (!cached) return res.status(404).json({ error: '暂无历史排程结果' })
  const stale = !cached.modelVersion || cached.modelVersion !== MODEL_VERSION
  res.json({
    ...cached,
    currentModelVersion: MODEL_VERSION,
    stale,
    staleReason: stale
      ? `该记录为历史版本（${cached.modelVersion || '无版本号'}），当前模型为 ${MODEL_VERSION}，不作为当前模型的最新验证结果，请重新生成。`
      : null
  })
})

// --------------------------- 仿真会话（异常注入与回放） ---------------------------

const SIM_STORE = 'simulation.json'
const DRILL_PENDING = 'drill-pending.json'
let SIM = store.readJSON(SIM_STORE, null)

function simCandidates(bundle) {
  return {
    deliveries: bundle.actualEntries
      .filter((e) => e.key === 'material_deliver')
      .sort((a, b) => a.start - b.start)
      .map((e) => ({ id: e.id, order: e.order, start: e.start, end: e.end, assignee: e.assigneeName })),
    persons: bundle.personnel.map((p) => ({ id: p.id, name: p.name, skill: p.skill })),
    resources: [
      { id: 'LINE-01', name: 'SMT 混线产线' },
      { id: 'CAL-01', name: '离线参数校准台' }
    ],
    orders: bundle.orderIds.map((o) => {
      const rel = bundle.actualEntries.find((e) => e.id === `${o}::quality_release`)
      return { order: o, releasedEnd: rel ? rel.end : null }
    })
  }
}

function simResponse(bundle) {
  const stale = !bundle.modelVersion || bundle.modelVersion !== MODEL_VERSION
  return {
    sessionId: bundle.sessionId,
    modelVersion: bundle.modelVersion,
    currentModelVersion: MODEL_VERSION,
    stale,
    staleReason: stale ? `该会话为历史版本（${bundle.modelVersion || '无版本号'}），当前模型为 ${MODEL_VERSION}，不作为当前模型的最新验证结果。` : null,
    seed: bundle.seed,
    inputDigest: bundle.inputDigest || null,
    createdAt: bundle.createdAt,
    orderIds: bundle.orderIds,
    orders: bundle.orders,
    tasks: bundle.tasks,
    personnel: bundle.personnel,
    exclusive: bundle.exclusive,
    basePlan: bundle.basePlan,
    actualEntries: bundle.actualEntries,
    events: bundle.events,
    candidates: simCandidates(bundle),
    updatedAt: bundle.updatedAt
  }
}

function drillFingerprint(orderIds, seed, eventType) {
  return `drill|${orderIds.slice().sort().join('+')}|seed:${seed}${eventType ? '|' + eventType : ''}`
}

// 对象字段顺序不影响请求身份；订单/目标数组顺序保持原输入。
function drillRequestKey(value) {
  if (Array.isArray(value)) return `[${value.map(drillRequestKey).join(',')}]`
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map((k) => `${JSON.stringify(k)}:${drillRequestKey(value[k])}`).join(',')}}`
  return JSON.stringify(value)
}

function drillFailure(error, pending) {
  error.executed = true
  error.runId = pending.runId
  error.usedFingerprints = pending.fingerprints.slice()
  return error
}

// 发布成功之前保留完整执行结果；补记与发布重试均沿用原 runId。
function finishDrill(pending, recovered = false) {
  try {
    const record = pending.record || { runId: pending.runId, at: pending.pendingAt, effectiveSets: ['drill'], fingerprints: pending.fingerprints, reservedRun: false, stage: 'drill', strategy: 'C', drillKind: pending.kind, caseFingerprints: pending.fingerprints }
    emitUsage(record, { runId: pending.runId, usedFingerprints: pending.fingerprints })
    if (pending.session) {
      store.writeJSON(SIM_STORE, pending.session)
      SIM = pending.session
    }
    store.writeJSON(DRILL_PENDING, null)
    const body = pending.responseBody || (pending.kind === 'reset' ? simResponse(SIM) : { applied: true, session: simResponse(SIM) })
    return { status: pending.responseStatus || 200, body: { ...body, recovered, executed: true, runId: pending.runId, usedFingerprints: pending.fingerprints } }
  } catch (error) {
    throw drillFailure(error, pending)
  }
}

function recoverDrillPending(kind, request) {
  const pending = store.readJSON(DRILL_PENDING, null)
  if (!pending) return null
  // 兼容本补丁之前已保存的待补记记录。
  const originalRequest = pending.request || (pending.kind === 'reset' ? { orders: pending.orderIds, seed: pending.seed } : pending.eventInput)
  if (pending.kind !== kind || drillRequestKey(originalRequest) !== drillRequestKey(request)) {
    const error = drillFailure(new Error(`存在待恢复的 ${pending.kind} 演练 ${pending.runId}，当前请求不同；请重试原请求，未覆盖待恢复记录。`), pending)
    error.httpStatus = 409
    throw error
  }
  return finishDrill(pending, true)
}

// 失败的恢复尝试也保留结果；不将前置拒绝或重复事件计为一次求解。
function runDrill({ kind, request, orderIds, seed, eventType }, solve) {
  const runId = `drill-${kind}-${crypto.randomUUID()}`
  let result
  try {
    result = solve()
  } catch (error) {
    result = { status: 500, body: { error: error.message }, outcome: 'failed', session: null }
  }
  if (result.skipUsage) return { status: result.status || 200, body: result.body }
  const fingerprints = [drillFingerprint(orderIds, seed, eventType)]
  const at = new Date().toISOString()
  const record = { runId, at, effectiveSets: ['drill'], fingerprints, reservedRun: false, stage: 'drill', strategy: 'C', drillKind: kind, outcome: result.outcome || 'applied', requestKey: drillRequestKey(request), caseFingerprints: fingerprints }
  const pending = { kind, runId, fingerprints, seed, orderIds, eventType: eventType || null, request, eventInput: kind === 'event' ? request : null, session: result.session || null, record, responseStatus: result.status || 200, responseBody: result.body, pendingAt: at }
  try {
    store.writeJSON(DRILL_PENDING, pending)
    return finishDrill(pending)
  } catch (error) {
    throw drillFailure(error, pending)
  }
}

function sendDrillError(res, err) {
  res.status(err.httpStatus || 500).json({ error: err.message, executed: !!err.executed, runId: err.runId || null, usedFingerprints: err.usedFingerprints || [] })
}

app.post('/api/simulate/reset', (req, res) => {
  try {
    const body = req.body || {}
    const orderIds = Array.isArray(body.orders) && body.orders.length ? body.orders.map(String) : []
    const request = { orders: orderIds, seed: Number(body.seed) || 20261005 }
    const recovered = recoverDrillPending('reset', request)
    if (recovered) return res.status(recovered.status).json(recovered.body)
    const selected = orderIds.map((id) => DATASET.orders.find((o) => o.order === id)).filter(Boolean)
    if (!selected.length) return res.status(400).json({ error: '请至少选择一个订单' })
    const result = runDrill({ kind: 'reset', request, orderIds: selected.map((o) => o.order), seed: request.seed }, () => {
      const session = recovery.createSession({ orders: selected, seed: request.seed })
      return { session, body: simResponse(session) }
    })
    res.status(result.status).json(result.body)
  } catch (err) {
    sendDrillError(res, err)
  }
})

app.post('/api/simulate/event', (req, res) => {
  try {
    const event = req.body || {}
    const recovered = recoverDrillPending('event', event)
    if (recovered) return res.status(recovered.status).json(recovered.body)
    if (!SIM) return res.status(400).json({ error: '请先初始化仿真会话' })
    if (!event.type) return res.status(400).json({ error: '缺少事件类型' })
    const result = runDrill({ kind: 'event', request: event, orderIds: SIM.orderIds, seed: SIM.seed, eventType: event.type }, () => {
      const { bundle, result } = recovery.applyEvent(SIM, event)
      return { session: result.applied ? bundle : null, body: { ...result, session: simResponse(result.applied ? bundle : SIM) }, skipUsage: !result.applied && result.applicable !== true, outcome: result.applied ? 'applied' : 'failed-attempt' }
    })
    res.status(result.status).json(result.body)
  } catch (err) {
    console.error('[simulate] 事件注入失败:', err)
    sendDrillError(res, err)
  }
})

app.get('/api/simulate', (req, res) => {
  if (!SIM) return res.status(404).json({ error: '暂无仿真会话，请先初始化' })
  res.json(simResponse(SIM))
})

app.get('/api/simulate/export', (req, res) => {
  if (!SIM) return res.status(404).json({ error: '暂无仿真会话' })
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.setHeader('Content-Disposition', `attachment; filename="simulation-${SIM.sessionId}.json"`)
  res.send(JSON.stringify(SIM, null, 2))
})

// --------------------------- 仿真数据层与批量评测 ---------------------------

const SIMDATA_STORE = 'simdata.json'
const EVAL_STORE = 'evaluation.json'

function getSimData(force) {
  if (!force) {
    const cached = store.readJSON(SIMDATA_STORE, null)
    if (cached && cached.modelVersion === MODEL_VERSION) return cached
  }
  const data = buildSimulationData({ orders: DATASET.orders })
  store.writeJSON(SIMDATA_STORE, data)
  return data
}

app.get('/api/simdata', (req, res) => {
  try {
    const data = getSimData(req.query.force === '1')
    res.json(data)
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

const USAGE_STORE = 'eval-usage.json'

function loadUsage() {
  const u = store.readJSON(USAGE_STORE, { fingerprints: [], runs: [], history: [] })
  u.fingerprints = u.fingerprints || []
  u.runs = u.runs || []
  u.history = u.history || []
  const fps = new Set(u.fingerprints)
  for (const h of HISTORICAL_RESERVED_USED) {
    if (!fps.has(h.fingerprint)) {
      fps.add(h.fingerprint)
      u.history.push({ id: h.id, fingerprint: h.fingerprint, source: 'v4.2 verify 保留集保护测试（回归实际求解）', usedAt: 'unknown', evidence: 'data-eval-evidence.json / release/round4/test-output.txt' })
    }
  }
  u.fingerprints = Array.from(fps)
  return u
}
function saveUsage(u) {
  store.writeJSON(USAGE_STORE, u)
}
function recordUsage(rec) {
  const u = loadUsage()
  // 部分写入成功后的补记会重放同一运行，HTTP 与 CLI 均按 runId 幂等。
  if (u.runs.some((run) => run.runId === rec.runId)) return
  const fps = new Set(u.fingerprints)
  for (const f of rec.fingerprints || []) fps.add(f)
  u.fingerprints = Array.from(fps)
  u.runs = u.runs.concat([
    {
      runId: rec.runId,
      at: rec.at,
      effectiveSets: rec.effectiveSets,
      reservedRun: rec.reservedRun,
      stage: rec.stage || 'evaluation',
      strategy: rec.strategy || null,
      paramId: rec.paramId || null,
      caseFingerprints: rec.caseFingerprints || rec.fingerprints || null,
      attempts: rec.attempts != null ? rec.attempts : null,
      baselineAttempts: rec.baselineAttempts != null ? rec.baselineAttempts : null,
      attemptsByParam: rec.attemptsByParam || null,
      ...(rec.stage === 'drill' ? { drillKind: rec.drillKind || null, outcome: rec.outcome || null, requestKey: rec.requestKey || null } : {})
    }
  ])
  saveUsage(u)
}
// 真实求解入口统一记账；纯筛选不触发
setUsageSink(recordUsage)
loadUsage() // 启动时补记历史已用（幂等）

// 异常演练真实求解（初始化会话 / 注入事件）也统一记账；
// 具体流程见 runDrill / finishDrill（先保存待记账，再幂等记账，发布完成后清理）。

app.get('/api/eval/catalog', (req, res) => {
  const usage = loadUsage()
  const catalog = buildCaseCatalog(DATASET.orders, usage.fingerprints)
  const byCategory = {}
  for (const c of catalog) byCategory[c.category] = (byCategory[c.category] || 0) + 1
  const sets = {}
  for (const s of ['dev', 'validation', 'frozen', 'reserved']) sets[s] = catalog.filter((c) => c.set === s).length
  res.json({
    caseCount: catalog.length,
    categories: byCategory,
    sets,
    reservedStatus: { actualReservedCount: sets.reserved, historicalUsedCount: usage.history.length, retiredUnused: RETIRED_UNUSED_RESERVED },
    usageRuns: usage.runs.length,
    cases: catalog
  })
})

app.post('/api/eval/run', (req, res) => {
  try {
    const body = req.body || {}
    const data = getSimData(false)
    const usage = loadUsage()
    const strategyOverride = lab.getActiveOverride(DATASET.orders)
    const report = runEvaluation({ orders: DATASET.orders, simData: data, sets: body.sets, categories: body.categories, seed: Number(body.seed) || undefined, usage, strategyOverride })
    report.note = body.note || '缺省仅运行 dev+validation；reserved 保留集不默认运行。'
    store.writeJSON(EVAL_STORE, report)
    res.json(report)
  } catch (err) {
    console.error('[eval] 运行失败:', err)
    res.status(500).json({ error: err.message })
  }
})

app.get('/api/eval/results', (req, res) => {
  const cached = store.readJSON(EVAL_STORE, null)
  if (!cached) return res.status(404).json({ error: '暂无评测结果' })
  res.json(cached)
})

app.get('/api/eval/usage', (req, res) => {
  res.json(store.readJSON(USAGE_STORE, { fingerprints: [], runs: [] }))
})

app.get('/api/eval/export.json', (req, res) => {
  const cached = store.readJSON(EVAL_STORE, null)
  if (!cached) return res.status(404).json({ error: '暂无评测结果' })
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.setHeader('Content-Disposition', 'attachment; filename="evaluation.json"')
  res.send(JSON.stringify(cached, null, 2))
})

app.get('/api/eval/export.csv', (req, res) => {
  const cached = store.readJSON(EVAL_STORE, null)
  if (!cached) return res.status(404).json({ error: '暂无评测结果' })
  const headers = ['run_id', 'model_version', 'seed', 'id', 'set', 'group', 'category', 'kind', 'orders', 'status', 'changeover_instances', 'anomaly_injections', 'A_makespan', 'B_makespan', 'C_makespan', 'A_feasible', 'B_feasible', 'C_feasible', 'r0_makespan', 'r1_makespan', 'r1_remaining', 'r1_used_r0_fallback', 'computeTimeMs', 'failure_reason', 'events', 'validation']
  const rows = cached.cases.map((c) => {
    const r = c.result || {}
    return [
      cached.runId,
      cached.modelVersion,
      cached.seed,
      c.id,
      c.set,
      c.group,
      c.category,
      c.kind,
      (c.input.orders || []).join(' '),
      r.status,
      r.changeoverInstances != null ? r.changeoverInstances : '',
      r.anomalyInjections != null ? r.anomalyInjections : '',
      r.makespan ? r.makespan.A : '',
      r.makespan ? r.makespan.B : '',
      r.makespan ? r.makespan.C : '',
      r.feasible ? r.feasible.A : '',
      r.feasible ? r.feasible.B : '',
      r.feasible ? r.feasible.C : '',
      r.r0Makespan != null ? r.r0Makespan : '',
      r.r1Makespan != null ? r.r1Makespan : '',
      r.r1Remaining != null ? r.r1Remaining : '',
      r.usedR0Fallback != null ? r.usedR0Fallback : '',
      r.computeTimeMs != null ? r.computeTimeMs : '',
      r.reason || r.failureReason || '',
      r.events ? JSON.stringify(r.events) : '',
      r.validation ? JSON.stringify(r.validation) : ''
    ]
  })
  const csv = [headers.join(','), ...rows.map((r) => r.map(csvCell).join(','))].join('\n')
  res.setHeader('Content-Type', 'text/csv; charset=utf-8')
  res.setHeader('Content-Disposition', 'attachment; filename="evaluation.csv"')
  res.send('\ufeff' + csv)
})

function csvCell(v) {
  const s = String(v == null ? '' : v)
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s
}

// --------------------------- 策略自优化实验室（第五阶段） ---------------------------

app.get('/api/lab/status', (req, res) => {
  try {
    res.json(lab.status({ orders: DATASET.orders }))
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.post('/api/lab/analyze', (req, res) => {
  try {
    res.json(lab.analyzeDevHistory({ orders: DATASET.orders }))
  } catch (err) {
    console.error('[lab] 历史分析失败:', err)
    res.status(500).json({ error: err.message })
  }
})

app.post('/api/lab/experiment', (req, res) => {
  try {
    const body = req.body || {}
    res.json(lab.runExperiment({ orders: DATASET.orders, newRound: !!body.newRound }))
  } catch (err) {
    console.error('[lab] 参数实验失败:', err)
    res.status(500).json({ error: err.message })
  }
})

app.post('/api/lab/validate', (req, res) => {
  try {
    res.json(lab.runValidation({ orders: DATASET.orders }))
  } catch (err) {
    console.error('[lab] 验证失败:', err)
    res.status(500).json({ error: err.message })
  }
})

app.post('/api/lab/activate', (req, res) => {
  try {
    res.json({ ok: true, state: lab.activate({ orders: DATASET.orders }) })
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
})

app.post('/api/lab/rollback', (req, res) => {
  try {
    res.json({ ok: true, state: lab.rollback({ reason: req.body && req.body.reason }) })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.post('/api/lab/reset', (req, res) => {
  try {
    res.json(lab.reset({ orders: DATASET.orders }))
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

app.get('/api/lab/export.json', (req, res) => {
  const snapshot = lab.status({ orders: DATASET.orders })
  res.setHeader('Content-Type', 'application/json; charset=utf-8')
  res.setHeader('Content-Disposition', 'attachment; filename="lab-evidence.json"')
  res.send(JSON.stringify(snapshot, null, 2))
})

app.get('/api/lab/export.csv', (req, res) => {
  const snapshot = lab.status({ orders: DATASET.orders })
  const headers = ['case_id', 'category', 'orders', 'status', 'base_feasible', 'base_makespan', 'base_online_stop', 'learned_feasible', 'learned_makespan', 'learned_online_stop', 'adopted_source', 'used_fallback', 'reason']
  const rows = (snapshot.validation ? snapshot.validation.cases : []).map((c) => {
    const b = c.baseline || {}
    const l = c.learned || {}
    return [
      c.id,
      c.category,
      (c.orders || []).join(' '),
      c.status,
      b.feasible,
      b.makespan != null ? b.makespan : '',
      b.onlineStopTotal != null ? b.onlineStopTotal : '',
      l.feasible,
      l.makespan != null ? l.makespan : '',
      l.onlineStopTotal != null ? l.onlineStopTotal : '',
      c.adopted ? c.adopted.source : '',
      c.usedFallback,
      (l.reason || c.reason || '').replace(/\n/g, ' ')
    ]
  })
  const csv = [headers.join(','), ...rows.map((r) => r.map(csvCell).join(','))].join('\n')
  res.setHeader('Content-Type', 'text/csv; charset=utf-8')
  res.setHeader('Content-Disposition', 'attachment; filename="lab-validation.csv"')
  res.send('\ufeff' + csv)
})

// --------------------------- 智能协作与可核验问答（第六阶段） ---------------------------

function getCollabSnapshot(query) {
  const source = String(query.source || 'execution')
  if (source === 'plan') {
    const cached = store.readJSON(PLAN_STORE, null)
    if (!cached) throw new Error('暂无排程计划，请先生成换产计划')
    return collab.snapshotFromPlan(cached)
  }
  if (!SIM) throw new Error('暂无仿真会话，请先在异常演练中初始化会话')
  if (source === 'replay') {
    const eventIndex = query.eventIndex != null && query.eventIndex !== '' ? Number(query.eventIndex) : 0
    return collab.snapshotFromSession(SIM, { eventIndex })
  }
  const at = query.at != null && query.at !== '' ? Number(query.at) : undefined
  return collab.snapshotFromSession(SIM, { at })
}

function collabLabSummary() {
  try {
    const s = lab.status({ orders: DATASET.orders })
    return {
      collaborationVersion: collab.COLLAB_VERSION,
      selection: s.selection ? { templateId: s.selection.templateId, name: s.selection.name, devSumMakespan: s.selection.devSumMakespan, lockedAt: s.selection.lockedAt, round: s.selection.round } : null,
      validation: s.validation ? { runId: s.validation.runId, eligibleForActivation: s.validation.eligibleForActivation, reasons: s.validation.reasons, improvement: s.validation.improvement, makespan: s.validation.makespan, onlineStop: s.validation.onlineStop } : null,
      effectiveStrategy: s.effectiveStrategy,
      applicability: s.applicability
    }
  } catch (e) {
    return { error: e.message }
  }
}

app.get('/api/collab/status', (req, res) => {
  let planAvailable = false
  try { planAvailable = !!store.readJSON(PLAN_STORE, null) } catch (e) { planAvailable = false }
  res.json({
    collaborationVersion: collab.COLLAB_VERSION,
    assistantVersion: assistant.ASSISTANT_VERSION,
    modelStatus: assistant.modelStatus(),
    sources: {
      plan: { available: planAvailable, label: '计划预测' },
      execution: { available: !!SIM, label: '当前仿真执行', clock: SIM ? SIM.clock : null, sessionId: SIM ? SIM.sessionId : null },
      replay: { available: !!SIM, label: '历史回放', eventCount: SIM ? SIM.events.length : 0 }
    },
    roles: collab.ROLES.map((r) => ({ id: r.id, code: r.code, name: r.name, role: r.role })),
    reserved: { solved: false, note: '第六阶段不求解任何 reserved 保留案例，也不将其作为问答或模型上下文。' },
    declaration: '智能协作与问答为补充模型下的仿真结果，不代表工厂实测；OEE 待验证。'
  })
})

app.get('/api/collab/model-status', (req, res) => {
  res.json(assistant.modelStatus())
})

app.get('/api/collab/console', (req, res) => {
  try {
    const snapshot = getCollabSnapshot(req.query)
    const roles = collab.buildRoleStates(snapshot)
    const messages = collab.buildMessages(snapshot)
    res.json({ snapshot: summarizeSnapshot(snapshot), roles, messages })
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
})

app.get('/api/collab/export', (req, res) => {
  try {
    const snapshot = getCollabSnapshot(req.query)
    const payload = { snapshot: summarizeSnapshot(snapshot), roles: collab.buildRoleStates(snapshot), messages: collab.buildMessages(snapshot), generatedAt: new Date().toISOString() }
    res.setHeader('Content-Type', 'application/json; charset=utf-8')
    res.setHeader('Content-Disposition', 'attachment; filename="collab-console.json"')
    res.send(JSON.stringify(payload, null, 2))
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
})

app.post('/api/collab/assistant', async (req, res) => {
  try {
    const body = req.body || {}
    const snapshot = getCollabSnapshot({ source: body.source, at: body.at, eventIndex: body.eventIndex })
    const answer = await assistant.explain({ question: body.question, intent: body.intent, snapshot, lab: collabLabSummary(), allowModel: body.allowModel !== false })
    res.json(answer)
  } catch (err) {
    res.status(400).json({ error: err.message })
  }
})

function summarizeSnapshot(snapshot) {
  return {
    snapshotId: snapshot.snapshotId,
    collaborationVersion: snapshot.collaborationVersion,
    kind: snapshot.kind,
    sourceId: snapshot.sourceId,
    modelVersion: snapshot.modelVersion,
    contractDigest: snapshot.contractDigest,
    revision: snapshot.revision,
    observationTime: snapshot.observationTime,
    clock: snapshot.clock != null ? snapshot.clock : null,
    timeBasis: snapshot.timeBasis,
    orders: snapshot.orders,
    taskCount: snapshot.tasks.length,
    knownEventCount: snapshot.knownEvents.length,
    knownEvents: snapshot.knownEvents.map((e) => ({ id: e.id, type: e.event.type, target: e.event.target || (e.event.targets || []).join('+'), triggerAt: e.triggerAt, snapshotAt: e.snapshotAt, sharedSnapshotId: e.sharedSnapshotId, chosen: e.chosen, R0: e.R0.metrics.makespan, R1: e.R1.metrics.makespan, R0ok: e.R0.validation.ok, R1ok: e.R1.validation.ok, chosenFromR0: e.chosenFromR0 })),
    quality: snapshot.quality,
    lineLocks: snapshot.lineLocks,
    metrics: snapshot.metrics,
    limitations: snapshot.limitations,
    unknowns: snapshot.unknowns
  }
}

// --------------------------- 静态资源（单端口） ---------------------------

if (fs.existsSync(WEB_DIST)) {
  app.use(express.static(WEB_DIST))
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/')) return next()
    res.sendFile(path.join(WEB_DIST, 'index.html'))
  })
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[server] 协同换产指挥台已启动: http://0.0.0.0:${PORT}`)
  console.log(`[server] 静态资源目录: ${fs.existsSync(WEB_DIST) ? WEB_DIST : '（未构建，仅提供 API）'}`)
})

loadOrImportData()
