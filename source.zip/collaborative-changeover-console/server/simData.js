'use strict'

/**
 * 独立仿真数据层（Simulation Data Layer）· 统一轨迹版
 * -------------------------------------------------------------------------
 * 每个场景只有一份执行时钟、任务图与资源台账：异常直接作用在该场景当时的执行状态上，
 * 采用后的恢复计划、返工复检、资源占用与后续事件时间统一回写。事件、规模、页面与导出
 * 均由这条统一轨迹派生。产品/物料目录由实际事件引用闭合构建。
 * 所有内容均为仿真数据，不代表真实工厂历史；原始 Excel 事实未修改。
 */

const { MODEL_VERSION, TASK_TEMPLATES, EQUIPMENT, EQUIPMENT_TYPES } = require('./simulation')
const recovery = require('./recovery')

const SEED = 20261006
const CALENDAR_DAYS = 36
const CALENDAR_START = '2026-09-07'
const EVENTS_PER_SCENARIO = 6
const SCENARIO_COUNT = 13
const SCENARIO_STEP_DAYS = 3
const AS_OF_DAY = 34

function mulberry32(seed) {
  let a = seed >>> 0
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
function addDays(iso, n) {
  const [y, m, d] = iso.split('-').map(Number)
  const dt = new Date(Date.UTC(y, m - 1, d))
  dt.setUTCDate(dt.getUTCDate() + n)
  return dt.toISOString().slice(0, 10)
}
function r2(x) {
  return Math.round(x * 100) / 100
}

function selectScenarioOrders(orders, rand, usedProducts) {
  const picked = []
  const used = new Set(usedProducts)
  let guard = 0
  while (picked.length < EVENTS_PER_SCENARIO && guard++ < 8000) {
    const o = orders[Math.floor(rand() * orders.length)]
    if (used.has(o.product)) continue
    used.add(o.product)
    picked.push(o)
  }
  return picked
}

function orderOnlineWindow(entries, order) {
  const online = entries.filter((e) => e.order === order && ['line_clear', 'tooling_switch', 'param_apply', 'fai_produce', 'resume'].includes(e.key))
  if (!online.length) return null
  return { start: Math.min(...online.map((e) => e.start)), end: Math.max(...online.map((e) => e.end)) }
}

function buildSimulationData({ orders, seed = SEED, startDate = CALENDAR_START, calendarDays = CALENDAR_DAYS }) {
  const rand = mulberry32(seed)
  const orderById = new Map(orders.map((o) => [o.order, o]))
  const productMeta = new Map()
  for (const o of orders) {
    if (!productMeta.has(o.product)) productMeta.set(o.product, { product: o.product, desc: o.productDesc, materials: new Set(), faces: new Set(), totalQty: 0, bomLines: 0, orders: [] })
    const rec = productMeta.get(o.product)
    rec.totalQty += o.qty || 0
    rec.bomLines += o.bomLines || 0
    for (const f of o.faces) rec.faces.add(f)
    for (const b of o.bom) rec.materials.add(b.material)
    rec.orders.push(o.order)
  }
  const allProductIds = Array.from(productMeta.keys())
  const descMap = new Map()
  for (const o of orders) for (const b of o.bom) if (!descMap.has(b.material)) descMap.set(b.material, { desc: b.materialDesc, category: b.materialDesc })

  const LINES = ['SMT-L1', 'SMT-L2', 'SMT-L3']
  const scenarios = []
  const allEvents = []
  const abnormalRecords = []
  const usedProductsGlobal = new Set()
  const referencedProducts = new Set()
  const equipmentUsed = new Set()
  const personnelUsed = new Set()
  let eventSeq = 0
  let validScenarios = 0

  const ANOMALY_TYPES = ['agv_delay', 'person_absence', 'equipment_failure', 'fai_fail']

  for (let s = 0; s < SCENARIO_COUNT; s++) {
    const scenarioId = `SC-${String(s + 1).padStart(3, '0')}`
    const line = LINES[s % LINES.length]
    const dayOffset = Math.min(calendarDays - 1, s * SCENARIO_STEP_DAYS)
    const simDate = addDays(startDate, dayOffset)
    const planned = dayOffset > AS_OF_DAY

    const selOrders = selectScenarioOrders(orders, rand, usedProductsGlobal)
    for (const o of selOrders) usedProductsGlobal.add(o.product)

    // 场景唯一执行会话：任务图、资源日历、时钟一致。异常目标置于 orders[0] 便于追溯。
    const anomalyIdx = Math.floor(selOrders.length / 2)
    const anomalyOrder = selOrders[anomalyIdx] ? selOrders[anomalyIdx].order : null
    const orderedInput = selOrders.length ? [selOrders[anomalyIdx], ...selOrders.filter((_, i) => i !== anomalyIdx)] : selOrders
    let session = recovery.createSession({ orders: orderedInput })
    let anomalyType = null
    let anomalyDetail = null
    if (!planned && anomalyOrder && selOrders.length && s % 2 === 0) {
      const type = ANOMALY_TYPES[Math.floor(s / 2) % ANOMALY_TYPES.length]
      // 在该场景当时的执行状态上注入
      const win = orderOnlineWindow(session.actualEntries, anomalyOrder)
      let injection = null
      if (type === 'agv_delay') {
        const d = session.actualEntries.filter((e) => e.key === 'material_deliver' && e.order === anomalyOrder).sort((a, b) => a.start - b.start)[0]
        injection = d ? { type, target: d.id, at: r2(Math.max(0, d.start + 0.5)), duration: 15 } : null
      } else if (type === 'person_absence') {
        injection = win ? { type, target: 'EQP-01', at: r2(win.start), duration: 8, policy: 'finish_current' } : null
      } else if (type === 'equipment_failure') {
        injection = win ? { type, target: 'MNT-01', at: r2(win.start), duration: 8 } : null
      } else {
        injection = { type: 'fai_fail', target: anomalyOrder, at: 0 }
      }
      if (injection) {
        const res = recovery.applyEvent(session, injection)
        if (res.result.applied) {
          session = res.bundle
          const rec = res.result.eventRecord
          anomalyType = type
          anomalyDetail = { type, reserveAt: rec.reserveAt, triggerAt: rec.triggerAt, r0Makespan: rec.R0.metrics.makespan, r1Makespan: rec.R1.metrics.makespan, r0Valid: rec.R0.validation.ok, r1Valid: rec.R1.validation.ok, chosen: rec.chosen, sessionId: session.sessionId, unified: true }
          abnormalRecords.push({ eventOrder: anomalyOrder, scenarioId, type, simDate, triggerAt: rec.triggerAt, unified: true, sessionId: session.sessionId, note: '在场景执行状态上实际注入并重排（同一执行时钟/任务图/资源台账）' })
        }
      }
    }

    const trajValidation = recovery.validateTrajectory(session)
    const scenarioValidated = trajValidation.ok
    if (!planned && scenarioValidated) validScenarios++

    // 从统一轨迹派生事件（执行顺序 = 在线换产窗口先后）
    const windows = selOrders
      .map((o) => ({ order: o.order, product: o.product, win: orderOnlineWindow(session.actualEntries, o.order) }))
      .filter((x) => x.win)
      .sort((a, b) => a.win.start - b.win.start)

    let initial = null
    if (windows.length) {
      let g = 0
      initial = allProductIds[Math.floor(rand() * allProductIds.length)]
      while (initial === windows[0].product && g++ < 50) initial = allProductIds[Math.floor(rand() * allProductIds.length)]
    }
    referencedProducts.add(initial)
    let prev = initial
    const scenarioEvents = []
    for (const w of windows) {
      if (w.product === prev) continue
      const eventId = `CO-${String(++eventSeq).padStart(4, '0')}`
      const orderEntries = session.actualEntries.filter((e) => e.order === w.order && !e.id.includes('::seg@'))
      const taskInstances = orderEntries.map((e) => ({ id: `${eventId}::${e.key}`, key: e.key, name: e.name, skill: e.skill, equipment: e.equipment, duration: e.duration, assignee: e.assigneeName, kind: e.kind || 'recovery' }))
      const isAnomaly = anomalyOrder === w.order && anomalyType
      const ev = {
        eventId,
        scenarioId,
        line,
        fromProduct: prev,
        toProduct: w.product,
        sourceOrderRef: w.order,
        simDate,
        taskKeys: TASK_TEMPLATES.map((t) => t.key),
        taskInstances,
        stopStart: r2(w.win.start),
        stopStartEvent: '清线与旧工装拆卸(在线)',
        resumeTime: r2(w.win.end),
        onlineStopMin: r2(w.win.end - w.win.start),
        execStatus: planned ? '计划' : isAnomaly ? '异常' : '已完成',
        abnormal: isAnomaly ? anomalyType : null,
        anomaly: isAnomaly ? anomalyDetail : null,
        validated: !planned && scenarioValidated,
        scenarioValidated
      }
      scenarioEvents.push(ev)
      prev = w.product
      referencedProducts.add(ev.fromProduct)
      referencedProducts.add(ev.toProduct)
    }
    scenarios.push({ scenarioId, line, simDate, initialProduct: initial, planned, validated: !planned && scenarioValidated, events: scenarioEvents })
    allEvents.push(...scenarioEvents)

    for (const e of session.actualEntries) {
      if (e.equipment) equipmentUsed.add(e.equipment)
      if (e.assigneeId) personnelUsed.add(e.assigneeId)
    }
  }

  // 闭合目录：由实际事件引用的产品构建，物料为其 BOM 的并集
  const products = Array.from(referencedProducts)
    .filter((pid) => pid && productMeta.has(pid))
    .map((pid) => {
      const m = productMeta.get(pid)
      return { product: pid, desc: m.desc, faces: Array.from(m.faces), bomLines: m.bomLines, totalScheduleQty: m.totalQty, materialCount: m.materials.size, materials: Array.from(m.materials).slice(0, 400), sourceOrders: m.orders.slice(0, 10) }
    })
    .sort((a, b) => a.product.localeCompare(b.product))
  const materialSet = new Set()
  for (const p of products) for (const mat of p.materials) materialSet.add(mat)
  const materials = Array.from(materialSet)
    .map((material) => ({ material, desc: (descMap.get(material) || {}).desc || '', category: (descMap.get(material) || {}).category || '' }))
    .sort((a, b) => a.material.localeCompare(b.material))

  const catalogProducts = new Set(products.map((p) => p.product))
  const catalogMaterials = new Set(materials.map((m) => m.material))
  let missingRef = 0
  for (const ev of allEvents) {
    if (!catalogProducts.has(ev.fromProduct)) missingRef++
    if (!catalogProducts.has(ev.toProduct)) missingRef++
    const src = orderById.get(ev.sourceOrderRef)
    if (src && !catalogProducts.has(src.product)) missingRef++
    for (const t of ev.taskInstances) if (t.equipment && !EQUIPMENT.some((x) => x.id === t.equipment)) missingRef++
  }
  for (const p of products) for (const mat of p.materials) if (!catalogMaterials.has(mat)) missingRef++

  const executed = allEvents.filter((e) => e.execStatus !== '计划')
  const completed = executed.filter((e) => e.execStatus === '已完成')
  const abnormal = executed.filter((e) => e.execStatus === '异常')
  const plannedCount = allEvents.filter((e) => e.execStatus === '计划').length
  const validChangeovers = executed.filter((e) => e.validated).length

  const dates = Array.from({ length: calendarDays }, (_, i) => addDays(startDate, i))
  const execDates = executed.map((e) => e.simDate).sort()
  const eventSpanDays = execDates.length ? Math.round((new Date(execDates[execDates.length - 1]) - new Date(execDates[0])) / 86400000) : 0

  const stats = {
    calendarDays,
    spanDays: calendarDays - 1,
    eventSpanDays,
    scenarioCount: scenarios.length,
    scenarioValidatedCount: validScenarios,
    eventTotal: allEvents.length,
    eventPlanned: plannedCount,
    eventCompleted: completed.length,
    eventAbnormal: abnormal.length,
    validChangeovers,
    distinctEventCount: new Set(allEvents.map((e) => e.eventId)).size,
    distinctProducts: products.length,
    distinctMaterials: materials.length,
    personnelRoster: 12,
    personnelAvailableAtZero: 8,
    personnelActuallyUsed: personnelUsed.size,
    equipmentTypeCount: EQUIPMENT_TYPES.length,
    equipmentInventoryCount: EQUIPMENT.length,
    equipmentActuallyUsed: equipmentUsed.size,
    referenceIntegrity: { productsReferenced: referencedProducts.size, productsInCatalog: products.length, materialsInCatalog: materials.length, unresolvedReferences: missingRef },
    sourceDataUnchanged: { rows: 5424, orders: orders.length, products: 88, materials: 1276, deliveryDate: '2026-09-07' }
  }

  return {
    modelVersion: MODEL_VERSION,
    seed,
    generatedAt: new Date().toISOString(),
    declaration: '本数据层为仿真数据，不代表真实工厂历史；原始 Excel 事实未修改。事件与规模由每个场景的统一执行轨迹派生。',
    asOfDay: AS_OF_DAY,
    calendar: { start: startDate, end: addDays(startDate, calendarDays - 1), days: calendarDays, dates },
    products,
    materials,
    scenarios,
    events: allEvents,
    abnormalRecords,
    stats,
    dataDictionary: DATA_DICTIONARY
  }
}

const DATA_DICTIONARY = {
  calendar: { start: '仿真日历起始日', end: '仿真日历结束日', days: '自然日天数', dates: '日期列表' },
  products: { product: '成品专用号（来自原始 BOM）', desc: '成品描述', faces: '装配面', bomLines: 'BOM 行数', totalScheduleQty: '关联订单排产数量合计', materialCount: '关联物料种类数', materials: '物料编码列表', sourceOrders: '来源订单引用' },
  materials: { material: '物料编码', desc: '物料描述', category: '物料分类' },
  events: { eventId: '换产事件编号（任务实例前缀）', scenarioId: '场景编号', line: '产线', fromProduct: '来源产品', toProduct: '目标产品', sourceOrderRef: '来源订单引用（仅引用原 BOM 订单）', simDate: '仿真日期', taskKeys: '换产工序类型', taskInstances: '以 eventId 命名的真实任务实例（含返工/复检）', stopStart: '停线开始', resumeTime: '恢复生产时间', onlineStopMin: '在线停线时长', execStatus: '执行状态（计划/已完成/异常）', abnormal: '异常类型', anomaly: '场景内异常恢复结果', validated: '是否通过整场景独立验证', scenarioValidated: '场景轨迹是否独立验证通过' },
  stats: '由统一执行轨迹派生的规模、资源使用与引用完整性'
}

module.exports = { buildSimulationData, SEED, CALENDAR_DAYS, CALENDAR_START, DATA_DICTIONARY, mulberry32, addDays }
