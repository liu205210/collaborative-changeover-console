'use strict'

const { makePrepPriority } = require('./prepPriority')

const EPS = 1e-9

const ONLINE_KEYS = new Set(['line_clear', 'tooling_switch', 'param_apply', 'fai_produce', 'resume'])
const LINE_BAND_KEYS = ['line_clear', 'tooling_switch', 'param_apply', 'fai_inspect', 'quality_release', 'resume']

// ---------------------------------------------------------------------------
// 基础工具
// ---------------------------------------------------------------------------

function round(x, p = 2) {
  const f = Math.pow(10, p)
  return Math.round(x * f) / f
}

function overlaps(intervals, s, e) {
  for (const [a, b] of intervals) {
    if (s < b - EPS && e > a + EPS) return true
  }
  return false
}

function firstFreeSlot(intervals, from, dur) {
  let t = from
  const arr = intervals.slice().sort((x, y) => x[0] - y[0])
  let guard = 0
  while (guard++ < 5000) {
    let conflict = null
    for (const iv of arr) {
      if (t < iv[1] - EPS && t + dur > iv[0] + EPS) {
        conflict = iv
        break
      }
    }
    if (!conflict) return t
    t = conflict[1]
  }
  return t
}

function mulberry32(seed) {
  let a = seed >>> 0
  return function () {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

// ---------------------------------------------------------------------------
// 资源账本（只承载人员与离线独占资源；产线由“换产带”串行分配）
// ---------------------------------------------------------------------------

// 规划视界：由所提供的人员班次日历决定（最大值），不得用有限哨兵值假装可行
const PLANNING_HORIZON = 1440

function shiftHorizon(personnel) {
  let h = PLANNING_HORIZON
  for (const p of personnel || []) if (Array.isArray(p.shiftWindow)) h = Math.max(h, p.shiftWindow[1])
  return h
}

function makeBanks(personnel, exclusive, equipment) {
  const skills = new Map()
  for (const p of personnel) {
    if (!skills.has(p.skill)) skills.set(p.skill, [])
    const intervals = []
    // 班次窗口外的时段视为不可用；规划视界外亦不可用（无“无限可用”哨兵）
    if (Array.isArray(p.shiftWindow)) {
      intervals.push([-PLANNING_HORIZON, p.shiftWindow[0]])
      intervals.push([p.shiftWindow[1], PLANNING_HORIZON])
    }
    skills.get(p.skill).push({ ...p, intervals })
  }
  const exclusiveBanks = new Map()
  for (const e of exclusive) {
    if (e.id === 'LINE-01') continue // 产线由换产带统一管理，不进入通用账本
    exclusiveBanks.set(e.id, { ...e, intervals: [] })
  }
  for (const eq of equipment || []) {
    if (!exclusiveBanks.has(eq.id)) exclusiveBanks.set(eq.id, { ...eq, intervals: [] })
  }
  return { skills, exclusiveBanks, horizon: shiftHorizon(personnel) }
}

function equipmentOptions(banks, task) {
  if (!task.equipment) return []
  return [task.equipment, ...(task.equipmentAlternatives || [])].filter((id) => banks.exclusiveBanks.has(id))
}

function earliestEquipment(banks, task, from, dur) {
  const opts = equipmentOptions(banks, task)
  if (!opts.length) return { id: null, start: from, missing: !!task.equipment }
  let best = Infinity
  let bestId = null
  for (const id of opts) {
    const s = firstFreeSlot(banks.exclusiveBanks.get(id).intervals, from, dur)
    if (s < best - EPS) {
      best = s
      bestId = id
    }
  }
  return { id: bestId, start: Number.isFinite(best) ? best : from, missing: false }
}

function pickAssignment(banks, task, est) {
  const dur = task.duration
  const qualified = banks.skills.get(task.skill) || []
  if (!qualified.length) return { start: est, person: null, eqId: null, error: `无可用工种: ${task.skill}` }
  let start = est
  let person = null
  let chosenEq = null
  for (let i = 0; i < 80; i++) {
    let lower = start
    if (task.exclusive && task.exclusive !== 'LINE-01' && banks.exclusiveBanks.has(task.exclusive)) {
      lower = Math.max(lower, firstFreeSlot(banks.exclusiveBanks.get(task.exclusive).intervals, lower, dur))
    }
    const eq = earliestEquipment(banks, task, lower, dur)
    if (eq.missing) return { start: lower, person: null, eqId: null, error: `设备库存缺少任务 ${task.id} 所需设备` }
    lower = Math.max(lower, eq.start)
    chosenEq = eq.id
    let best = null
    let bestStart = Infinity
    for (const p of qualified) {
      const ps = firstFreeSlot(p.intervals, lower, dur)
      if (ps < bestStart - EPS) {
        bestStart = ps
        best = p
      }
    }
    if (!best) return { start: lower, person: null, eqId: chosenEq, error: '无可用人员' }
    person = best
    const newStart = Math.max(lower, bestStart)
    if (Math.abs(newStart - start) < EPS) {
      start = newStart
      break
    }
    start = newStart
  }
  if (start + dur > banks.horizon + EPS) {
    return { start, person: null, eqId: chosenEq, error: `班次/资源日历内无足够可用时段（需 ${dur} 分钟，视界 ${banks.horizon} 分钟）` }
  }
  return { start, person, eqId: chosenEq, error: null }
}

function commitAssignment(banks, task, start, person, eqId) {
  const dur = task.duration
  if (person) person.intervals.push([start, start + dur])
  if (task.exclusive && task.exclusive !== 'LINE-01') {
    const ex = banks.exclusiveBanks.get(task.exclusive)
    if (ex) ex.intervals.push([start, start + dur])
  }
  if (eqId && banks.exclusiveBanks.has(eqId)) {
    banks.exclusiveBanks.get(eqId).intervals.push([start, start + dur])
  }
}

function earliestPersonForSkill(banks, skill, from, dur) {
  const qualified = banks.skills.get(skill) || []
  let best = null
  let bestStart = Infinity
  for (const p of qualified) {
    const ps = firstFreeSlot(p.intervals, from, dur)
    if (ps < bestStart - EPS) {
      bestStart = ps
      best = p
    }
  }
  return best ? { start: bestStart, person: best } : null
}

// ---------------------------------------------------------------------------
// 离线准备任务排程（SGS，在所有订单之间全局共享资源）
// ---------------------------------------------------------------------------

function schedulePrep(prepTasks, priorityIndex, banks, startOffset = 0) {
  if (!prepTasks.length) return []
  const scheduled = new Map()
  const unscheduled = prepTasks.slice()
  const out = []
  let guard = 0
  while (unscheduled.length && guard++ < 200000) {
    let task = null
    let bestKey = Infinity
    for (const t of unscheduled) {
      const ready = t.deps.every((d) => !prepTasks.some((x) => x.id === d) || scheduled.has(d))
      if (!ready) continue
      const key = priorityIndex ? priorityIndex(t) : 0
      // 确定性并列：优先级相同按 task.id 字典序（原 C 各优先级函数取值互异，不影响原行为）
      if (key < bestKey - EPS || (task && Math.abs(key - bestKey) <= EPS && t.id < task.id)) {
        bestKey = key
        task = t
      }
    }
    if (!task) break
    let est = Math.max(startOffset, task.release || 0)
    for (const d of task.deps) {
      const s = scheduled.get(d)
      if (s) est = Math.max(est, s.end)
    }
    const { start, person, eqId, error } = pickAssignment(banks, task, est)
    if (error) throw new Error(`${error} (${task.id})`)
    commitAssignment(banks, task, start, person, eqId)
    const entry = makeEntry(task, start, person, est, eqId)
    scheduled.set(task.id, entry)
    out.push(entry)
    unscheduled.splice(unscheduled.indexOf(task), 1)
  }
  return out
}

function makeEntry(task, start, person, depEarliest, eqId) {
  return {
    id: task.id,
    key: task.key,
    name: task.name,
    phase: task.phase,
    order: task.order,
    product: task.product,
    skill: task.skill,
    skillLabel: task.skillLabel,
    exclusive: task.exclusive,
    equipment: eqId || null,
    equipmentAlternatives: task.equipmentAlternatives || [],
    mode: task.mode,
    stage: task.stage,
    deps: task.deps || [],
    release: task.release || 0,
    duration: round(task.duration),
    assigneeId: person.id,
    assigneeName: person.name,
    start: round(start),
    end: round(start + task.duration),
    depEarliest: round(depEarliest),
    resourceWait: round(Math.max(0, start - depEarliest)),
    delayedByResource: start > depEarliest + EPS
  }
}

// ---------------------------------------------------------------------------
// 在线换产带：同一订单的在线作业原子占线；带内质量环节保持产线锁定
// ---------------------------------------------------------------------------

function scheduleLineBands(taskById, orderSequence, banks, lineFree, opts = {}) {
  const lineBlocks = (opts.lineBlocks || []).slice().sort((a, b) => a[0] - b[0])
  const release = opts.release || 0
  const entries = []
  let cursor = Math.max(lineFree, release)

  function avoidBlocks(t, dur) {
    let x = t
    let guard = 0
    while (guard++ < 50) {
      const hit = lineBlocks.find(([a, b]) => x < b - EPS && x + dur > a + EPS)
      if (!hit) return x
      x = hit[1]
    }
    return x
  }
  function placeOnline(task, lower) {
    let t = avoidBlocks(Math.max(lower, release), task.duration)
    for (let i = 0; i < 80; i++) {
      const eq = earliestEquipment(banks, task, t, task.duration)
      if (eq.missing) throw new Error(`设备库存缺少任务 ${task.id} 所需设备`)
      const cur = Math.max(t, eq.start)
      const p = earliestPersonForSkill(banks, task.skill, cur, task.duration)
      if (!p) throw new Error(`任务 ${task.id} 无法在班次/资源日历内安排（无可派人员）`)
      let start = Math.max(cur, p.start)
      const adj = avoidBlocks(start, task.duration)
      if (adj > start + EPS) {
        t = adj
        continue
      }
      const eq2 = earliestEquipment(banks, task, start, task.duration)
      if (eq2.start > start + EPS) {
        t = eq2.start
        continue
      }
      const p2 = earliestPersonForSkill(banks, task.skill, start, task.duration)
      if (p2 && p2.start <= start + EPS) {
        if (start + task.duration > banks.horizon + EPS) throw new Error(`任务 ${task.id} 超出班次/资源日历视界`)
        p2.person.intervals.push([start, start + task.duration])
        if (eq2.id) banks.exclusiveBanks.get(eq2.id).intervals.push([start, start + task.duration])
        return { start, person: p2.person, eqId: eq2.id }
      }
      t = p2 ? p2.start : start + task.duration
      if (t > banks.horizon + EPS) throw new Error(`任务 ${task.id} 超出班次/资源日历视界`)
    }
    throw new Error(`任务 ${task.id} 无法在班次/资源日历内安排`)
  }

  function placeOffline(task, lower) {
    const r = pickAssignment(banks, task, Math.max(lower, release))
    if (r.error) throw new Error(r.error)
    commitAssignment(banks, task, r.start, r.person, r.eqId)
    return r
  }

  for (const order of orderSequence) {
    const get = (key) => taskById.get(`${order}::${key}`)
    const prepEnd = (key) => (get(key) ? get(key).end : 0)

    // 清线与旧工装拆卸：产线锁定开始（在离线准备与线边配送完成后停线）
    const lcTask = get('line_clear')
    const lcLower = Math.max(cursor, lcTask.release || 0, prepEnd('tooling_prep'), prepEnd('material_deliver'))
    const lc = placeOnline(lcTask, lcLower)
    const lcStart = lc.start
    const lcEnd = lcStart + lcTask.duration
    entries.push(makeEntry(lcTask, lcStart, lc.person, Math.max(prepEnd('tooling_prep'), prepEnd('material_deliver')), lc.eqId))

    // 工装切换(在线)
    const swTask = get('tooling_switch')
    const swLower = Math.max(lcEnd, prepEnd('tooling_prep'), prepEnd('material_deliver'))
    const sw = placeOnline(swTask, swLower)
    const swStart = sw.start
    const swEnd = swStart + swTask.duration
    entries.push(makeEntry(swTask, swStart, sw.person, Math.max(prepEnd('tooling_prep'), prepEnd('material_deliver')), sw.eqId))

    // 参数应用与校准(在线)
    const apTask = get('param_apply')
    const apLower = Math.max(swEnd, prepEnd('param_prepare'))
    const ap = placeOnline(apTask, apLower)
    const apStart = ap.start
    const apEnd = apStart + apTask.duration
    entries.push(makeEntry(apTask, apStart, ap.person, swEnd, ap.eqId))

    // 首件生产(在线)
    const prTask = get('fai_produce')
    const pr = placeOnline(prTask, apEnd)
    const prStart = pr.start
    const prEnd = prStart + prTask.duration
    entries.push(makeEntry(prTask, prStart, pr.person, apEnd, pr.eqId))

    // 首件检验(离线，但产线保持锁定)
    const inTask = get('fai_inspect')
    const ins = placeOffline(inTask, prEnd)
    const inStart = ins.start
    const inEnd = inStart + inTask.duration
    entries.push(makeEntry(inTask, inStart, ins.person, prEnd, ins.eqId))

    // 质量放行(离线)
    const rlTask = get('quality_release')
    const rl = placeOffline(rlTask, inEnd)
    const rlStart = rl.start
    const rlEnd = rlStart + rlTask.duration
    entries.push(makeEntry(rlTask, rlStart, rl.person, inEnd, rl.eqId))

    // 恢复生产(在线)：产线锁定结束
    const rsTask = get('resume')
    const rs = placeOnline(rsTask, rlEnd)
    const rsStart = rs.start
    const rsEnd = rsStart + rsTask.duration
    entries.push(makeEntry(rsTask, rsStart, rs.person, rlEnd, rs.eqId))

    cursor = rsEnd
  }
  return { entries, lineFree: cursor }
}

// ---------------------------------------------------------------------------
// 优先级规则
// ---------------------------------------------------------------------------

const TPL_ORDER = ['material_pick', 'material_deliver', 'tooling_prep', 'param_prepare', 'line_clear', 'tooling_switch', 'param_apply', 'fai_produce', 'fai_inspect', 'quality_release', 'resume']

function templateRank(orderSequence) {
  const orderIdx = new Map(orderSequence.map((o, i) => [o, i]))
  const tplIdx = new Map(TPL_ORDER.map((k, i) => [k, i]))
  return (t) => (orderIdx.get(t.order) ?? 0) * 100 + (tplIdx.get(t.key) ?? 0)
}

function criticalPathRank(tasks) {
  const succ = new Map()
  for (const t of tasks) succ.set(t.id, [])
  for (const t of tasks) for (const d of t.deps) if (succ.has(d)) succ.get(d).push(t.id)
  const memo = new Map()
  function depth(id) {
    if (memo.has(id)) return memo.get(id)
    const t = tasks.find((x) => x.id === id)
    if (!t) return 0
    let m = 0
    for (const s of succ.get(id) || []) m = Math.max(m, depth(s))
    const v = t.duration + m
    memo.set(id, v)
    return v
  }
  const score = new Map(tasks.map((t) => [t.id, depth(t.id)]))
  const order = tasks.slice().sort((a, b) => score.get(b.id) - score.get(a.id))
  const rank = new Map(order.map((t, i) => [t.id, i]))
  return (t) => rank.get(t.id) ?? 0
}

// ---------------------------------------------------------------------------
// 三种策略
// ---------------------------------------------------------------------------

function splitTasks(tasks) {
  const prep = tasks.filter((t) => t.stage === 'prep')
  const taskById = new Map(tasks.map((t) => [t.id, t]))
  return { prep, taskById }
}

function runPipeline(tasks, orderSequence, prepPriority, personnel, exclusive, equipment, lineFreeStart = 0, prepStartOffset = 0) {
  const { prep, taskById } = splitTasks(tasks)
  const banks = makeBanks(personnel, exclusive, equipment)
  const prepEntries = schedulePrep(prep, prepPriority, banks, prepStartOffset)
  // 用离线准备结果刷新 taskById 的 end 时间，供换产带读取
  for (const e of prepEntries) {
    const t = taskById.get(e.id)
    if (t) t.end = e.end
  }
  // 无准备任务的订单，其前置完成时间按 0 处理
  for (const t of taskById.values()) {
    if (t.stage === 'prep' && t.end === undefined) t.end = 0
  }
  const band = scheduleLineBands(taskById, orderSequence, banks, lineFreeStart)
  return { entries: prepEntries.concat(band.entries), banks }
}

function buildStrategyA(tasks, orderSequence, personnel, exclusive, equipment) {
  // A：当前订单串行推进的仿真 SOP 对照。
  // 同一时刻只推进一个订单：该订单的离线准备完成后再进入在线换产带。
  const { prep, taskById } = splitTasks(tasks)
  let cursor = 0
  const entries = []
  for (const order of orderSequence) {
    const orderPrep = prep.filter((t) => t.order === order)
    const banks = makeBanks(personnel, exclusive, equipment)
    const prepEntries = schedulePrep(orderPrep, templateRank([order]), banks, cursor)
    for (const e of prepEntries) {
      const t = taskById.get(e.id)
      if (t) t.end = e.end
    }
    const band = scheduleLineBands(taskById, [order], banks, cursor)
    entries.push(...prepEntries, ...band.entries)
    cursor = band.lineFree
  }
  return {
    mode: 'A',
    modeName: '方案A · 订单串行 SOP 对照（对照策略假设）',
    description:
      '当前订单串行推进的仿真 SOP 对照：同一时刻只推进一个订单，该订单离线准备完成后才进入在线换产带。' +
      '“订单串行推进”属于对照策略假设，不作为最优策略。',
    entries: entries.sort(byStart),
    strategyAssumption: '订单串行推进（对照假设）'
  }
}

function buildStrategyB(tasks, orderSequence, personnel, exclusive, equipment) {
  // B：允许跨订单离线准备，在线阶段保持相同产线状态约束，采用固定优先级。
  const { prep } = splitTasks(tasks)
  const result = runPipeline(tasks, orderSequence, templateRank(orderSequence), personnel, exclusive, equipment)
  return {
    mode: 'B',
    modeName: '方案B · 跨订单离线准备 + 固定优先级',
    description:
      '允许后续订单的物料拣配、离线工装准备、参数方案准备提前并行；在线阶段保持与方案C完全相同的产线状态一致性约束；' +
      '订单上线顺序与离线准备优先级均使用固定规则。',
    entries: result.entries.sort(byStart),
    strategyAssumption: '固定优先级（订单给定顺序 + 工序模板顺序）'
  }
}

function enumerateSequences(orderSequence) {
  return orderSequence.length <= 5 ? permutations(orderSequence) : heuristicSequences(orderSequence)
}

// 原 C 的固定候选优先级集合（模板顺序 + 关键路径 + 40 组随机起点），行为与旧版一致
function candidateRanksOriginal(tasks, orderSequence, seed) {
  const rand = mulberry32(seed)
  const ranks = []
  ranks.push(templateRank(orderSequence))
  ranks.push(criticalPathRank(tasks))
  for (let i = 0; i < 40; i++) {
    const score = new Map(tasks.map((t) => [t.id, rand()]))
    ranks.push((t) => score.get(t.id))
  }
  return ranks
}

// 统一候选排程尝试搜索：ranksForSeq 为每个订单顺序提供候选优先级函数；
// budget 为候选排程尝试上限（原 C 与 C-learned 使用相同上限），attempts 为实际计数。
function searchCBudgeted(tasks, seqs, personnel, exclusive, equipment, ranksForSeq, budget) {
  let best = null
  let attempts = 0
  let lastError = null
  for (const seq of seqs) {
    const ranks = ranksForSeq(seq)
    for (const rank of ranks) {
      if (budget != null && attempts >= budget) return { best, attempts, lastError }
      attempts++
      let result
      try {
        result = runPipeline(tasks, seq, rank, personnel, exclusive, equipment)
      } catch (e) {
        lastError = e
        continue
      }
      const makespan = result.entries.reduce((m, e) => Math.max(m, e.end), 0)
      const conflicts = result.entries.filter((e) => e.delayedByResource).length
      if (!best || makespan < best.makespan - EPS || (Math.abs(makespan - best.makespan) < EPS && conflicts < best.conflicts)) {
        best = { entries: result.entries, makespan, conflicts, sequence: seq }
      }
    }
  }
  return { best, attempts, lastError }
}

// 全部候选失败时抛出带业务原因与实际尝试次数的错误（不丢失预算消耗）
function noFeasibleCError(attempts, budget, lastError) {
  const reason = lastError && lastError.message ? lastError.message : '所有候选排程均不可行'
  const err = new Error(`方案C 无可行排程：${reason}`)
  err.reason = reason
  err.attempts = attempts
  err.candidateAttempts = attempts
  err.maxCandidateAttempts = budget != null ? budget : null
  return err
}

function buildStrategyC(tasks, orderSequence, personnel, exclusive, equipment, seed = 20261005) {
  // C：与B相同的并行权限与物理约束，采用协同优化策略（订单上线顺序 + 离线准备优先级联合寻优）。
  const seqs = enumerateSequences(orderSequence)
  const ranks = candidateRanksOriginal(tasks, orderSequence, seed)
  const budget = seqs.length * ranks.length
  const { best, attempts, lastError } = searchCBudgeted(tasks, seqs, personnel, exclusive, equipment, () => ranks, budget)
  if (!best) throw noFeasibleCError(attempts, budget, lastError)
  return {
    mode: 'C',
    modeName: '方案C · 协同优化排程',
    description:
      '与方案B使用完全相同的订单、任务耗时、人员、资源、初始状态与产线状态一致性约束；' +
      '在允许的并行权限下，对订单上线顺序与离线准备优先级进行联合寻优，取可行解中总历时最短方案。',
    entries: best.entries.sort(byStart),
    optimizedSequence: best.sequence,
    strategyAssumption: '协同优化（订单顺序 + 离线优先级联合寻优）',
    learned: false,
    candidateAttempts: attempts,
    maxCandidateAttempts: budget
  }
}

// C-learned：订单顺序仍做联合寻优，但离线准备优先级使用学习得到的可解释参数（单一优先级函数）。
// 预算上限与原 C 相同（seqs.length × 42），实际尝试次数单独计数。
function buildStrategyCLearned(tasks, orderSequence, personnel, exclusive, equipment, weights, opts = {}) {
  const seqs = enumerateSequences(orderSequence)
  const naturalBudget = seqs.length * 42
  const budget = opts.maxAttempts != null ? opts.maxAttempts : naturalBudget
  const { best, attempts, lastError } = searchCBudgeted(tasks, seqs, personnel, exclusive, equipment, (seq) => [makePrepPriority(weights, seq, tasks)], budget)
  if (!best) throw noFeasibleCError(attempts, budget, lastError)
  return {
    mode: 'C',
    modeName: '方案C-learned · 协同优化排程（学习参数）',
    description:
      '在线阶段与方案C完全相同的订单、任务耗时、人员、资源、初始状态与产线状态一致性约束；' +
      '订单上线顺序仍联合寻优，离线准备优先级改用从开发集历史中选择的可解释参数（仅影响离线准备任务的排序）。',
    entries: best.entries.sort(byStart),
    optimizedSequence: best.sequence,
    strategyAssumption: '协同优化 + 学习后的离线准备优先级',
    learned: true,
    learnedWeights: weights,
    candidateAttempts: attempts,
    maxCandidateAttempts: budget
  }
}

function permutations(arr) {
  if (arr.length <= 1) return [arr.slice()]
  const out = []
  for (let i = 0; i < arr.length; i++) {
    const rest = arr.slice(0, i).concat(arr.slice(i + 1))
    for (const p of permutations(rest)) out.push([arr[i], ...p])
  }
  return out
}

function heuristicSequences(orderSequence) {
  const by = (fn) => orderSequence.slice().sort(fn)
  return [orderSequence.slice(), by((a, b) => a.localeCompare(b)), by((a, b) => b.localeCompare(a)), by((a, b) => String(a).length - String(b).length)]
}

function byStart(a, b) {
  return a.start - b.start || (a.order < b.order ? -1 : 1) || (a.key < b.key ? -1 : 1)
}

// ---------------------------------------------------------------------------
// 指标计算（含开始/结束事件与公式）
// ---------------------------------------------------------------------------

function computeMetrics(entries, personnel, exclusive, orders, equipment) {
  const makespan = entries.reduce((m, e) => Math.max(m, e.end), 0)
  const resourceWaitTotal = entries.reduce((s, e) => s + e.resourceWait, 0)
  const conflictEvents = entries.filter((e) => e.delayedByResource).length
  const utilMap = new Map()
  for (const p of personnel) utilMap.set(p.id, { id: p.id, name: p.name, skill: p.skill, busy: 0 })
  for (const e of entries) {
    const u = utilMap.get(e.assigneeId)
    if (u) u.busy += e.duration
  }
  const utilization = Array.from(utilMap.values()).map((u) => ({
    ...u,
    busy: round(u.busy),
    utilizationPct: makespan ? round((u.busy / makespan) * 100, 1) : 0
  }))
  const exclusiveUsage = (exclusive || []).map((ex) => {
    const used = entries.filter((e) => e.exclusive === ex.id).reduce((s, e) => s + e.duration, 0)
    return { id: ex.id, name: ex.name, busy: round(used), utilizationPct: makespan ? round((used / makespan) * 100, 1) : 0 }
  })
  const equipmentUsage = (equipment || []).map((eq) => {
    const used = entries.filter((e) => e.equipment === eq.id).reduce((s, e) => s + e.duration, 0)
    return { id: eq.id, type: eq.type, name: eq.name, busy: round(used), utilizationPct: makespan ? round((used / makespan) * 100, 1) : 0 }
  })

  const orderMetrics = (orders || []).map((o) => {
    const id = typeof o === 'string' ? o : o.order
    const prep = entries.filter((e) => e.order === id && e.stage === 'prep')
    const onlines = entries.filter((e) => e.order === id && e.stage === 'line')
    const firstOnline = onlines.length ? onlines.reduce((a, b) => (a.start <= b.start ? a : b)) : null
    const rs = entries.find((e) => e.order === id && e.key === 'resume')
    const pr = entries.find((e) => e.order === id && e.key === 'fai_produce')
    const prepStart = prep.length ? Math.min(...prep.map((e) => e.start)) : 0
    const prepEnd = prep.length ? Math.max(...prep.map((e) => e.end)) : 0
    const prepWork = prep.reduce((s, e) => s + e.duration, 0)
    return {
      order: id,
      prepStart: round(prepStart),
      prepEnd: round(prepEnd),
      prepSpanMin: round(Math.max(0, prepEnd - prepStart)),
      prepWorkMin: round(prepWork),
      stopStartEvent: firstOnline ? firstOnline.name : '—',
      onlineStart: firstOnline ? firstOnline.start : 0,
      onlineEnd: rs ? rs.end : 0,
      onlineStopMin: firstOnline && rs ? round(rs.end - firstOnline.start) : 0,
      produceStart: pr ? pr.start : 0
    }
  })

  const onlineStopTotal = round(orderMetrics.reduce((s, m) => s + m.onlineStopMin, 0))
  const offlinePrepTotal = round(orderMetrics.reduce((s, m) => s + m.prepWorkMin, 0))
  const offlinePrepSpanTotal = round(orderMetrics.reduce((s, m) => s + m.prepSpanMin, 0))

  return {
    makespan: round(makespan),
    criticalPath: round(computeCriticalPath(entries)),
    taskCount: entries.length,
    resourceWaitTotal: round(resourceWaitTotal),
    conflictEvents,
    onlineStopTotal,
    offlinePrepTotal,
    offlinePrepSpanTotal,
    orderMetrics,
    utilization,
    exclusiveUsage,
    equipmentUsage
  }
}

function computeCriticalPath(entries) {
  // 依据 entries 的依赖关系重算关键路径（不依赖任务模板）
  const byId = new Map(entries.map((e) => [e.id, e]))
  const depsOf = (e) => e.deps || []
  const memo = new Map()
  function depth(id) {
    if (memo.has(id)) return memo.get(id)
    const e = byId.get(id)
    if (!e) return 0
    let m = 0
    for (const d of depsOf(e)) m = Math.max(m, depth(d))
    const v = e.duration + m
    memo.set(id, v)
    return v
  }
  let best = 0
  for (const e of entries) best = Math.max(best, depth(e.id))
  return best
}

// ---------------------------------------------------------------------------
// 独立验证器
// ---------------------------------------------------------------------------

function validateSchedule(entries, tasks, personnel, options = {}) {
  const checks = []
  const violations = []
  const skillOf = new Map(personnel.map((p) => [p.id, p.skill]))
  const taskById = new Map(tasks.map((t) => [t.id, t]))
  const byId = new Map()
  const now = Date.now()

  // 1. 完整性与唯一性
  let dupCount = 0
  for (const e of entries) {
    if (byId.has(e.id)) dupCount++
    byId.set(e.id, e)
  }
  const missing = tasks.filter((t) => !byId.has(t.id)).map((t) => t.id)
  const extra = entries.filter((e) => !taskById.has(e.id)).map((e) => e.id)
  const complete = dupCount === 0 && missing.length === 0 && extra.length === 0
  if (dupCount) violations.push({ type: 'completeness', detail: `${dupCount} 个任务重复出现` })
  if (missing.length) violations.push({ type: 'completeness', detail: `缺失 ${missing.length} 个任务：${missing.slice(0, 5).join('、')}` })
  if (extra.length) violations.push({ type: 'completeness', detail: `出现 ${extra.length} 个未知任务` })
  checks.push({
    name: '任务完整性与唯一性检查',
    status: complete ? 'pass' : 'fail',
    detail: complete ? `任务完整：${entries.length} 个任务全部执行且无重复` : `完整性异常：重复 ${dupCount}，缺失 ${missing.length}，多余 ${extra.length}`,
    violations: (dupCount ? 1 : 0) + missing.length + extra.length
  })

  // 2. 前置依赖
  let depViolations = 0
  for (const t of tasks) {
    const e = byId.get(t.id)
    if (!e) continue
    for (const d of t.deps) {
      const de = byId.get(d)
      if (!de) {
        depViolations++
        violations.push({ type: 'precedence', task: t.id, detail: `缺少前序任务 ${d}` })
      } else if (de.end > e.start + 1e-6) {
        depViolations++
        violations.push({ type: 'precedence', task: t.id, detail: `${t.name} 在 ${d} 完成前开始（${de.end} > ${e.start}）` })
      }
    }
  }
  checks.push({
    name: '前置依赖检查',
    status: depViolations === 0 ? 'pass' : 'fail',
    detail: depViolations === 0 ? '全部任务满足工序先后依赖' : `${depViolations} 处依赖违例`,
    violations: depViolations
  })

  // 3. 人员技能匹配
  let skillViolations = 0
  for (const e of entries) {
    const t = taskById.get(e.id)
    if (t && skillOf.get(e.assigneeId) !== t.skill) {
      skillViolations++
      violations.push({ type: 'skill', task: e.id, detail: `${e.assigneeName} 技能与 ${t.skillLabel} 不匹配` })
    }
  }
  checks.push({
    name: '人员技能匹配检查',
    status: skillViolations === 0 ? 'pass' : 'fail',
    detail: skillViolations === 0 ? '所有任务均分配到具备对应技能的合格人员' : `${skillViolations} 处技能不匹配`,
    violations: skillViolations
  })

  // 3b. 班次可用时间 + 设备库存成员/替代资格/容量
  let shiftViolations = 0
  let equiViolations = 0
  const personById = new Map(personnel.map((p) => [p.id, p]))
  const invSet = options.equipment ? new Set(options.equipment.map((e) => e.id)) : null
  for (const e of entries) {
    const p = personById.get(e.assigneeId)
    if (p && Array.isArray(p.shiftWindow)) {
      if (e.start < p.shiftWindow[0] - 1e-6 || e.end > p.shiftWindow[1] + 1e-6) {
        shiftViolations++
        violations.push({ type: 'shift', task: e.id, detail: `${e.id} 超出 ${p.name} 班次 [${p.shiftWindow[0]},${p.shiftWindow[1]}]（${e.start}→${e.end}）` })
      }
    }
    const t = taskById.get(e.id)
    if (t && t.equipment) {
      const qualified = e.equipment === t.equipment || (t.equipmentAlternatives || []).includes(e.equipment)
      if (!e.equipment || !qualified) {
        equiViolations++
        violations.push({ type: 'equipment', task: e.id, detail: `${e.id} 设备 ${e.equipment || '无'} 不符合任务所需 ${t.equipment} 及其替代资格` })
      } else if (invSet && !invSet.has(e.equipment)) {
        equiViolations++
        violations.push({ type: 'equipment_inventory', task: e.id, detail: `${e.id} 使用库存外设备 ${e.equipment}` })
      }
    }
  }
  checks.push({
    name: '班次可用时间检查',
    status: shiftViolations === 0 ? 'pass' : 'fail',
    detail: shiftViolations === 0 ? '所有任务均落在执行人班次可用时段内' : `${shiftViolations} 处超出班次`,
    violations: shiftViolations
  })
  checks.push({
    name: '设备库存成员/替代资格检查',
    status: equiViolations === 0 ? 'pass' : 'fail',
    detail: equiViolations === 0 ? '任务设备均在库存成员内且符合类型与替代资格' : `${equiViolations} 处设备违规`,
    violations: equiViolations
  })

  // 4. 资源占用（人员 + 独占资源，含产线任务级）
  let resourceViolations = 0
  const personIntervals = new Map()
  const exIntervals = new Map()
  for (const e of entries) {
    if (!personIntervals.has(e.assigneeId)) personIntervals.set(e.assigneeId, [])
    personIntervals.get(e.assigneeId).push([e.start, e.end, e.id])
    if (e.exclusive) {
      if (!exIntervals.has(e.exclusive)) exIntervals.set(e.exclusive, [])
      exIntervals.get(e.exclusive).push([e.start, e.end, e.id])
    }
    if (e.equipment) {
      if (!exIntervals.has(e.equipment)) exIntervals.set(e.equipment, [])
      exIntervals.get(e.equipment).push([e.start, e.end, e.id])
    }
  }
  for (const [pid, arr] of personIntervals.entries()) {
    arr.sort((a, b) => a[0] - b[0])
    for (let i = 1; i < arr.length; i++) {
      if (arr[i][0] < arr[i - 1][1] - 1e-6) {
        resourceViolations++
        violations.push({ type: 'resource', resource: pid, detail: `人员 ${pid} 任务时间重叠：${arr[i - 1][2]} / ${arr[i][2]}` })
      }
    }
  }
  for (const [ex, arr] of exIntervals.entries()) {
    arr.sort((a, b) => a[0] - b[0])
    for (let i = 1; i < arr.length; i++) {
      if (arr[i][0] < arr[i - 1][1] - 1e-6) {
        resourceViolations++
        violations.push({ type: 'resource', resource: ex, detail: `独占资源 ${ex} 任务时间重叠：${arr[i - 1][2]} / ${arr[i][2]}` })
      }
    }
  }
  checks.push({
    name: '资源占用与冲突检查',
    status: resourceViolations === 0 ? 'pass' : 'fail',
    detail: resourceViolations === 0 ? '人员与独占资源均无重叠占用' : `${resourceViolations} 处资源冲突`,
    violations: resourceViolations
  })

  // 5. 同一产线在线换产窗口不交叠
  const orderIds = Array.from(new Set(tasks.map((t) => t.order)))
  const firstOnline = (oid) => {
    const arr = entries.filter((e) => e.order === oid && ONLINE_KEYS.has(e.key))
    return arr.length ? arr.reduce((a, b) => (a.start <= b.start ? a : b)) : null
  }
  const locks = []
  for (const oid of orderIds) {
    const st = firstOnline(oid)
    const rs = byId.get(`${oid}::resume`)
    if (!st || !rs) continue
    locks.push({ order: oid, start: st.start, end: rs.end, startEvent: st.name })
  }
  let lockViolations = 0
  for (let i = 0; i < locks.length; i++) {
    for (let j = i + 1; j < locks.length; j++) {
      const a = locks[i]
      const b = locks[j]
      if (a.start < b.end - 1e-6 && b.start < a.end - 1e-6) {
        lockViolations++
        violations.push({ type: 'line_lock', detail: `订单 ${a.order} 与 ${b.order} 的在线换产窗口交叠` })
      }
    }
  }
  checks.push({
    name: '同一产线在线换产窗口检查',
    status: lockViolations === 0 ? 'pass' : 'fail',
    detail: lockViolations === 0 ? '各订单在线换产窗口互不交叠（单产线串行换产）' : `${lockViolations} 处产线窗口交叠`,
    violations: lockViolations
  })

  // 6. 首件生产时产品/工装/参数一致性
  let consistencyViolations = 0
  for (const oid of orderIds) {
    const st = firstOnline(oid)
    const ap = byId.get(`${oid}::param_apply`)
    const pr = byId.get(`${oid}::fai_produce`)
    if (!st || !ap || !pr) continue
    if (st.end > pr.start + 1e-6) {
      consistencyViolations++
      violations.push({ type: 'line_consistency', detail: `订单 ${oid} 首件生产早于本订单在线换产开始` })
    }
    if (ap.end > pr.start + 1e-6) {
      consistencyViolations++
      violations.push({ type: 'line_consistency', detail: `订单 ${oid} 首件生产早于本订单参数应用完成` })
    }
    // 在 [本订单在线换产开始, 首件生产开始] 区间内，不得出现其他订单的在线产线任务
    for (const other of orderIds) {
      if (other === oid) continue
      for (const key of ['line_clear', 'tooling_switch', 'param_apply']) {
        const oe = byId.get(`${other}::${key}`)
        if (!oe) continue
        if (oe.start < pr.start - 1e-6 && oe.end > st.start + 1e-6) {
          consistencyViolations++
          violations.push({
            type: 'line_consistency',
            detail: `订单 ${oid} 首件生产前，产线在位配置被订单 ${other} 的 ${key} 覆盖`
          })
        }
      }
    }
  }
  checks.push({
    name: '首件生产产品/工装/参数一致性检查',
    status: consistencyViolations === 0 ? 'pass' : 'fail',
    detail: consistencyViolations === 0 ? '首件生产时产线产品、在位工装与已生效参数均与本订单一致' : `${consistencyViolations} 处产线在位配置被覆盖`,
    violations: consistencyViolations
  })

  // 7. 质量门禁：检验通过 → 放行 → 恢复生产
  let gateViolations = 0
  const faiResults = options.faiResults || {}
  for (const oid of orderIds) {
    const insp = byId.get(`${oid}::fai_inspect`)
    const rel = byId.get(`${oid}::quality_release`)
    const rs = byId.get(`${oid}::resume`)
    if (!insp || !rel || !rs) continue
    if (insp.end > rel.start + 1e-6) {
      gateViolations++
      violations.push({ type: 'quality_gate', detail: `订单 ${oid} 质量放行早于首件检验完成` })
    }
    if (rel.end > rs.start + 1e-6) {
      gateViolations++
      violations.push({ type: 'quality_gate', detail: `订单 ${oid} 恢复生产早于质量放行` })
    }
    if (faiResults[oid] === 'fail') {
      gateViolations++
      violations.push({ type: 'quality_gate', detail: `订单 ${oid} 首件检验未通过，禁止放行与恢复生产` })
    }
  }
  checks.push({
    name: '质量门禁检查',
    status: gateViolations === 0 ? 'pass' : 'fail',
    detail: gateViolations === 0 ? '首件检验合格 → 质量放行 → 恢复生产链路合规' : `${gateViolations} 处质量门禁违例`,
    violations: gateViolations
  })

  return { ok: violations.length === 0, checks, violations, locks, evaluatedAt: now }
}

// ---------------------------------------------------------------------------
// 对外：构建 A / B / C 三套排程
// ---------------------------------------------------------------------------

function buildSchedules({ tasks, personnel, exclusive, equipment, ordersInOrder, seed = 20261005, strategyOverride = null }) {
  // 设备库存准入：任务所需设备（含替代）必须在提供的库存成员中，否则视为不可行
  if (equipment !== undefined) {
    const inv = new Set((equipment || []).map((e) => e.id))
    for (const t of tasks) {
      if (!t.equipment) continue
      const opts = [t.equipment, ...(t.equipmentAlternatives || [])]
      if (!opts.some((id) => inv.has(id))) {
        throw new Error(`设备库存缺少任务 ${t.id} 所需设备 ${t.equipment}`)
      }
    }
  }
  const override = strategyOverride && strategyOverride.weights ? strategyOverride : null
  const A = withMetrics(buildStrategyA(tasks, ordersInOrder, personnel, exclusive, equipment), tasks, personnel, exclusive, ordersInOrder, equipment)
  const B = withMetrics(buildStrategyB(tasks, ordersInOrder, personnel, exclusive, equipment), tasks, personnel, exclusive, ordersInOrder, equipment)
  const C = withMetrics(
    override
      ? buildStrategyCLearned(tasks, ordersInOrder, personnel, exclusive, equipment, override.weights, { maxAttempts: override.maxAttempts })
      : buildStrategyC(tasks, ordersInOrder, personnel, exclusive, equipment, seed),
    tasks,
    personnel,
    exclusive,
    ordersInOrder,
    equipment
  )

  const delta = (from, to) => ({
    from: from.mode,
    to: to.mode,
    makespanDeltaMin: round(Math.max(0, from.metrics.makespan - to.metrics.makespan)),
    makespanDeltaPct: from.metrics.makespan ? round(((from.metrics.makespan - to.metrics.makespan) / from.metrics.makespan) * 100, 1) : 0,
    onlineStopDeltaMin: round(Math.max(0, from.metrics.onlineStopTotal - to.metrics.onlineStopTotal))
  })

  return {
    A,
    B,
    C,
    comparison: {
      A: A.metrics,
      B: B.metrics,
      C: C.metrics,
      deltas: {
        AtoB: delta(A, B),
        BtoC: delta(B, C),
        AtoC: delta(A, C)
      },
      interpretation: {
        AtoB: 'A→B 的变化主要来自“后续订单离线准备提前并行”带来的收益（订单上线顺序与离线优先级均未优化）。',
        BtoC: 'B→C 在并行权限与物理约束完全相同的前提下，变化来自调度算法（订单上线顺序 + 离线准备优先级联合寻优）带来的收益。',
        AtoC: 'A→C 为对照策略到协同优化的总体变化。'
      },
      note: '三套排程使用完全相同的订单、任务耗时、人员、资源与初始状态；未通过放松产线状态约束制造改善。'
    }
  }
}

function withMetrics(strategy, tasks, personnel, exclusive, ordersInOrder, equipment) {
  const metrics = computeMetrics(strategy.entries, personnel, exclusive, ordersInOrder, equipment)
  return { ...strategy, metrics }
}

module.exports = {
  buildSchedules,
  validateSchedule,
  computeMetrics,
  computeCriticalPath,
  round,
  ONLINE_KEYS,
  makeBanks,
  schedulePrep,
  scheduleLineBands,
  templateRank,
  criticalPathRank,
  earliestPersonForSkill,
  earliestEquipment,
  equipmentOptions,
  firstFreeSlot,
  byStart,
  enumerateSequences,
  candidateRanksOriginal,
  searchCBudgeted,
  buildStrategyC,
  buildStrategyCLearned
}
