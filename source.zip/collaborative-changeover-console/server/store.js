'use strict'

const fs = require('fs')
const path = require('path')

const STORE_DIR = path.join(__dirname, '..', 'data', 'store')

function ensure() {
  if (!fs.existsSync(STORE_DIR)) fs.mkdirSync(STORE_DIR, { recursive: true })
}

function file(name) {
  return path.join(STORE_DIR, name)
}

function readJSON(name, fallback = null) {
  try {
    const p = file(name)
    if (!fs.existsSync(p)) return fallback
    return JSON.parse(fs.readFileSync(p, 'utf8'))
  } catch (err) {
    console.error(`[store] 读取 ${name} 失败:`, err.message)
    return fallback
  }
}

function writeJSON(name, value) {
  ensure()
  const p = file(name)
  const tmp = `${p}.tmp`
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2), 'utf8')
  fs.renameSync(tmp, p)
  return p
}

module.exports = { STORE_DIR, readJSON, writeJSON }
