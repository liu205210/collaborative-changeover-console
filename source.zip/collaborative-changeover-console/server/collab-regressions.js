'use strict'

/**
 * 第六阶段 · 智能协作与可核验问答回归（独立、只读，不求解 reserved）
 * 用法：node server/collab-regressions.js
 */

const assert = require('assert')
const recovery = require('./recovery')
const collab = require('./collaboration')
const assistant = require('./assistant')
const evaluation = require('./evaluation')
const store = require('./store')
const { importWorkbook, DEFAULT_XLSX } = require('./dataLoader')

const { orders } = importWorkbook(DEFAULT_XLSX)

let passed = 0
let failed = 0
function check(name, fn) {
  try {
    fn()
    passed++
    console.log(`  [PASS] ${name}`)
  } catch (err) {
    failed++
    console.log(`  [FAIL] ${name} -> ${err.message}`)
  }
}

function fresh(n = 3) {
  return recovery.createSession({ orders: orders.slice(0, n) })
}
function apply(session, ev) {
  const r = recovery.applyEvent(session, ev)
  return { session: r.bundle, result: r.result }
}
function snap(session, opts) {
  return collab.snapshotFromSession(session, opts || {})
}

console.log('\n=== 1. 事实快照：计划/执行/回放不串版本 ===')
check('计划预测快照为 plan 且无已知事件', () => {
  const plan = { planId: 'p1', modelVersion: 'v4.2.2-audited', orders: orders.slice(0, 3), schedules: { C: { entries: [], metrics: { makespan: 10, onlineStopTotal: 5 } } } }
  const s = collab.snapshotFromPlan(plan)
  assert.strictEqual(s.kind, 'plan')
  assert.strictEqual(s.knownEvents.length, 0)
  assert.ok(s.snapshotId.startsWith('snap-plan-'))
})
check('执行与回放快照修订号不同且回放只用已保存事件', () => {
  const s0 = fresh()
  const { session } = apply(s0, { type: 'equipment_failure', target: 'LINE-01', at: 30, duration: 10 })
  const exec = snap(session, {})
  const replay = snap(session, { eventIndex: 1 })
  const baseline = snap(session, { eventIndex: 0 })
  assert.strictEqual(exec.kind, 'execution')
  assert.strictEqual(replay.kind, 'replay')
  assert.strictEqual(baseline.kind, 'replay')
  assert.notStrictEqual(exec.revision, replay.revision)
  assert.strictEqual(baseline.knownEvents.length, 0)
  assert.strictEqual(replay.knownEvents.length, 1)
})

console.log('\n=== 2. t=0 与任务边界 ===')
check('t=0 不提前完成任务，状态不为已完成', () => {
  const s = snap(fresh(), { at: 0 })
  const at0 = collab.buildRoleStates(s)
  assert.ok(at0.every((r) => r.status !== '已完成'))
  assert.ok(s.tasks.every((t) => t.start >= 0))
  assert.strictEqual(s.tasks.filter((t) => t.end <= 0).length, 0)
})
check('跨越任务边界时状态为进行中', () => {
  const session = fresh()
  const running = session.actualEntries.find((e) => e.end > 1 && e.start < 1)
  const mid = collab.r2((running.start + running.end) / 2)
  const s = snap(session, { at: mid })
  const task = s.tasks.find((t) => t.id === running.id)
  const doneIds = new Set(s.tasks.filter((t) => t.end <= mid + 1e-9).map((t) => t.id))
  assert.strictEqual(collab.tStatus(task, mid, doneIds), '进行中')
})
check('未来故障不进入当前已知事实', () => {
  const s0 = fresh()
  const { session } = apply(s0, { type: 'equipment_failure', target: 'LINE-01', at: 30, duration: 10 })
  const before = snap(session, { at: 20 })
  assert.strictEqual(before.knownEvents.length, 0, '未发生事件不应出现在已知事实中')
  assert.ok(!before.tasks.some((t) => t.id.includes('::seg@')), '不应提前暴露故障片段')
  const msgs = collab.buildMessages(before)
  assert.ok(!msgs.some((m) => m.reasonCode === 'ANOMALY_DETECTED' && /设备故障/.test(m.text)))
})

console.log('\n=== 3. 角色映射与质量门禁/锁定 ===')
check('关键任务类型均有角色映射（清线/返工/复检/续作片段）', () => {
  for (const k of ['line_clear', 'resume', 'rework', 'recheck', 'material_deliver', 'param_apply', 'tooling_switch', 'fai_inspect', 'quality_release']) {
    assert.ok(collab.ROLE_OF_KEY[k], `缺少角色映射 ${k}`)
  }
  assert.strictEqual(collab.ROLE_OF_KEY.line_clear, 'scheduler')
  assert.strictEqual(collab.ROLE_OF_KEY.rework, 'employee')
  assert.strictEqual(collab.ROLE_OF_KEY.recheck, 'quality')
})
check('清线→恢复生产为产线锁定，解除时刻=恢复生产结束', () => {
  const session = fresh()
  const s = snap(session, { at: 1e9 })
  const lock = s.lineLocks[0]
  const lc = s.tasks.find((t) => t.order === lock.order && t.key === 'line_clear')
  const rs = s.tasks.find((t) => t.order === lock.order && t.key === 'resume')
  assert.ok(Math.abs(lock.start - lc.start) < 1e-6)
  assert.ok(Math.abs(lock.end - rs.end) < 1e-6)
  const q = s.quality.find((x) => x.order === lock.order)
  assert.strictEqual(q.lineUnlocked, true)
  assert.ok(q.releaseComplete && q.resumeComplete)
})
check('首件不合格：检验完成、放行、恢复、锁定解除时刻区分且返工复检存在', () => {
  const s0 = fresh()
  const order = s0.orderIds[0]
  const { session } = apply(s0, { type: 'fai_fail', target: order, at: 0 })
  const rec = session.events[0]
  const at = collab.r2(rec.triggerAt + 0.001)
  const s = snap(session, { at })
  const q = s.quality.find((x) => x.order === order)
  assert.strictEqual(q.faiComplete, true)
  assert.strictEqual(q.faiStatus, '不合格')
  assert.strictEqual(q.reworkPresent, true)
  assert.strictEqual(q.recheckPresent, true)
  assert.strictEqual(q.lineUnlocked, false, '返工复检完成前不应解除产线锁定')
  const roles = collab.buildRoleStates(s)
  const quality = roles.find((r) => r.id === 'quality')
  assert.ok(quality.tasks.some((t) => t.key === 'recheck'))
})

console.log('\n=== 3b. 时间/版本绑定与失败历史分离 ===')
check('首件失败在触发前不可见（t=0 与检验中均不显示不合格）', () => {
  const s0 = fresh()
  const order = s0.orderIds[0]
  const { session } = apply(s0, { type: 'fai_fail', target: order, at: 0 })
  const rec = session.events[0]
  const insp = session.basePlan.entries.find((e) => e.id === `${order}::fai_inspect`)
  const before = snap(session, { at: 0 })
  const during = snap(session, { at: collab.r2((insp.start + insp.end) / 2) })
  assert.strictEqual(before.knownEvents.length, 0)
  assert.strictEqual(before.quality.find((q) => q.order === order).faiStatus, '待检验')
  assert.strictEqual(during.quality.find((q) => q.order === order).faiStatus, '待检验')
  assert.ok(!snap(session, { at: rec.triggerAt + 0.001 }).tasks.some((t) => t.result === 'fail' && t.end > rec.triggerAt + 1e-9))
})
check('连续事件的历史时刻使用对应已保存版本', () => {
  const s0 = fresh()
  const first = apply(s0, { type: 'equipment_failure', target: 'LINE-01', at: 30, duration: 10 })
  const second = apply(first.session, { type: 'equipment_failure', target: 'LINE-01', at: 31, duration: 20 })
  const at30a = snap(first.session, { at: 30 })
  const at30b = snap(second.session, { at: 30 })
  const idx1 = snap(second.session, { eventIndex: 1 })
  assert.deepStrictEqual(at30a.tasks, at30b.tasks)
  assert.deepStrictEqual(idx1.tasks, at30b.tasks)
})
check('同刻新增事件改变任务时快照身份变化', () => {
  const s0 = fresh()
  const first = apply(s0, { type: 'equipment_failure', target: 'LINE-01', at: 30, duration: 10 })
  const sameAt = apply(first.session, { type: 'equipment_failure', target: 'LINE-01', at: 30, duration: 20 })
  const a = snap(first.session, {})
  const b = snap(sameAt.session, {})
  assert.ok(JSON.stringify(a.tasks) !== JSON.stringify(b.tasks))
  assert.ok(a.snapshotId !== b.snapshotId && a.contractDigest !== b.contractDigest)
})
check('返工复检完成后质量角色不再显示活动异常', () => {
  const s0 = fresh()
  const order = s0.orderIds[0]
  const { session } = apply(s0, { type: 'fai_fail', target: order, at: 0 })
  const fixture = JSON.parse(JSON.stringify(session))
  fixture.clock = collab.r2(Math.max(...fixture.actualEntries.map((t) => t.end)))
  const s = snap(fixture, {})
  const quality = collab.buildRoleStates(s).find((r) => r.id === 'quality')
  assert.notStrictEqual(quality.status, '异常')
  assert.ok(!/已拦截放行/.test(quality.request))
  assert.strictEqual(s.quality.find((q) => q.order === order).recheckComplete, true)
})
check('真实依赖未完成时任务状态为等待（不恒真）', () => {
  const s = snap(fresh(), { at: 0 })
  const deliver = s.tasks.find((t) => t.key === 'material_deliver')
  const doneIds = new Set(s.tasks.filter((t) => t.end <= 0 + 1e-9).map((t) => t.id))
  assert.strictEqual(collab.tStatus(deliver, 0, doneIds), '等待', '配送依赖拣配，t=0 应等待')
})

console.log('\n=== 4. 四类异常与协作消息一致 ===')
const EVENT_CASES = [
  { type: 'agv_delay', make: (s) => { const d = s.actualEntries.filter((e) => e.key === 'material_deliver').sort((a, b) => a.start - b.start)[0]; return { type: 'agv_delay', target: d.id, at: Math.max(0, d.start), duration: 15 } } },
  { type: 'person_absence', make: () => ({ type: 'person_absence', target: 'EQP-01', at: 6, duration: 8, policy: 'finish_current' }) },
  { type: 'equipment_failure', make: () => ({ type: 'equipment_failure', target: 'LINE-01', at: 30, duration: 10 }) },
  { type: 'fai_fail', make: (s) => ({ type: 'fai_fail', target: s.orderIds[0], at: 0 }) }
]
for (const c of EVENT_CASES) {
  check(`${c.type}：消息含异常/快照/R0R1 且与恢复记录一致`, () => {
    const s0 = fresh()
    const ev = c.make(s0)
    const { session, result } = apply(s0, ev)
    assert.ok(result.applied, `事件未生效 ${c.type}`)
    const rec = session.events[session.events.length - 1]
    const s = snap(session, {})
    const msgs = collab.buildMessages(s)
    const codes = new Set(msgs.map((m) => m.reasonCode))
    assert.ok(codes.has('ANOMALY_DETECTED') && codes.has('SNAPSHOT_SHARED') && codes.has('R0R1_COMPARED') && codes.has('VALIDATION_RESULT'))
    const cmp = msgs.find((m) => m.reasonCode === 'R0R1_COMPARED')
    const r0 = cmp.evidenceRefs.find((r) => r.ref.endsWith(':R0'))
    const r1 = cmp.evidenceRefs.find((r) => r.ref.endsWith(':R1'))
    assert.strictEqual(r0.value, rec.R0.metrics.makespan)
    assert.strictEqual(r1.value, rec.R1.metrics.makespan)
    const adopted = msgs.find((m) => m.reasonCode === 'PLAN_ADOPTED')
    assert.ok(adopted.text.includes(rec.chosen))
  })
}

console.log('\n=== 5. 问答：数值引用一致、未知明确 ===')
function agvSession() {
  const s0 = fresh()
  const d = s0.actualEntries.filter((e) => e.key === 'material_deliver').sort((a, b) => a.start - b.start)[0]
  return apply(s0, { type: 'agv_delay', target: d.id, at: Math.max(0, d.start), duration: 15 }).session
}
check('AGV 恢复问答数值与恢复记录一致', () => {
  const session = agvSession()
  const rec = session.events[0]
  const s = snap(session, {})
  const a = assistant.answerQuestion({ question: 'AGV 延迟后为什么采用当前恢复方案？', snapshot: s })
  const r0 = a.evidenceRefs.find((r) => r.ref.endsWith(':R0'))
  const r1 = a.evidenceRefs.find((r) => r.ref.endsWith(':R1'))
  assert.strictEqual(r0.value, rec.R0.metrics.makespan)
  assert.strictEqual(r1.value, rec.R1.metrics.makespan)
  assert.ok(a.conclusion.includes(String(rec.R0.metrics.makespan)))
})
check('未发生 AGV 事件时明确未知', () => {
  const a = assistant.answerQuestion({ question: 'AGV 延迟后为什么采用当前恢复方案？', snapshot: snap(fresh(), {}) })
  assert.ok(/没有已发生/.test(a.conclusion))
  assert.strictEqual(a.evidenceRefs.length, 0)
})
check('不支持的问题明确未知', () => {
  const a = assistant.answerQuestion({ question: '今天天气怎么样', snapshot: snap(fresh(), {}) })
  assert.strictEqual(a.intent, 'unknown')
  assert.ok(/不在当前支持/.test(a.conclusion))
  assert.strictEqual(a.evidenceRefs.length, 0)
})
check('放行问答在首件未完成时明确缺失条件', () => {
  const s = snap(fresh(), { at: 0 })
  const order = s.orders[0].order
  const a = assistant.answerQuestion({ question: `订单 ${order} 现在能否放行？`, snapshot: s })
  assert.ok(/尚不能放行|尚未进入/.test(a.conclusion))
})
check('显式未知订单不得替换为快照首单', () => {
  const s = snap(fresh(), { at: 1e9 })
  const a = assistant.answerQuestion({ question: '订单 9999999999 现在能否放行？', snapshot: s })
  assert.ok(/未找到|不属于|不存在/.test(a.conclusion))
  assert.ok(!a.evidenceRefs.some((r) => r.order === s.orders[0].order))
})

console.log('\n=== 6. 大模型：配置/回退/伪造引用/越权 ===')
check('无凭据时为规则模式且真实调用未验证', () => {
  delete process.env.LLM_PROVIDER
  delete process.env.LLM_API_KEY
  delete process.env.LLM_BASE_URL
  delete process.env.LLM_MODEL
  const st = assistant.modelStatus()
  assert.strictEqual(st.configured, false)
  assert.strictEqual(st.realCallVerified, false)
  const a = assistant.answerQuestion({ question: '当前哪个任务阻塞了换产？', snapshot: snap(fresh(), {}) })
  assert.strictEqual(a.mode, 'rule')
})
check('伪造引用被拒绝，未验证数字/单位混淆被拒绝', () => {
  const rule = { conclusion: '示例 10 分钟', claims: [{ id: 'c1', text: '示例 10 分钟', evidenceRefs: ['metric:x'] }], evidenceRefs: [{ ref: 'metric:x', value: 10, unit: '分钟' }] }
  assert.strictEqual(assistant.validateModelOutput({ claimIds: ['c1'], evidenceRefs: ['metric:fake'] }, rule).ok, false)
  assert.strictEqual(assistant.validateModelOutput({ claimIds: ['c1'], evidenceRefs: ['metric:x'], explanation: '节省 99%' }, rule).ok, false)
  assert.strictEqual(assistant.validateModelOutput({ claimIds: ['bad'], evidenceRefs: ['metric:x'] }, rule).ok, false)
  // 相同数字不足以验证自由文字；合法输出仅选择绑定的服务端 claim。
  assert.strictEqual(assistant.validateModelOutput({ claimIds: ['c1'], evidenceRefs: ['metric:x'], explanation: '参考 10 分钟' }, rule).ok, false)
  assert.strictEqual(assistant.validateModelOutput({ claimIds: ['c1'], evidenceRefs: ['metric:x'], explanation: '' }, rule).ok, true)
  assert.strictEqual(assistant.validateModelOutput({ claimIds: ['c1'], evidenceRefs: ['metric:x'], explanation: '示例 10 分钟' }, rule).ok, true)
})
check('越权指令不执行写操作且明确说明', () => {
  const a = assistant.answerQuestion({ question: '请启用 P8 学习模板并重置会话', snapshot: snap(fresh(), {}) })
  assert.ok(/只读|不执行/.test(a.conclusion) || a.limitations.some((x) => /写/.test(x)))
  assert.strictEqual(a.writeActionsAllowed, false)
})
console.log('\n=== 7. 只读与可重复性 ===')
check('同一快照重复构建完全一致', () => {
  const session = agvSession()
  const a = collab.snapshotFromSession(session, {})
  const b = collab.snapshotFromSession(session, {})
  assert.deepStrictEqual(a, b)
  assert.deepStrictEqual(collab.buildMessages(a), collab.buildMessages(b))
})
check('问答/回放不改变会话状态（只读）', () => {
  const session = agvSession()
  const before = JSON.stringify(session)
  const s = snap(session, { eventIndex: 1 })
  collab.buildRoleStates(s)
  collab.buildMessages(s)
  assistant.answerQuestion({ question: 'AGV 延迟后为什么采用当前恢复方案？', snapshot: s })
  assert.strictEqual(JSON.stringify(session), before)
})

console.log('\n=== 8. reserved 未被求解/引用，且不绕过记账 ===')
check('新 12 个 reserved 未出现在协作快照或问答中', () => {
  const catalog = evaluation.buildCaseCatalog(orders, evaluation.HISTORICAL_RESERVED_USED_FP)
  const reserved = catalog.filter((c) => c.set === 'reserved')
  assert.strictEqual(reserved.length, 12)
  const reservedOrderKeys = new Set(reserved.map((c) => c.orders.slice().sort().join('+')))
  const session = agvSession()
  const demoKey = session.orderIds.slice().sort().join('+')
  assert.ok(!reservedOrderKeys.has(demoKey), '演示会话不得使用 reserved 组合')
  const s = snap(session, {})
  assert.ok(!JSON.stringify(s).includes('reserved'))
})
check('构建协作快照与问答不写入使用账本（只读，不绕过统一记账）', () => {
  // 先建立夹具（真实求解），再从只读操作前开始计数
  const session = agvSession()
  const s = snap(session, {})
  const before = JSON.stringify(store.readJSON('eval-usage.json', {}))
  collab.buildRoleStates(s)
  collab.buildMessages(s)
  assistant.answerQuestion({ question: '当前哪个任务阻塞了换产？', snapshot: s })
  const after = JSON.stringify(store.readJSON('eval-usage.json', {}))
  assert.strictEqual(before, after)
})

console.log('\n=== 9. 模型适配与回退（异步） ===')
;(async () => {
  const saved = {}
  for (const k of ['LLM_PROVIDER', 'LLM_BASE_URL', 'LLM_MODEL', 'LLM_API_KEY', 'LLM_TIMEOUT_MS']) saved[k] = process.env[k]
  try {
    process.env.LLM_PROVIDER = 'openai'
    process.env.LLM_BASE_URL = 'http://127.0.0.1:9'
    process.env.LLM_MODEL = 'none'
    process.env.LLM_API_KEY = 'test-key-not-real'
    process.env.LLM_TIMEOUT_MS = '1500'
    const s = snap(fresh(), {})
    const a = await assistant.explain({ question: '当前哪个任务阻塞了换产？', snapshot: s, allowModel: true })
    check('提供方不可达时回退规则模式且标注原因', () => {
      assert.strictEqual(a.mode, 'fallback')
      assert.ok(a.conclusion)
      assert.ok(a.modelInfo && a.modelInfo.fallbackReason)
    })
    process.env.LLM_PROVIDER = 'stub'
    const b = await assistant.explain({ question: '当前哪个任务阻塞了换产？', snapshot: s, allowModel: true })
    check('测试替身模式标注 stub 且引用核验通过', () => {
      assert.strictEqual(b.mode, 'stub')
      assert.strictEqual(b.modelInfo.refCheck, 'pass')
      assert.strictEqual(b.modelInfo.realCallVerified, false)
    })
  } catch (e) {
    failed++
    console.log(`  [FAIL] 模型适配异步用例 -> ${e.message}`)
  } finally {
    for (const k of Object.keys(saved)) {
      if (saved[k] === undefined) delete process.env[k]
      else process.env[k] = saved[k]
    }
  }
  console.log(`\n=== 协作回归汇总：通过 ${passed} 项，失败 ${failed} 项 ===\n`)
  if (failed > 0) process.exit(1)
})()
